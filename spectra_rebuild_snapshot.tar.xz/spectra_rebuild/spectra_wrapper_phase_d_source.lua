-- SPECTRA Phase-D wrapper: clean auth + reconstructed UI + partial feature runtime.
-- Embedded payload remains byte-identical; D4-recovery source owns UI + no_recoil/converge + public visual entries after init.
local S = {}

-- BEGIN runtime.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local M = {}
S.Runtime = M
S.Config = type(S.Config) == "table" and S.Config or {}

local function safe_rawget(name)
    local ok, value = pcall(rawget, _G, name)
    if ok then
        return value
    end
    return nil
end

function M.safe_get(obj, key)
    local t = type(obj)
    if t ~= "table" and t ~= "userdata" then
        return nil
    end
    local ok, value = pcall(function()
        return obj[key]
    end)
    if ok then
        return value
    end
    return nil
end

function M.try_call(fn, ...)
    if type(fn) ~= "function" then
        return false, "not_a_function"
    end
    local ok, a, b, c = pcall(fn, ...)
    if not ok then
        return false, tostring(a)
    end
    return true, a, b, c
end

function M.try_method(obj, name, ...)
    local fn = M.safe_get(obj, name)
    if type(fn) ~= "function" then
        return false, "missing_method:" .. tostring(name)
    end
    return M.try_call(fn, obj, ...)
end

function M.trim(value)
    local s = tostring(value or "")
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    return s
end

function M.normalize_card(value)
    local s = tostring(value or "")
    s = s:gsub("\239\187\191", "") -- U+FEFF
    s = s:gsub("\226\128\139", "") -- U+200B
    s = s:gsub("\226\128\140", "") -- U+200C
    s = s:gsub("\226\128\141", "") -- U+200D
    s = s:gsub("\226\129\160", "") -- U+2060
    s = s:gsub("\194\160", " ")     -- U+00A0
    s = s:gsub("\227\128\128", " ") -- U+3000
    s = M.trim(s)
    if #s >= 2 then
        local first = s:sub(1, 1)
        local last = s:sub(-1)
        if (first == '"' and last == '"') or (first == "'" and last == "'") then
            s = s:sub(2, -2)
        end
    end
    return (s:gsub("%s+", ""))
end

function M.delay(seconds, callback)
    local timer = safe_rawget("Timer")
    local delay_call = M.safe_get(timer, "DelayCall")
    if type(delay_call) ~= "function" then
        callback()
        return false
    end

    local ok = pcall(delay_call, seconds, callback)
    if not ok then
        ok = pcall(delay_call, timer, seconds, callback)
    end
    return ok
end

function M.show_tip(message, severity)
    -- Baseline proto 0.4 resolves _G.Module.CommonTips directly; it does not
    -- require a CommonTips module path.
    local module_root = safe_rawget("Module")
    local tips = M.safe_get(module_root, "CommonTips")
    local fn = M.safe_get(tips, "ShowSimpleTip")
    if type(fn) ~= "function" then
        return false
    end
    return pcall(fn, tips, tostring(message or ""), severity or 3)
end

function M.get_timestamp()
    local os_table = safe_rawget("os")
    local time_fn = M.safe_get(os_table, "time")
    if type(time_fn) == "function" then
        local ok, value = pcall(time_fn)
        if ok and type(value) == "number" then
            return math.floor(value)
        end
    end
    return 0
end

function M.get_device_id()
    -- Baseline proto 0.31 reads DEVICE_ID from the wrapper's private config
    -- table (root R0), not from _G. Keep the same private slot available for
    -- controlled overrides without inventing a global engine API.
    local direct = S.Config.DEVICE_ID
    if type(direct) == "string" and direct ~= "" then
        return direct
    end

    local bridge = safe_rawget("CharacterColorWeiYanGetDeviceId")
    if type(bridge) == "function" then
        local ok, value = pcall(bridge)
        if ok and value ~= nil and tostring(value) ~= "" then
            return tostring(value)
        end
    end

    do
        local require_fn = safe_rawget("require")
        if type(require_fn) == "function" then
            local ok, info_module = pcall(require_fn, "Common.Framework.Util.DeviceOSInfo")
            if ok and info_module ~= nil then
                local get_info = M.safe_get(info_module, "GetDeviceOSInfo")
                if type(get_info) == "function" then
                    local ok_info, info = pcall(get_info)
                    if not ok_info then
                        ok_info, info = pcall(get_info, info_module)
                    end
                    if ok_info and info ~= nil then
                        for _, key in ipairs({"DeviceId", "deviceId", "device_id"}) do
                            local ok_value, value = pcall(function() return info[key] end)
                            if ok_value and value ~= nil and tostring(value) ~= "" then
                                return tostring(value)
                            end
                        end
                    end
                end
            end
        end
    end

    do
        local import_fn = safe_rawget("import")
        if type(import_fn) == "function" then
            local ok_import, module = pcall(import_fn, "GetDeviceInfo")
            if ok_import and module ~= nil then
                local get_info = M.safe_get(module, "GetDeviceInfo")
                if type(get_info) == "function" then
                    for _, key in ipairs({"QIMEI36", "QIMEI", "OAID", "ANDROID_ID", "DeviceId"}) do
                        local ok_value, value = pcall(get_info, key)
                        if not ok_value then
                            ok_value, value = pcall(get_info, module, key)
                        end
                        if ok_value and value ~= nil and tostring(value) ~= "" then
                            return tostring(value)
                        end
                    end
                end
            end
        end
    end

    do
        local server_root = safe_rawget("Server")
        local account_server = M.safe_get(server_root, "AccountServer")
        local get_player_id = M.safe_get(account_server, "GetPlayerId")
        if type(get_player_id) == "function" then
            local ok, value = pcall(get_player_id, account_server)
            if ok and value ~= nil then
                local text = tostring(value)
                if text ~= "" and text ~= "0" then
                    return "player-" .. text
                end
            end
        end
    end

    for _, name in ipairs({
        "GetDeviceId", "GetDeviceID", "GetUniqueDeviceId", "GetUniqueDeviceID",
        "GetMachineCode", "GetAndroidId", "GetAndroidID",
    }) do
        local fn = safe_rawget(name)
        if type(fn) == "function" then
            local ok, value = pcall(fn)
            if ok and value ~= nil and tostring(value) ~= "" then
                return tostring(value)
            end
        end
    end

    return nil, "Unable to read device ID: DeviceOSInfo/GetDeviceInfo is unavailable"
end

function M.bytes_to_string(value)
    if type(value) == "string" then
        return value
    end
    local util = safe_rawget("ULuautils")
    local fn = M.safe_get(util, "GetStringFromBytes")
    if type(fn) == "function" then
        -- Baseline proto 0.15 calls this bridge as a plain function with the
        -- byte value as its sole argument.
        local ok, result = pcall(fn, value)
        if ok and type(result) == "string" then
            return result
        end
    end
    return ""
end

function M.parse_json(text)
    -- Primary baseline parser: Common.Components.dkjson.decode(text, 1, nil)
    local ok, dkjson = pcall(require, "Common.Components.dkjson")
    if ok and type(dkjson) == "table" and type(dkjson.decode) == "function" then
        local ok_decode, result, _, decode_err = pcall(dkjson.decode, text, 1, nil)
        if ok_decode and not decode_err and type(result) == "table" then
            return result
        end
    end

    -- Secondary baseline parser: createJson() -> decoder object -> decode(text).
    local ok_dfm, json_mod = pcall(require, "DFM.YxFramework.Plugin.Json.Json")
    local create_json = ok_dfm and M.safe_get(json_mod, "createJson") or nil
    if type(create_json) == "function" then
        local ok_create, decoder = pcall(create_json)
        local decode = ok_create and M.safe_get(decoder, "decode") or nil
        if type(decode) == "function" then
            local ok_decode, result = pcall(decode, text)
            if ok_decode and type(result) == "table" then
                return result
            end
        end
    end

    -- Exact minimal field fallback used by baseline proto 0.14.
    local result = {
        code = tonumber(text:match([["code"%s*:%s*(-?%d+)]])),
        time = tonumber(text:match([["time"%s*:%s*(%d+)]])),
        check = text:match([["check"%s*:%s*"([0-9a-fA-F]+)"]]),
        msg = text:match([["msg"%s*:%s*"([^"]*)"]]),
    }
    if result.code then
        return result
    end
    return nil
end

function M.server_message(data)
    if type(data) ~= "table" then
        return "Invalid server data"
    end
    if type(data.msg) == "string" then
        return data.msg
    end
    if type(data.msg) == "table" then
        for _, key in ipairs({"msg", "message", "note"}) do
            local value = data.msg[key]
            if value ~= nil and M.trim(value) ~= "" then
                return M.trim(value)
            end
        end
    end
    return "Status code " .. tostring(data.code or "unknown")
end

function M.get_state()
    local state = rawget(_G, "_x1")
    if type(state) ~= "table" then
        state = {}
        rawset(_G, "_x1", state)
    end
    return state
end

end)(S)
-- END runtime.lua

-- BEGIN crypto.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local M = {}
S.Crypto = M

local MASK = 0xffffffff

local function u32(x)
    return x & MASK
end

local function rol(x, n)
    x = u32(x)
    return u32((x << n) | (x >> (32 - n)))
end

local MD5_SHIFT = {
    7,12,17,22, 7,12,17,22, 7,12,17,22, 7,12,17,22,
    5,9,14,20, 5,9,14,20, 5,9,14,20, 5,9,14,20,
    4,11,16,23, 4,11,16,23, 4,11,16,23, 4,11,16,23,
    6,10,15,21, 6,10,15,21, 6,10,15,21, 6,10,15,21,
}

local MD5_K = {
    0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,
    0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
    0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
    0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
    0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,
    0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
    0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,
    0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391,
}

local function le_u32(s, i)
    local a,b,c,d = s:byte(i, i + 3)
    return u32(a | (b << 8) | (c << 16) | (d << 24))
end

local function le_bytes_u32(x)
    x = u32(x)
    return string.char(
        x & 0xff,
        (x >> 8) & 0xff,
        (x >> 16) & 0xff,
        (x >> 24) & 0xff
    )
end

function M.md5(message)
    message = tostring(message or "")
    local original_len = #message
    local bit_len = original_len * 8

    local padding_len = (56 - ((original_len + 1) % 64)) % 64
    local low = bit_len & MASK
    local high = math.floor(bit_len / 4294967296) & MASK
    local padded = message .. "\128" .. string.rep("\0", padding_len)
        .. le_bytes_u32(low) .. le_bytes_u32(high)

    local a0 = 0x67452301
    local b0 = 0xefcdab89
    local c0 = 0x98badcfe
    local d0 = 0x10325476

    for offset = 1, #padded, 64 do
        local m = {}
        for j = 0, 15 do
            m[j] = le_u32(padded, offset + j * 4)
        end

        local A, B, C, D = a0, b0, c0, d0
        for i = 0, 63 do
            local F, g
            if i <= 15 then
                F = (B & C) | ((~B) & D)
                g = i
            elseif i <= 31 then
                F = (D & B) | ((~D) & C)
                g = (5 * i + 1) % 16
            elseif i <= 47 then
                F = B ~ C ~ D
                g = (3 * i + 5) % 16
            else
                F = C ~ (B | (~D))
                g = (7 * i) % 16
            end

            F = u32(F)
            local next_d = D
            D = C
            C = B
            B = u32(B + rol(u32(A + F + MD5_K[i + 1] + m[g]), MD5_SHIFT[i + 1]))
            A = next_d
        end

        a0 = u32(a0 + A)
        b0 = u32(b0 + B)
        c0 = u32(c0 + C)
        d0 = u32(d0 + D)
    end

    local digest = le_bytes_u32(a0) .. le_bytes_u32(b0) .. le_bytes_u32(c0) .. le_bytes_u32(d0)
    return (digest:gsub(".", function(ch)
        return string.format("%02x", string.byte(ch))
    end))
end

function M.rc4(data, key)
    data = tostring(data or "")
    key = tostring(key or "")
    assert(#key > 0, "RC4 key must not be empty")

    local s = {}
    for i = 0, 255 do
        s[i] = i
    end

    local j = 0
    for i = 0, 255 do
        j = (j + s[i] + key:byte((i % #key) + 1)) % 256
        s[i], s[j] = s[j], s[i]
    end

    local i = 0
    j = 0
    local out = {}
    for n = 1, #data do
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        local k = s[(s[i] + s[j]) % 256]
        out[n] = string.char(data:byte(n) ~ k)
    end
    return table.concat(out)
end

function M.hex_lower(data)
    return (data:gsub(".", function(ch)
        return string.format("%02x", string.byte(ch))
    end))
end

function M.hex_upper(data)
    return (data:gsub(".", function(ch)
        return string.format("%02X", string.byte(ch))
    end))
end

function M.hex_decode(text)
    text = tostring(text or "")
    if (#text % 2) ~= 0 or text:find("[^0-9A-Fa-f]") then
        return nil
    end
    local out = {}
    for i = 1, #text, 2 do
        out[#out + 1] = string.char(tonumber(text:sub(i, i + 1), 16))
    end
    return table.concat(out)
end

function M.rc4_encrypt_hex(data, key)
    return M.hex_lower(M.rc4(data, key))
end

-- This name matches the wrapper's semantic role, but the baseline function
-- actually converts every byte to bare uppercase hex. It is not RFC URL encoding.
function M.url_encode(value)
    return M.hex_upper(tostring(value or ""))
end

local B64 = {}
do
    local alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    for i = 1, #alphabet do
        B64[alphabet:sub(i, i)] = i - 1
    end
end

function M.base64_decode(text)
    text = tostring(text or ""):gsub("%s", "")
    if (#text % 4) ~= 0 then
        return nil, "invalid_base64_length"
    end

    local out = {}
    for pos = 1, #text, 4 do
        local c1 = text:sub(pos, pos)
        local c2 = text:sub(pos + 1, pos + 1)
        local c3 = text:sub(pos + 2, pos + 2)
        local c4 = text:sub(pos + 3, pos + 3)

        local a = B64[c1]
        local b = B64[c2]
        local c = (c3 == "=") and 0 or B64[c3]
        local d = (c4 == "=") and 0 or B64[c4]
        if a == nil or b == nil or c == nil or d == nil then
            return nil, "invalid_base64_character"
        end

        local n = (a << 18) | (b << 12) | (c << 6) | d
        out[#out + 1] = string.char((n >> 16) & 0xff)
        if c3 ~= "=" then
            out[#out + 1] = string.char((n >> 8) & 0xff)
        end
        if c4 ~= "=" then
            out[#out + 1] = string.char(n & 0xff)
        end
    end
    return table.concat(out)
end

function M.self_test()
    local rc4_vector = M.rc4_encrypt_hex("Plaintext", "Key")
    local md5_vector = M.md5("abc")
    return rc4_vector == "bbf316e8d940af0ad3"
       and md5_vector == "900150983cd24fb0d6963f7d28e17f72",
       rc4_vector,
       md5_vector
end

end)(S)
-- END crypto.lua

-- BEGIN storage.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local M = {}
S.Storage = M

M.KEY = "SPECTRA_WY_71438_CARD"

local function get_manager()
    local facade = rawget(_G, "Facade")
    return Runtime.safe_get(facade, "ConfigManager")
end

function M.get_string(key)
    local manager = get_manager()
    local fn = Runtime.safe_get(manager, "GetUserString")
    if type(fn) ~= "function" then
        return ""
    end
    local ok, value = pcall(fn, manager, key)
    if not ok or value == nil then
        return ""
    end
    return Runtime.trim(value)
end

function M.set_string(key, value)
    local manager = get_manager()
    local fn = Runtime.safe_get(manager, "SetUserString")
    if type(fn) ~= "function" then
        return false
    end
    return pcall(fn, manager, key, tostring(value or ""))
end

function M.get_card()
    return Runtime.normalize_card(M.get_string(M.KEY))
end

function M.set_card(card)
    return M.set_string(M.KEY, Runtime.normalize_card(card))
end

function M.clear_card()
    return M.set_string(M.KEY, "")
end

end)(S)
-- END storage.lua

-- BEGIN transport.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local M = {}
S.Transport = M

local state = Runtime.get_state()
state._s9 = type(state._s9) == "table" and state._s9 or {}
state._sa = type(state._sa) == "table" and state._sa or {}

local function http_downloader_body(value)
    local body = Runtime.bytes_to_string(value)
    if body == "" then
        return nil
    end
    return body
end

local function http_loader_body(payload, content_type)
    -- Baseline proto 0.16.1 reads only callback parameter R2 (the third
    -- parameter), first attempting payload[content_type], then the first table
    -- value, and finally passing that value to GetStringFromBytes. It does not
    -- scan status/request metadata arguments for a convenient string.
    local value = Runtime.safe_get(payload, content_type)
    if value == nil and type(payload) == "table" then
        for _, candidate in pairs(payload) do
            value = candidate
            break
        end
    end
    if value == nil then
        value = payload
    end

    local body = Runtime.bytes_to_string(value)
    if body == "" then
        return nil
    end
    return body
end

local function with_http_loader(tag, url, callback, previous_error)
    local ok_require, mod = pcall(require, "DFM.YxFramework.Managers.Resource.HttpLoader")
    local new_ins = ok_require and Runtime.safe_get(mod, "NewIns") or nil
    if type(new_ins) ~= "function" then
        callback(false, nil, "HttpLoader is unavailable; " .. tostring(previous_error or ""))
        return false
    end

    -- Baseline proto 0.16 invokes NewIns(module, "SPECTRA." .. tag).
    local ok_new, loader = pcall(new_ins, mod, "SPECTRA." .. tostring(tag))
    if not ok_new or loader == nil then
        callback(false, nil, "Failed to create HttpLoader; " .. tostring(previous_error or loader))
        return false
    end
    state._sa[tag] = loader

    local event = Runtime.safe_get(loader, "evtOnBatchComplete")
    local bind = Runtime.safe_get(event, "Bind")
    local request = Runtime.safe_get(loader, "RequestUrl")
    if type(bind) ~= "function" or type(request) ~= "function" then
        state._sa[tag] = nil
        local release = Runtime.safe_get(loader, "Release")
        if type(release) == "function" then pcall(release, loader) end
        callback(false, nil, "HttpLoader interface is incomplete")
        return false
    end

    local done = false
    local request_handle = nil
    local holder = {}

    local function finish(ok, body, err)
        if done then
            return
        end
        done = true
        state._sa[tag] = nil

        -- Baseline proto 0.16.0 explicitly unbinds the same callback/caller
        -- pair before releasing the loader.
        local unbind = Runtime.safe_get(event, "Unbind")
        if type(unbind) == "function" then
            pcall(unbind, event, holder.on_complete, holder)
        end

        local release = Runtime.safe_get(loader, "Release")
        if type(release) == "function" then
            pcall(release, loader)
        end
        callback(ok, body, err)
    end

    holder.on_complete = function(_, callback_request, payload)
        if done then return end
        -- Preserve the guard visible in baseline proto 0.16.1.
        if request_handle ~= nil and callback_request == request_handle then
            return
        end

        local content_root = rawget(_G, "EHttpContentType")
        local content_type = Runtime.safe_get(content_root, "String") or 1
        local body = http_loader_body(payload, content_type)
        if body == nil then
            finish(false, nil, "HttpLoader returned an empty response")
        else
            finish(true, body, nil)
        end
    end

    local ok_bind, bind_err = pcall(bind, event, holder.on_complete, holder)
    if not ok_bind then
        finish(false, nil, "Failed to bind HttpLoader callback: " .. tostring(bind_err))
        return false
    end

    local content_root = rawget(_G, "EHttpContentType")
    local content_type = Runtime.safe_get(content_root, "String") or 1
    local ok_start, start_result = pcall(request, loader, url, content_type)
    if not ok_start then
        finish(false, nil, "Failed to start HttpLoader: " .. tostring(start_result))
        return false
    end
    request_handle = start_result
    return true
end

function M.get(tag, url, callback)
    local import_fn = rawget(_G, "import")
    local mod = nil
    if type(import_fn) == "function" then
        local ok, result = pcall(import_fn, "HttpDownloader")
        if ok then mod = result end
    end

    local factory = Runtime.safe_get(mod, "HttpDownloader")
        or Runtime.safe_get(mod, "NewIns")
        or (type(mod) == "function" and mod or nil)

    if type(factory) ~= "function" then
        return with_http_loader(tag, url, callback, "HttpDownloader is unavailable")
    end

    local ok_new, downloader = pcall(factory)
    if not ok_new or downloader == nil then
        ok_new, downloader = pcall(factory, mod)
    end
    if not ok_new or downloader == nil then
        return with_http_loader(tag, url, callback,
            "Failed to create HttpDownloader: " .. tostring(downloader))
    end

    state._s9[tag] = downloader

    local success_event = Runtime.safe_get(downloader, "OnByteSuccess")
    local fail_event = Runtime.safe_get(downloader, "OnFail")
    local success_add = Runtime.safe_get(success_event, "Add")
    local fail_add = Runtime.safe_get(fail_event, "Add")
    local start = Runtime.safe_get(downloader, "StartDownLoadBytes")

    if type(success_add) ~= "function" or type(fail_add) ~= "function" or type(start) ~= "function" then
        state._s9[tag] = nil
        return with_http_loader(tag, url, callback, "HttpDownloader interface is incomplete")
    end

    local done = false
    local function complete(ok, body, err)
        if done then return false end
        done = true
        state._s9[tag] = nil
        callback(ok, body, err)
        return true
    end

    local function fallback_once(reason)
        if done then return false end
        done = true
        state._s9[tag] = nil
        return with_http_loader(tag, url, callback, reason)
    end

    local success_cb = function(value)
        if done then return end
        local body = http_downloader_body(value)
        if body == nil then
            fallback_once("HttpDownloader returned an empty response")
            return
        end
        complete(true, body, nil)
    end

    local fail_cb = function(...)
        if done then return end
        local args = {...}
        local reason = "HttpDownloader request failed"
        for i = #args, 1, -1 do
            if args[i] ~= nil and tostring(args[i]) ~= "" then
                reason = tostring(args[i])
                break
            end
        end
        fallback_once(reason)
    end

    local ok_success = pcall(success_add, success_event, success_cb)
    if not ok_success then ok_success = pcall(success_add, success_event, success_cb, downloader) end
    local ok_fail = pcall(fail_add, fail_event, fail_cb)
    if not ok_fail then ok_fail = pcall(fail_add, fail_event, fail_cb, downloader) end
    if not ok_success or not ok_fail then
        return fallback_once("Failed to bind HttpDownloader callbacks")
    end

    local ok_start, start_err = pcall(start, downloader, url)
    if not ok_start then
        return fallback_once("Failed to start HttpDownloader: " .. tostring(start_err))
    end
    return true
end

end)(S)
-- END transport.lua

-- BEGIN payload_embed.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

-- Exact Base64 fragments extracted from baseline root constants K35..K835.
-- Do not edit these fragments if byte-identical payload preservation is required.
S.PayloadBase64Chunks = {
    "G0x1YVMAGZMNChoKBAQECAh4VgAAAAAAAAAAAAAAKHdAASbnqbfpgJTpmYzot68gICAgICAgIF/lhajmlrDlr6vms5UubHVhAAAAAAAAAAAAARV/AAAAJgUAACUFgAAmBQAAKABAAGhAQABpgMAAGQABAe0AAAAowUAAYwEBABmBAAFowUAAo",
    "0EBAFmBAAGowUAA44EBAJmBAAHowUAAI8IBANmBAAEowkAAYwICABmCAAFowkAAo0ICAFmCAAGogkIA48ICAJmCAAHpAkMF2YKAACEDAADsAIOGIUMAAOwAA4chgwAA7ACDhyHDAADsAAOIIQMBAOwAg4ghQwEA7AADiSGDAQDsAIOJIcMBAO",
    "wAA4ohAwIA7ACDiiFDAgDsAAOLIYMCAOwAg4shwwIA7AADjCEDAwDsAIOMIUMDAOwAA40hgwMA7ACDjS0DgANoQ0cAaYPHBqhDRwCpw0cH6ENHAOkDyAcoREcAKURICGhERwBphMgIqERHAKnESAnoREcA6QTJCSBDgAPsAAOOLQMAAmhDRwB",
    "pg8kGqENHAKnDSQfoQ0cA6QPKByhERwApREoIIEMAAuwAg5IhwwMA7AADlSEDBADsAIOVIUMEAOwAA5YhgwQA7ACDliHDBADsAAOXIQMFAOwAg5chQwUA7AADmCGDBQDsAIOYIcMFAOwAA5ktAwAAYQMGAOxAg5lhQwYA7EADmm0DAAChgwYA",
    "7ICDmqHDBgDsgAOboQMHAOyAg5uhQwcA6ANOAAAEAAdoRE4ApgSAANmDgALbAAABGwCAADoAAAAEEEdlbkxvY2FsTG9nRnVuYwQQRUx1YUxvZ0NhdGVnb3J5BA9MdWFNQXJtZWRGb3JjZQQIcmVxdWlyZRQuREZNLlN0YW5kYWxvbmVMdWEuQ",
    "nVzaW5lc3NUb29sLkl0ZW1IZWxwZXJUb29sFDlERk0uU3RhbmRhbG9uZUx1YS5CdXNpbmVzc1Rvb2wuU3RydWN0VG9vbC5JdGVtQ29uZmlnVG9vbBQ9REZNLlN0YW5kYWxvbmVMdWEuQnVzaW5lc3NUb29sLlN0cnVjdFRvb2wuV2VhcG9uQX",
    "NzZW1ibHlUb29sFDBERk0uU3RhbmRhbG9uZUx1YS5CdXNpbmVzc1Rvb2wuV2VhcG9uSGVscGVyVG9vbBQ3REZNLlN0YW5kYWxvbmVMdWEuQnVzaW5lc3NUb29sLlN0cnVjdFRvb2wuSXRlbUJhc2VUb29sFE1ERk0uQnVzaW5lc3MuTW9kdWx",
    "lLkFybWVkRm9yY2VNb2R1bGUuTG9naWMuQXJtZWRGb3JjZS5Bcm1lZEZvcmNlRXhwaXJlZExvZ2ljBAdpbXBvcnQEEEFtbW9EYXRhTWFuYWdlcgQER2V0BCRDaGVja0VxdWlwbWVudEJlZm9yRW50ZXJHYW1lUHJvY2VzcwQOX0NoZWNrUHJv",
    "Y2VzcwQVX0NoZWNrRXF1aXBtZW50VmFsdWUEFUdldEFsbEVxdWlwbWVudFZhbHVlBA9fQ2hlY2tNZWRpY2luZQQWX0NoZWNrVW5DYXJyeU1lZGljaW5lBBBfQ2hlY2tDb250YWluZXIEDV9DaGVja0J1bGxldAQRX0NoZWNrRHVyYWJ1bGl0e",
    "QQUQ2hlY2tFcXVpcFNsb3RFbXB0eQQUQ2hlY2tFcXVpcFNsb3RWYWx1ZQQcRHluYW1pY0d1aWRQcmljZUZpbmlzaEZldGNoBBZDaGVja1JhaWRCdWxsZXRFbm91Z2gEHkdldE1hdGNoQnVsbGV0TnVtQnlXZWFwb25JdGVtBBFfQ2hlY2tOaW",
    "dodEZpZ2h0BA5FcXVpcFR5cGVMaXN0BApFU2xvdFR5cGUED01haW5XZWFwb25MZWZ0BBBNYWluV2VhcG9uUmlnaHQECFBpc3Ryb2wEDEJyZWFzdFBsYXRlBAdIZWxtZXQEDUNoZXN0SGFuZ2luZwQEQmFnBBJDb250YWluZXJUeXBlTGlzdAQ",
    "WQ2hlc3RIYW5naW5nQ29udGFpbmVyBAdQb2NrZXQEDUJhZ0NvbnRhaW5lcgQRU2FmZUJveENvbnRhaW5lcgQoX0NoZWNrUGxheWVyU3VwcGxpZXNGb3JOaWdodFNwZWljYWxUeXBlBBtfQ2hlY2tTYWZlQm94RXhwaXJlZFN0YXR1cwQcX0No",
    "ZWNrS2V5Q2hhaW5FeHBpcmVkU3RhdHVzBBhfQ2hlY2tQcm9wRXhwaXJlZFN0YXR1cwQbQ2hlY2tQbGF5ZXJCb2R5SXRlbXNCeUxpc3QEHENoZWNrTmlnaHRWaXNpb25MaW1pdEJ5TGlzdAQfQ2hlY2tUaGVybWFsSW1hZ2luZ0xpbWl0QnlMa",
    "XN0BCFDaGVja1BsYXllckJvZHlJdGVtc0VudHJ5UXVhbGl0eQQYQ2hlY2tSZW50YWxDb25zdW1hYmxlSUQEHl9DaGVja1Byb3BpbmZvRG93bmxvYWRXaXRoTG9nBB5fQ2hlY2tJdGVtV2l0aENvbXBzRG93bmxvYWRlZAQXX0NoZWNrSXRlbU",
    "lkRG93bmxvYWRlZAQeX0NoZWNrQWxsV2VhcG9uUGFydERvd25sb2FkZWQEG0dldE5lZWREb3dubG9hZENhdGVnYXJ5S2V5BAZwY2FsbAQDX0cBAAAAAQAeAAAAAAsAAAARAAAAAAAFIwAAACYBAAAlAYAAJgEAACgAQAApQEAAAYBAAKgAQAC",
    "pQEABgcBAAZkAAAEZgAAAF0AAABPAAYAoAEAAKUBAAAHAQAAZgAABaABBAGlAwQAUQAAAEwADgCiAQQApwEEAKQBCAAFAQgAZQAABKIDCABlAgAAogEEAKcBBACnAQgApAEMAAUBDABlAAAEbAIAADgAAAAQHRmFjYWRlBBBHYW1lRmxvd01h",
    "bmFnZXIEEUNoZWNrTWFpbkZsb3dTT0wEE0dldEN1cnJlbnRHYW1lRmxvdwQTRUdhbWVGbG93U3RhZ2VUeXBlBAZMb2JieQQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQYUmVzZXRFcXVpcEFibm9ybWFsRGF0YXMEDl9DaGVja1Byb2Nlc",
    "3MEB0NvbmZpZwQYZXZ0RXF1aXBBYm5vcm1hbENoYW5nZWQEB0ludm9rZQIAAAAAAAEDAAAAAAAAAAAAAAAAAAAAAAASAAAAHgAAAAAAAx0AAACmAAAApQCAAKYAAAAoAEAAGUCAAChAQAAZQIAAKIBAABlAgAAowEAAGUCAACgAQQAZQIAAKE",
    "BBABlAgAAogEEAGUCAACjAQQAZQIAAKABCABlAgAAoQEIAGUCAACiAwgApwEIAKQBDAAFAQwAZQAABGwCAAA4AAAAEDV9DaGVja0J1bGxldAQRX0NoZWNrRHVyYWJ1bGl0eQQQX0NoZWNrQ29udGFpbmVyBA9fQ2hlY2tNZWRpY2luZQQVX0N",
    "oZWNrRXF1aXBtZW50VmFsdWUEEV9DaGVja05pZ2h0RmlnaHQEGENoZWNrUmVudGFsQ29uc3VtYWJsZUlEBBtfQ2hlY2tTYWZlQm94RXhwaXJlZFN0YXR1cwQcX0NoZWNrS2V5Q2hhaW5FeHBpcmVkU3RhdHVzBBhfQ2hlY2tQcm9wRXhwaXJl",
    "ZFN0YXR1cwQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQSU29ydEVxdWlwQWJub3JtYWwCAAAAAQMAAAAAAAAAAAAAAAAAAAAAAAAAHwAAADQAAAAAAApaAAAAZgIAAGUCgABmAgAAKABAABmAgABoQMAAaYDAAEHAwABZwAAB6ADBAOlAw",
    "QHpgMEBwcDBAWgBwQBpQcECaQHCAmlBwgJpgcICo8ECANmAAALXAAAAE4AGgCkBwwEXAQAAE8AFgFTAwgATQAWAFUAAABPABIAoAcEAKUFBAimBQQIBQUMCrQEBAOmBwwGswQGH6AHBAOlBwQPpAcID6UHCA+mBwgOswYGH6UHEAazBAYjtgQ",
    "AA7EGAiewBAIqswQGJGUGAASgBwQApQUECKYFBAgHBQQKoAcEAqUFBA6kBQgOpQUIDqUFFA+PBAgAZgQACFwEAABOABoBpAUMCVwEAABPABYBUwEIBE0AFgBUAAAETwASAaAHBAGlBwQJpgcECQUHDAu0BAQApgkMC7AEChygCwQApQkEEKQJ",
    "CBClCQgQpQkUE7AGChylCRALsAQKILYIAACyCgIksAgCK7AECiVlBgAEbAIAAFgAAAAQVR2V0QWxsRXF1aXBtZW50VmFsdWUEB1NlcnZlcgQPR2FtZU1vZGVTZXJ2ZXIEEEdldE1hcE5lZWRWYWx1ZQQHTW9kdWxlBAtBcm1lZEZvcmNlBAZG",
    "aWVsZAQWR2V0RXF1aXBtZW50Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEG0VxdWlwbWVudEFsbFZhbHVlTm90RW5vdWdoEwAAAAAAAAAABAdzd2l0Y2gEEUFkZEVxdWlwQWJub3JtYWwEBGtleQQNYWJub3JtYWxUeXBlBARsb",
    "2MEDWFibm9ybWFsRGVzYwQGcGFyYW0ECm5lZWRWYWx1ZQQMY3VyQWxsVmFsdWUEGUVxdWlwbWVudEFsbFZhbHVlRXhjZWVkcwIAAAABAwAAAAAAAAAAAAAAAAAAAAAAAAA1AAAAVgAAAAAAC2UAAACmAgAApQKAAKYCAAAnAAAAYwAAABlAAA",
    "EjQAAAaIDAAGnAwABBAMEAWYAAAVcAAAATwACAaEDBAGmAwQBXQAAAE0AAgGhAwQBpwMEAqADCAKlAQgGBgEIBmYAAAZcAAAATgAWAqADCAKlAQgGBwEIBmYAAAZcAAAATwAKAKQBDAecAAAAoQcMAKYFDAmPBAwCpAUQB6UFEASmCRAFAAgA",
    "AGQEAA9lAAAATgAqA5wAAASPBBADZQAABI0AAABNACYCtAIAD6ADFAOlAxQEoAcUAKYFFAmgBxQBpwcUCqAHFAKkBRgPoAcUA6UHGAygCxQApgkYEaALFAGnCxgSgQIAD6ADHAAABAAHZAAEBE8AAgChCxwFAAoADGYIAAQIAAgDegAAAX0H+",
    "f+gAwgDpQMIBwYDHAdmAAAEnAQAAaEHDAGmBwwKjwQcAwAGAAQACAABZAQACGUEAAKcAAADjAAgAmUAAAaiAwACpQEgBqYBIAanASAGBAEkBAAEAAEABgACZQAACgAAAAMAAgACbAIABGwCAACUAAAAUZ0NoZWNrRXF1aXBMb2dpYy5HZXRBb",
    "GxFcXVpcG1lbnRWYWx1ZSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBTVEFSVCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PRMAAAAAAAAAAAQHTW9kdWxlBBJMb2JieVNPTENoYWxsZW5nZQQYQ2hlY2tJblNPTENoYWxsZW",
    "5nZU1vZGUEFEVDdXJyZW5jeUNsaWVudFR5cGUEEVNPTENoYWxsZW5nZUNvaW4EC09ubHlVbkJpbmQEB1NlcnZlcgQRQXJtZWRGb3JjZVNlcnZlcgQUQ2hlY2tJc1JlbnRhbFN0YXR1cwQRR2V0Q3VyUmVudGFsUGxhbgQNcHJlc2V0X3ByaWN",
    "lBAdzdHJpbmcEB2Zvcm1hdBSGQ2hlY2tFcXVpcExvZ2ljLkdldEFsbEVxdWlwbWVudFZhbHVlIOOAkElzUmVudGFsU3RhdHVz44CRcmVzdWx0ID09PiBjb25zdW1hYmxlX2lkID0gJXMsIHR5cGVfaWQgPSAlcywgcHJlc2V0X2lkID0gJXMs",
    "IHRvdGFsVmFsdWUgPSAlcwQOY29uc3VtYWJsZV9pZAQIdHlwZV9pZAQKcHJlc2V0X2lkFFBDaGVja0VxdWlwTG9naWMuR2V0QWxsRXF1aXBtZW50VmFsdWUgSXNSZW50YWxTdGF0dXMgYnV0IGN1clJlbnRhbFBsYW4gaXMgbmlsISEhBApFU",
    "2xvdFR5cGUEB0hlbG1ldAQMQnJlYXN0UGxhdGUEDUNoZXN0SGFuZ2luZwQEQmFnBA9NYWluV2VhcG9uTGVmdAQQTWFpbldlYXBvblJpZ2h0BAhQaXN0cm9sBAZwYWlycwQUQ2hlY2tFcXVpcFNsb3RWYWx1ZQQSR2V0Q3VyU2xvdEdyb3VwSW",
    "QUSENoZWNrRXF1aXBMb2dpYy5HZXRBbGxFcXVpcG1lbnRWYWx1ZSDjgJAlc+OAkXJlc3VsdCA9PT4gdG90YWxWYWx1ZSA9ICVzFGVDaGVja0VxdWlwTG9naWMuR2V0QWxsRXF1aXBtZW50VmFsdWUgPT09PT09PT09PT09PT09PT09PT09PT0",
    "9PT09PT0gRU5EID09PT09PT09PT09PT09PT09PT09PT09PT09PT09BAtBcm1lZEZvcmNlBAdDb25maWcEHGV2dEFsbEVxdWlwbWVudFZhbHVlQ2hhbmdlZAQHSW52b2tlBAAAAAEBAAABAgEDAAAAAAAAAAAAAAAAAAAAAABXAAAAZQAAAAAA",
    "CjkAAABmAgAAZQKAAGYCAAAoAEAAKUBAACmAQAABwEAAGYAAAWgAwQCoQEEAqYBBAejAQQCZgAABwAAAAFmAgAFXAAAAE4AJgKkAwgCRAAABFYCAhBOACICoQEEAqYBCAenAwgAoAUMAKUFDAimBQwKZgIAB6ABAAOlAwAHpgMABwcDDAW0BA",
    "QCpAcQAbIEBiKgBQACpQUADqYFEA6nBRAOpAUUDbIGBiKiBRQCpwUUD6AFAAOlBwAPpgcQD6UHDA+kBxgMAAgABmYGAAWyBgYqtQQAA6QHCAKzBAY1sgYGM2UCAARsAgAAbAAAABAdNb2R1bGUEC0FybWVkRm9yY2UEBkZpZWxkBBBHZXRNZW",
    "RpY2luZVR5cGUEFl9DaGVja1VuQ2FycnlNZWRpY2luZQQGdGFibGUEB3ZhbHVlcwQYRURpc3BlbnNpbmdNZWRpY2luZVR5cGUEGXVuQ2FycnlNZWRpY2luZXNUeXBlTGlzdBMAAAAAAAAAAAQHY29uY2F0BBx1bkNhcnJ5TWVkaWNpbmVzVHl",
    "wZVN0ckxpc3QEDUNvbW1vbkNvbmZpZwQETG9jBAZDb21tYQQRQWRkRXF1aXBBYm5vcm1hbAQEa2V5BA1hYm5vcm1hbFR5cGUEB0NvbmZpZwQORUFibm9ybWFsVHlwZQQNTGFja01lZGljaW5lBARsb2MEB3N0cmluZwQHZm9ybWF0BBhVbmFi",
    "bGVUb1Jlc29sdmVUaGVTdGF0ZQQGcGFyYW0EEWFibm9ybWFsVHlwZUxpc3QCAAAAAAABAwAAAAAAAAAAAAAAAAAAAAAAZgAAAHUAAAACAA04AAAAJgMAACUDgAAmAwAArcAAAKxAQIDtAAAArMAAge0AAACswICB6ABBAAABAADZAAEBE4AJg",
    "ChCQQApgkEEKcJBBAECQgSoQkEAqYJBBalCQgWpgkIFqcJCBcACgAMZggACFwIAABNABoBpAkMEVwIAABOABYBoQkMAaYLDBIACgADAAoADWYKAAVdCAAATwAOAaMJDAGkCxASpAkAB6QJABFmCgAGsQAKAaEJDAGlCxASpgkABwAKAA1lCgA",
    "FoQkMAaULEBKnCQAHpgkQEWUKAAd6AAABfgfV/mwAAARsAgAATAAAABARrZXkTAAAAAAAAAAAEGXVuQ2FycnlNZWRpY2luZXNUeXBlTGlzdAQcdW5DYXJyeU1lZGljaW5lc1R5cGVTdHJMaXN0BAdpcGFpcnMEB01vZHVsZQQLQXJtZWRGb3J",
    "jZQQGRmllbGQEFkdldEVxdWlwbWVudENoZWNrRGF0YQQHQ29uZmlnBA5FQWJub3JtYWxUeXBlBA1MYWNrTWVkaWNpbmUEB3N3aXRjaAQGdGFibGUECWNvbnRhaW5zBAVtYXRoBARtYXgEB2luc2VydAQNYWJub3JtYWxEZXNjAQAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAB2AAAArAAAAAAAD8oAAACmAwAApQOAAKYDAAAhAAAAaABAAGlAwABpgMAAQcDAAOgAQADpQMAB6QDBAelAwQHpgMEBI8EBAFmAAAKjwAEA48ABACgBQgApQUICAYFCAhmBAAFoAUIAacHCAkEBwwLoQUMA6YHDAwACA",
    "AJZgQACgcHDApmBAAGCAUQDgoABAYFBxAKZgQABggFEA8KAgQGBgcQCmYEAAcABAAAAAgAD2UEAAegBQgDpwcIDwQHDA2hCQwBpwsQEgAIAAtmBAAJAAYADwcHDAtmBAAHCAcQDgsABAcFBxALZgQABwgHEA8LAgQHBgcQC2YEAAYABgAPAAQ",
    "AAAAIAA9lBAAHoAUIA6cHCA8EBwwNoQkMAaQLFBIACAALZgQACQAGAA8HBwwLZgQABwgHEA4LAAQHBQcQC2YEAAcIBxAPCwIEBwYHEAtmBAAGAAYADwAEAAAACAAPZQQABVwAAABNACoDpQcUA1wEAABOACYDpgcUAFsCBgxPACIDowUUA6QH",
    "GAweCgAHZgQABKMJFACkCRgRpgsUAGYIAARUAggMTQAaA6AFAAOlBwAPpgcADwUHGA20CAQCpgsYAbIICjagCQACpQkAFqQJBBalCQQWpgkEFbIKCjahCRwCpgkcF6cLHACjDRQApA0gGaYPFAERDyAYZAwABmYIAAGyCAo6tAgAAbIICkdlB",
    "gAHoAUAA6cHIA8EByQPZgQAB1wEAABPAAIDoQUkA6YHJA9dBAAATQACA6EFJAOnByQMoAkIAKcJCBAECQwSoQkMAqQJKBcACgAMZggACQAEABAFCygIZggABaAJAAGlCwARpgsAEQcLABOgCQADpQsAF6QLBBelCwQXpgsoFI8MBAFmCAAJAA",
    "IAEVwAAABNAB4BpQsUAVwIAABOABoBpgsUAFkCCgxPABYBowkUAaQLIBKmCxQBZggABFQCCBBNABIBoAkAAaULABGmCwARBQsYE7QIBACmDxgDsAgONKANAAClDQAYpA0EGKUNBBimDSgbsAoONKcPHAOwCA44tAwAA7AIDkVlCgAFBgsQCWY",
    "IAAYABgARAAgAAgAIAA1lCAAEbAIAAKwAAAAQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQWR2V0RXF1aXBtZW50Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEFFN0b3JhZ2VTcGFjZUlzVGlnaHQTAAAAAAAAAAAEB1NlcnZ",
    "lcgQRQXJtZWRGb3JjZVNlcnZlcgQSR2V0Q3VyU2xvdEdyb3VwSWQEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQKRVNsb3RUeXBlBBZDaGVzdEhhbmdpbmdDb250YWluZXIEEUdldFRvdGFsQ2FwYWNpdHkDje21oPfGsD4EFkdldFJlbWFp",
    "bmluZ1NwYWNlU2l6ZQQJR2V0SXRlbXMEDUJhZ0NvbnRhaW5lcgQHUG9ja2V0BAdzd2l0Y2gEC2NoZWNrVmFsdWUECU1hdGhVdGlsBBRHZXRUaGVTZWNvbmREZWNpbWFsBBFBZGRFcXVpcEFibm9ybWFsBARrZXkEDWFibm9ybWFsVHlwZQQEb",
    "G9jBAdzdHJpbmcEB2Zvcm1hdAQNYWJub3JtYWxEZXNjBA9HZXRSb3VuZGluZ051bRNkAAAAAAAAAAQGcGFyYW0EEkxvYmJ5U09MQ2hhbGxlbmdlBBhDaGVja0luU09MQ2hhbGxlbmdlTW9kZQQLRVNsb3RHcm91cAQNU09MQ2hhbGxlbmdlBA",
    "dQbGF5ZXIEEVNhZmVCb3hDb250YWluZXIEEEdldFVzZWRDYXBhY2l0eQQUSGFzVW5uZWNlc3NhcnlJdGVtcwEAAAAAAAEAAAAAdwAAAIIAAAABAAsgAAAApgIAAKUCgACmAgAAFwAAABNABoBoAEAAgAAAAFkAAQETwASAqUHAAuiBQADpwcA",
    "DFMABAxOAA4CBAcECKEJBACmCQQSZgYABlwEAABMAAoDpwUED1wEAABNAAYDoAUIA6UHCA+mBwgPBwcIDacJBA9lBgAFegAAA30D6fxsAgAAMAAAABAZwYWlycwQNaXRlbU1haW5UeXBlBApFSXRlbVR5cGUECU1lZGljaW5lBAtHZXRGZWF0",
    "dXJlBA1FRmVhdHVyZVR5cGUEB0hlYWx0aAQNbWVkaWNpbmVUeXBlBAdNb2R1bGUEC0FybWVkRm9yY2UEBkZpZWxkBBBBZGRNZWRpY2luZVR5cGUBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK0AAAD6AAAAAAAXlQAAAKYFA",
    "AClBYAApgUAACMAAABoQEAAaYDAAEHAwABZgAABoQAAAMAAAAEoAUEAKUFBAtlAAQHAAQABKAJBACmCQQTZQQEBwAIAASgDQQApw0EG2UIBAeYDAAAtBAAAbQQAANdAAAATgAqA10EAABMACoCoBEIAqURCCcAEAAgoBUEAKUVBCplEgAGoBE",
    "IAqURCCcAEAAgoBUEAKYVBCplEgAEUAAICE8ABgKgEQgCpREIJwASACCiFQgBABQADGQUAAZlEAAATQAyA10AAABOAAYCoBEIAqURCCcAEgAgohUIAQAUAAxkFAAGZRAAA10EAABOACYCoBEIAqURCCcAEgAgohUIAQAUABRkFAAGZRAAAE4A",
    "HgNdAAAATQAOAqARCAKlEQgnABAAIKAVBAClFQQqZRIABqARCAKlEQgnABIAIKIVCAEAFAAMZBQABmUQAABOAA4DXQQAAEwADgKgEQgCpREIJwAQACCgFQQAphUEKmUSAAagEQgCpREIJwASACCiFQgBABQAFGQUAAZlEAADXQgAAEwADgKgE",
    "QgCpREIJwAQACCgFQQApxUEKmUSAAagEQgCpREIJwASACCiFQgBABQAHGQUAAZlEAACoBEIAqcRCCcAEAAiZhAABl0QAABPAAYCoBEIAqQRDCcAEgAgoRUMAKYVDCinFQwqZhIABwAMACdcDAAATAASAqAREAKlERAmphEQJgcRECS0FAQAsB",
    "QCKaAVEAGlFxApphcUKacXFCmkFxgosRYWKLMWDjG1FAABsBYSNLEUFjZlEgAEbAIAAHAAAABMAAAAAAAAAAAQHU2VydmVyBBFBcm1lZEZvcmNlU2VydmVyBBJHZXRDdXJTbG90R3JvdXBJZAQKRVNsb3RUeXBlBA9NYWluV2VhcG9uTGVmdA",
    "QQTWFpbldlYXBvblJpZ2h0BAhQaXN0cm9sBAZ0YWJsZQQHaW5zZXJ0BAl0b3N0cmluZwQIaXNlbXB0eQQHY29uY2F0BA1Db21tb25Db25maWcEBExvYwQGQ29tbWEEB01vZHVsZQQLQXJtZWRGb3JjZQQGRmllbGQEEUFkZEVxdWlwQWJub3J",
    "tYWwEBGtleQQNYWJub3JtYWxUeXBlBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEC0xhY2tCdWxsZXQEBGxvYwQGcGFyYW0EEWFibm9ybWFsVHlwZUxpc3QFAAAAAAABBAEAAQMBAgEAAAAAsAAAANAAAAABAA5ZAAAAZgMAAGUDgABmAwAAaABA",
    "AGlAwABBgMAAwAAAACcBgABZgAACgcDAAJmAAAGXAAAAEwASgOgAQQEpQUEB2YAAASiBQQApwUECKQFCAgFBQgKogUEAqcFBA6mBQgOpwUIDqQFDA8ABgAEZgQACFwEAABNADYBpQUMCVwEAABOADIBogUMAacHDAqkBRAJZgQABFkCBiBNAC",
    "YCnAYAB44EEAAACgAJjwgQAqQJEAplBgAKoAUUCwAEAAScCgACZgYABFUABAxOABYDtgQAAKIJFACnCRQQpwgAE7AGCiuxBAYwoQkYAKYJGBGnCRgKAAoADGYKAAWgCRwBpQscEpwKAAumCRwJZgoABawKAAmUCAACAAoABw0IBAwADAARbAo",
    "ACE4ADgOUBgADbAQABE8ACgKcBAAPjwQcAAAKAAZlBgAGlAYAAmwEAARMAAYBlAYAAWwEAARNAAIDlAIAA2wAAARsAgAAgAAAABAdTZXJ2ZXIEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQNR2V0RXF1aXBJdGVtBA9HZXRTdWJUeXBlQnl",
    "JZAQDaWQEB01vZHVsZQQLQXJtZWRGb3JjZQQGRmllbGQEFkdldEVxdWlwbWVudENoZWNrRGF0YQQHQ29uZmlnBA5FQWJub3JtYWxUeXBlBAtMYWNrQnVsbGV0BAdzd2l0Y2gECU1hdGhVdGlsBA9HZXRSb3VuZGluZ051bQQLY2hlY2tWYWx1",
    "ZRMAAAAAAAAAAAQVW0RlYnVnXSBHZXQgVmFsdWUgPSAEDmNoZWNrVmFsdWUgPSAEHkdldE1hdGNoQnVsbGV0TnVtQnlXZWFwb25JdGVtBAtCdWxsZXROYW1lBAtJdGVtQ29uZmlnBBdNYXBXZWFwb25JdGVtVHlwZTJOYW1lBApCdWxsZXROd",
    "W0EC1N0cmluZ1V0aWwEEVBsdXJhbFRleHRGb3JtYXQEDWFibm9ybWFsRGVzYwQFbWF0aAQEbWF4BARrZXkUOUNoZWNrRXF1aXBMb2dpYy5fQ2hlY2tCdWxsZXQgY2hlY2tWYWx1ZSDlsI/kuo4w77yB77yB77yBBwAAAAAAAQEAAQACAAMBAA",
    "AEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7AAAAMgEAAAAAD1IAAACmAwAApQOAAKYDAAAjAAAAaEBAAGmAwABBwMAAWYAAAaEAAADAAAABKAFBAClBQQLZwAABQAEAAagBQQCpgUEDWcEAAeYBAAAtAgAAbQIAANdAAAATAAOAqMJ",
    "BAKkCQgXAAoAEKANBAClDQQaZQoABqMJBAKkCQgXAAgAEKENCAEADAAIZAwABmUIAAFdBAAATAAOAqMJBAKkCQgXAAoAEKANBACmDQQaZQoABqMJBAKkCQgXAAgAEKENCAEADAAMZAwABmUIAANcAAAATQACAV0EAABPAAYCowkEAqYJCBcAC",
    "AAQow0IAKQNDBilDQwaZgoABwAEABdcBAAATAASAqIJDAKnCQwWpAkQFgUJEBS0DAQAsAwCJaINDAGnDwwZpA8UGaUPFBmmDxQYsQ4OJLMOBi21DAABsQ4KMLEMDjJlCgAEbAIAAGgAAABMAAAAAAAAAAAQHU2VydmVyBBFBcm1lZEZvcmNlU",
    "2VydmVyBBJHZXRDdXJTbG90R3JvdXBJZAQKRVNsb3RUeXBlBAdIZWxtZXQEDEJyZWFzdFBsYXRlBAZ0YWJsZQQHaW5zZXJ0BAl0b3N0cmluZwQHY29uY2F0BA1Db21tb25Db25maWcEBExvYwQGQ29tbWEEB01vZHVsZQQLQXJtZWRGb3JjZQ",
    "QGRmllbGQEEUFkZEVxdWlwQWJub3JtYWwEBGtleQQNYWJub3JtYWxUeXBlBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEF0luc3VmZmljaWVudER1cmFiaWxpdHkEBGxvYwQGcGFyYW0EEWFibm9ybWFsVHlwZUxpc3QCAAAAAAABAgEAAAAA/gA",
    "AABkBAAABAA1hAAAAJgMAACUDgAAmAwAAaABAAGlAwABBgMAAwAAAACcBgABZgAACgcDAAJmAAAGXAAAAEwAUgMEAQQFoQUEAaYHBAtmAgAHXAAAAEwATgAHBwQEZgQABF0EAABPAAIABAcIBGYEAARcBAAATABGAKEFCACmBQgIpwUICAQFD",
    "AqhBQgCpgUIDqUFDA6mBQwOpwUMDwAEAABmBAAIXAQAAE4AMgGkBRAJXAQAAE8ALgGlBRAIWQAGJE0AJgFcBAAATAAiAqMFEAKkBRQPBQcUB2QEAAZmBAADowUQA6QHFAwACgALZgQABFsABAxNABYCogUUAqcFFA+cBAAEpAkYCmYGAAasBA",
    "AGlAQAA6EFGAOmBxgMpwkYCaEJCAGkCxwRpQsMEaULHBGkCgASowkQAqYJHBcTCxwKZAgAB2QEAAJsBAAATgAOApQGAAJsBAAETwAKApwGAAeMBCAAAAgAAmUGAAaUBgACbAQABEwABgGUBgABbAQABE0AAgOUAgADbAAABGwCAACEAAAAEB1",
    "NlcnZlcgQQSW52ZW50b3J5U2VydmVyBAhHZXRTbG90BA1HZXRFcXVpcEl0ZW0EC0dldEZlYXR1cmUEDUVGZWF0dXJlVHlwZQQKRXF1aXBtZW50BAlJc0hlbG1ldAQOSXNCcmVhc3RQbGF0ZQQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQ",
    "WR2V0RXF1aXBtZW50Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEF0luc3VmZmljaWVudER1cmFiaWxpdHkEB3N3aXRjaAQLY2hlY2tWYWx1ZRMAAAAAAAAAAAQJTWF0aFV0aWwEFEdldFRoZVNlY29uZERlY2ltYWwEFUdldER1",
    "cmFiaWxpdHlQZXJjZW50BAVtYXRoBARtYXgEBGtleQQHc3RyaW5nBAdmb3JtYXQEDWFibm9ybWFsRGVzYwQKSW52ZW50b3J5BBBTbG90TmFtZU1hcHBpbmcED0dldFJvdW5kaW5nTnVtE2QAAAAAAAAAFD1DaGVja0VxdWlwTG9naWMuX0NoZ",
    "WNrRHVyYWJ1bGl0eSBjaGVja1ZhbHVlIOWwj+S6jjDvvIHvvIHvvIEEAAAAAAABAQEAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADMBAAA8AQAAAQAHGAAAAKYBAAClAYAApgEAAGgAQABpQMAAQYDAAFmAAAGoAEAAqcBAAYEAQQ",
    "EAAQAAQAGAAJmAAALBQEEB2YAAAddAAAATgACAJQGAABsBAAETgACAJQEAAEABgAEbAYABGwCAAAYAAAAEB1NlcnZlcgQRQXJtZWRGb3JjZVNlcnZlcgQSR2V0Q3VyU2xvdEdyb3VwSWQEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQNR2V",
    "0RXF1aXBJdGVtAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AQAASQEAAAEADDAAAADmAgAA5QKAAOYCAABoAEAAaUDAAEGAwABZgAABqABAAKnAQAGBAEEBAAEAAEABgACZgAACwUBBAdmAAAHXQAAAE0ACgCcBgABogUEAacHBAqMBAgDAAQAA",
    "WQGAARlBAAAjQQIAGwEAARPABIAoAUAAKYFCAgHBQgKAAYAB5gGAAGUCAAAZgQADZwGAAKiBQQCpwUED4wEDAAACAABpQsMBgAIAApkBgAJZQQAAWEEAAhMAAIBjQQIAWwEAARsAgAAOAAAABAdTZXJ2ZXIEEUFybWVkRm9yY2VTZXJ2ZXIEE",
    "kdldEN1clNsb3RHcm91cElkBBBJbnZlbnRvcnlTZXJ2ZXIECEdldFNsb3QEDUdldEVxdWlwSXRlbQQHc3RyaW5nBAdmb3JtYXQUVUNoZWNrRXF1aXBMb2dpYy5HZXRBbGxFcXVpcG1lbnRWYWx1ZSBFcXVpcCA9PT4gc2xvdCA9ICVzLCBlcX",
    "VpcE5hbWUgPSBuaWwsIHByaWNlID0gMBMAAAAAAAAAAAQLU2hvcFNlcnZlcgQlR2V0U2hvcFNpbmdsZUR5bmFtaWNHdWlkZVByaWNlQnlJdGVtFFVDaGVja0VxdWlwTG9naWMuR2V0QWxsRXF1aXBtZW50VmFsdWUgRXF1aXAgPT0+IHNsb3Q",
    "gPSAlcywgZXF1aXBOYW1lID0gJXMsIHByaWNlID0gJXMEBW5hbWUCAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAASgEAAE4BAAABAAYaAAAAZgEAAGUBgABmAQAAaABAAGlAwABBgMAA6ABAAOlAwAHBwMAB2QAAAVmAAABXQAAAE8ABgGgAQABp",
    "QMAAQcDAAFmAAAGoAEEAqUBBARSAgAATwACAFwAAABNAAIBogMEAWUCAABsAgAAHAAAABAdGYWNhZGUEEEdhbWVGbG93TWFuYWdlcgQRQ2hlY2tNYWluRmxvd1NPTAQTR2V0Q3VycmVudEdhbWVGbG93BBNFR2FtZUZsb3dTdGFnZVR5cGUEB",
    "kxvYmJ5BBVfQ2hlY2tFcXVpcG1lbnRWYWx1ZQIAAAAAAAEDAAAAAAAAAAAAAAAAAAAAAABPAQAAewEAAAEADiwAAABmAwAAZQOAAGYDAAAXQAAAE8AAgGcAAACjAAAAWUAAARsAgABtAIABqEDAAKmAQAHoQMAA6cDAAShBwAApAUECYECAAa",
    "UAAADtAAAAKEHBACmBQQIBwUECGYEAAWEBAACoAcIAwAGAAJkBAQETgACAwAKAAgADAAXZQgABnoEAAB+C/n+nAYAB6EHCAOmBwgMjwgIAQAIAAdkBgAGZQQAAgAEAAcABgAGbAYABGwCAAAwAAAAUOUNoZWNrRXF1aXBMb2dpYy5DaGVja1J",
    "haWRCdWxsZXRFbm91Z2ggbWF0Y2hNb2RlSUQgaXMgbmlsBApFU2xvdFR5cGUED01haW5XZWFwb25MZWZ0BBBNYWluV2VhcG9uUmlnaHQECFBpc3Ryb2wEB1NlcnZlcgQRQXJtZWRGb3JjZVNlcnZlcgQSR2V0Q3VyU2xvdEdyb3VwSWQEB2lw",
    "YWlycwQHc3RyaW5nBAdmb3JtYXQUTkNoZWNrRXF1aXBMb2dpYy5DaGVja1JhaWRCdWxsZXRFbm91Z2ggcmFpZOWtkOW8ueajgOafpee7k+aenCA9PT4gYkVub3VnaCA9ICVzBAAAAAECAAABAwEBAQAAAABcAQAAdQEAAAEAEFcAAADmAwAA5",
    "QOAAOYDAABoAEAAaUDAAEGAwADAAAAAJwGAAFmAAAKBwMAAmYAAAZcAAAATwA+A6ABBAChBQQApgUECaMFBAKkBQgFZgQABo0ECAOOBAgAZAQAC2YAAACjBQgApAUMCKUFDAgGBQwKnAQABwAGAARmBAAJowcMBgAEAAecBgABZgYABFQABiB",
    "OACIAVQAECEwADgKUBgACrAQACpwGAAuhBQQDpQcQDI4IEAGcCAAGAAoABwAIAAAADgALZAQADmUEAABOACICtwQAA6QFCAazBAYSsAYGJw0EBAqzBAYqqgQEApwGAAuhBQQDpQcQDI0IFAGcCAAGAAoABwAIAACkDQgFAAwACg0MBAtkBAAS",
    "ZQQAAE4ADgKcBgAPjgQUAJwIAAUACgAGZQQACEwACgOcAgAIoQUEAKUFEAmPBBQCnAQAB6AFGAAACAAAZAYAC2UAAABsAgAAZAAAABAdTZXJ2ZXIEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQNR2V0RXF1aXBJdGVtBAl0b251bWJlcgQH",
    "c3RyaW5nBARzdWIECXRvc3RyaW5nBANpZBMBAAAAAAAAABMEAAAAAAAAAAQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQWR2V0UmFpZEJ1bGxldENoZWNrTnVtBB5HZXRNYXRjaEJ1bGxldE51bUJ5V2VhcG9uSXRlbRMAAAAAAAAAAAQHZ",
    "m9ybWF0FI1DaGVja0VxdWlwTG9naWMuQ2hlY2tSYWlkQnVsbGV0RW5vdWdoIHJhaWTlrZDlvLnmo4Dmn6Xnu5PmnpwgbWF0Y2hNb2RlSUQgPSAlcywgd2VhcG9uUHJlZml4SUQgPSAlcywg5qe95L2NID0gJXMsIOWtkOW8uei2s+WknyDmkL",
    "rluKZudW0gPSAlcwQPY2hlY2tCdWxsZXROdW0ECG5lZWROdW0UnENoZWNrRXF1aXBMb2dpYy5DaGVja1JhaWRCdWxsZXRFbm91Z2ggcmFpZOWtkOW8ueajgOafpee7k+aenCBtYXRjaE1vZGVJRCA9ICVzLCB3ZWFwb25QcmVmaXhJRCA9ICV",
    "zLCDmp73kvY0gPSAlcywgaWQgPSAlcywgY2hlY2tCdWxsZXROdW0gPSAlcywgbmVlZE51bSA9ICVzFDZDaGVja0VxdWlwTG9naWMuQ2hlY2tSYWlkQnVsbGV0RW5vdWdoIE5vdCBjb25maWd1cmVkIBR+Q2hlY2tFcXVpcExvZ2ljLkNoZWNr",
    "UmFpZEJ1bGxldEVub3VnaCByYWlk5a2Q5by55qOA5p+l57uT5p6cIG1hdGNoTW9kZUlEID0gJXMsIHdlYXBvblByZWZpeElEID0gJXMsIOanveS9jSA9ICVzLCDmsqHluKbmrablmagED3dlYXBvblByZWZpeElECAAAAAABAQQBAAACAQIAA",
    "wEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHwBAACVAQAAAgAQJgAAAOYDAADlA4AA5gMAAKMAAAAXAAAAE0AHgMFAQADZgAAB1wAAABNABoDhAAAAKIFAAUHBQABZAQABGcEAAIIAAQGtAQAC6AFBAOlBwQMoAkEAKYJBBGgCQQ",
    "BpwsEEqAJBAKkCQgWgQQAC6EFCAAACAAPZAQEBE8AAgAADgAFAA4AFqYNCABlDgAHegQAAX0L+f5sAAAEbAIAACwAAABMAAAAAAAAAAAQJSXNXZWFwb24EHkdldFdlYXBvbkJ1bGxldE51bUFuZENhcGFjaXR5BA9HZXRSYXdQcm9wSW5mbwQ",
    "KRVNsb3RUeXBlBBZDaGVzdEhhbmdpbmdDb250YWluZXIEDUJhZ0NvbnRhaW5lcgQHUG9ja2V0BBFTYWZlQm94Q29udGFpbmVyBAdpcGFpcnMEA2lkAwAAAAAAAQsBBgEAAAAAfwEAAIcBAAACAA4hAAAAZgMAAGUDgABmAwAAqABAAKlAQAGB",
    "gEABAAEAAGcBgACZgAACwcBAAdmAAAEoAUEAQAGAARkBAQETgAOAQUJBBFmCAAFXAgAAE4ACgGcCAAFBgsEEwAKAACnDQQRZggACVwIAABPAAIBnAoABqQJCBEKCggRrAoABHoEAAJ+B+38bAIAACQAAAAQHU2VydmVyBBBJbnZlbnRvcnlTZ",
    "XJ2ZXIECEdldFNsb3QECUdldEl0ZW1zBAdpcGFpcnMECUlzQnVsbGV0BA5Jc01hdGNoV2VhcG9uBANpZAQEbnVtBAAAAAAAAQEAAQECAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACWAQAArQEAAAAAD0gAAACmAwAApQOAAKYDAAAoAE",
    "AAKUBAAAGAQAAZgAABFwAAABNAD4AVAICBE8AOgGgAQQCoQMEAWQABARNADYCogUEAqcFBA6kBQgOBQUIDKIJBACnCQQQpgkIEKcJCBCkCQwRAAoACmYEAApcBAAATAAqA6UFDA9cBAAATQAmA6YFDA9cBAAATgAiA6YFDA9cBAAATwAeAKMJ",
    "DACkCRARAAoADgAIAABmCgAEXAgAAEwAGgGhCRAGpgkQDWYIAAVdCAAATwASAaIJBAGnCwQRpAsIEQcLEBO0CAQApA0UD7AIDiiiDQQApw0EGKYNCBinDQgYpA0MG7AKDiinDRQPsAgOLLUMAAGmDRAMsQ4OM7AIDjFlCgAFegAAA38DxfxsA",
    "gAAaAAAABAdTZXJ2ZXIED0dhbWVNb2RlU2VydmVyBA9HZXRNYXRjaE1vZGVJRBMAAAAAAAAAAAQGcGFpcnMEEUVJdGVtU3BlaWNhbFR5cGUEB01vZHVsZQQLQXJtZWRGb3JjZQQGRmllbGQEFkdldEVxdWlwbWVudENoZWNrRGF0YQQHQ29uZ",
    "mlnBA5FQWJub3JtYWxUeXBlBApMYWNrTmlnaHQEB3N3aXRjaAQQbWF0Y2hNb2RlSURMaXN0BAZ0YWJsZQQJY29udGFpbnMEKF9DaGVja1BsYXllclN1cHBsaWVzRm9yTmlnaHRTcGVpY2FsVHlwZQQNY2hlY2tTdWJUeXBlBBFBZGRFcXVpcE",
    "Fibm9ybWFsBARrZXkEDWFibm9ybWFsVHlwZQQEbG9jBA1hYm5vcm1hbERlc2MEBnBhcmFtBBBhYm5vcm1hbFN1YlR5cGUDAAAAAAABCAEDAAAAAAAAAAAAAAAAAAAAAAC9AQAA1gEAAAEAEkwAAABmBAAAZQSAAGYEAABoAEAAaUDAAEGAwAB",
    "ZgAABqMBAAOgAwQCZAAEBE8AEgOgBQADpQcEDwYHBA0ACAAOAAoAA2YEAAtcBAAATwAKAAcLBAxmCAAEXAgAAE8ABgGgCQgGAAgAEwAIAAFmCgAFXAgAAE0AAgGUCgABbAgABnoAAAB9B+n+owEAA6EDCAJkAAQETQAiA6AFAAOlBwQPBgcED",
    "QAIAA4ACgADZgQAC1wEAABNABoABgsIDGYIAARcCAAATQAWAaMJCAGkCwwSAAgAEWYIAAVdCAAATwAOAaMJAAIACAARZAgEBE0ACgFcDAAATwAGAqANCAcADgAYABAAAmYOAAZcDAAATQACApQOAAJsDAAFeggAA38L8f56AAAAfwfZ/pQAAA",
    "JsAAAEbAIAADQAAAAQHU2VydmVyBBFBcm1lZEZvcmNlU2VydmVyBBJHZXRDdXJTbG90R3JvdXBJZAQHaXBhaXJzBA5FcXVpcFR5cGVMaXN0BBBJbnZlbnRvcnlTZXJ2ZXIECEdldFNsb3QEDUdldEVxdWlwSXRlbQQlQ2hlY2tTdXBwb3J0Tm",
    "lnaHRCYXR0bGVCeVNwZWljYWxUeXBlBBJDb250YWluZXJUeXBlTGlzdAQJR2V0SXRlbXMEBnRhYmxlBAhpc2VtcHR5AwAAAAAAAQMBCAAAAAAAAAAAAAAAAAAAAAAA1wEAAOMBAAAAAAcwAAAApgEAAKUBgACmAQAAKABAAClAQAApgEAAAcB",
    "AAKgAQACpQEABqQBBAalAQQGpgEEB6MBBAOkAwgEZgAACFwAAABNAB4BpQEIAVwAAABOABoBoAEAAaYDCAEHAwgBZgAABVwAAABMABYBoAEAAaUDAAGmAwABBAMMA7QABAClBQwDsAIGGKAFAAClBQAIpAUECKUFBAimBQQLsAAGHKQFEAOwA",
    "gYctQQAAaMFBAGkBwgIsQQGJ7ACBiFlAgAEbAIAAEwAAAAQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQWR2V0RXF1aXBtZW50Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEDkV4cGlyZWRTdGF0dXMECkVTbG90VHlwZQQIU",
    "2FmZUJveAQHc3dpdGNoBApJbnZlbnRvcnkEGkNoZWNrU2FmZUJveEV4cGlyZWRTdGF0dXMEEUFkZEVxdWlwQWJub3JtYWwEBGtleQQNYWJub3JtYWxUeXBlBARsb2MEDWFibm9ybWFsRGVzYwQGcGFyYW0EEGFibm9ybWFsU3ViVHlwZQEAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAA5AEAAPABAAAAAAcwAAAApgEAAKUBgACmAQAAKABAAClAQAApgEAAAcBAAKgAQACpQEABqQBBAalAQQGpgEEB6MBBAOkAwgEZgAACFwAAABNAB4BpQEIAVwAAABOABoBoAEAAaYDCAEHAwgBZgAABVwAAABM",
    "ABYBoAEAAaUDAAGmAwABBAMMA7QABAClBQwDsAIGGKAFAAClBQAIpAUECKUFBAimBQQLsAAGHKQFEAOwAgYctQQAAaMFBAGkBwgIsQQGJ7ACBiFlAgAEbAIAAEwAAAAQHTW9kdWxlBAtBcm1lZEZvcmNlBAZGaWVsZAQWR2V0RXF1aXBtZW50",
    "Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEDkV4cGlyZWRTdGF0dXMECkVTbG90VHlwZQQJS2V5Q2hhaW4EB3N3aXRjaAQKSW52ZW50b3J5BBtDaGVja0tleUNoYWluRXhwaXJlZFN0YXR1cwQRQWRkRXF1aXBBYm5vcm1hbAQEa",
    "2V5BA1hYm5vcm1hbFR5cGUEBGxvYwQNYWJub3JtYWxEZXNjBAZwYXJhbQQQYWJub3JtYWxTdWJUeXBlAQAAAAAAAAAAAAAAAAAAAAAAAAAAAADxAQAAGQIAAAAAEmoAAABmBAAAZQSAAGYEAAAoAEAAKUBAACmAQAABwEAAqABAAKlAQAGpAE",
    "EBqUBBAamAQQHjwAEAGYAAAhcAAAATgACAaQBCAFdAAAATAACAGwCAAGhAQgBpgMIAQcDCAFmAAAGlAAAA6ABDAChBwwDZAAEBEwAEgChCQgApgkMEAcJDBIACgAPAAoAAGYIAAhcCAAATAAKAQQJEBFmCAAGoQkQBwAKABJmCAAGXAgAAE0A",
    "AgKUAgAATQACA3oAAAF8B+3+XQAAAEwAJgOgAQwAogcQA2QABAROAB4AoQkIAKYJDBAHCQwSAAoADwAKAABmCAAIXAgAAE4AFgEHCRARZggABVwIAABOABICoAkUAqUJFBcACgASZggABl0IAABMAA4CoAkMAwAKABJkCAQETgAGA6ENEAQAE",
    "AAfZgwAB1wMAABNAAIClAIAAE0AAgJ6CAAAfg/1/3oAAAF+B93+XAAAAE8ADgOgAQADpQMAB6YDAAcGAxQFtwQAAqcFFAGyBgYuoAUAAqUFAA6kBQQOpQUEDqYFBA2yBAYypgUYAbIGBjNlAgAEbAIAAGwAAAAQHTW9kdWxlBAtBcm1lZEZvc",
    "mNlBAZGaWVsZAQWR2V0RXF1aXBtZW50Q2hlY2tEYXRhBAdDb25maWcEDkVBYm5vcm1hbFR5cGUEDEV4cGlyZWRQcm9wEwAAAAAAAAAABAdzd2l0Y2gEB1NlcnZlcgQRQXJtZWRGb3JjZVNlcnZlcgQSR2V0Q3VyU2xvdEdyb3VwSWQEB2lwYW",
    "lycwQORXF1aXBUeXBlTGlzdAQQSW52ZW50b3J5U2VydmVyBAhHZXRTbG90BA1HZXRFcXVpcEl0ZW0EDUNoZWNrRXhwaXJlZAQSQ29udGFpbmVyVHlwZUxpc3QECUdldEl0ZW1zBAZ0YWJsZQQIaXNlbXB0eQQRQWRkRXF1aXBBYm5vcm1hbAQ",
    "Ea2V5BA1hYm5vcm1hbFR5cGUEBGxvYwQNYWJub3JtYWxEZXNjAwAAAAAAAQMBCQAAAAAAAAAAAAAAAAAAAAAAGgIAAE0CAAABABRXAAAA5gQAAOUEgADmBAAAF0AAABNAAYBnAAAAowAAAFlAAAFlAAAArQAAAFsAgAFtAAAArQAAAOhAwADp",
    "gMABwcDAAdmAAAEhAQAAaAHBAKhBQQJZAQEBE4ADgKhCwACpgkEFgcJBBQADgARAA4ABmYIAApcCAAATgAGAwQJCBdmCAAHXAgAAE4AAgAADAAJAA4AFGUMAAV6BAADfgft/aAHBAKhBQgJZAQEBEwAHgKhCwACpgkEFgcJBBQADgARAA4ABm",
    "YIAApcCAAATAAWAwYJCBdmCAAHXAgAAEwAEgCjDwgApA0MGQAOABRmDAAEXQwAAE4ACgCgDwQBAA4AFGQMBARMAAYAXBAAAE4AAgEAEAAKABAAIWUQAAR6DAACfA/5/XoEAAN8B+H9owcIAaUHDAoABAAFZgQABQACAAmjBwgBpAcMCgAGAAF",
    "mBAAFQAYACgAGAAFsBgAEbAIAADgAAABRAQ2hlY2tFcXVpcExvZ2ljLkNoZWNrTmlnaHRWaXNpb25MaW1pdEJ5TGlzdCBjaGVja0xpc3QgaXMgbmlsISEhBAdTZXJ2ZXIEEUFybWVkRm9yY2VTZXJ2ZXIEEkdldEN1clNsb3RHcm91cElkBAd",
    "pcGFpcnMEDkVxdWlwVHlwZUxpc3QEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQNR2V0RXF1aXBJdGVtBBJDb250YWluZXJUeXBlTGlzdAQJR2V0SXRlbXMEBnRhYmxlBAhpc2VtcHR5BAVrZXlzBQAAAAECAAABBAEGAQMBAAAAACICAAA0",
    "AgAAAQAOOQAAAGYDAABlA4AAZgMAAGkAQACoQEAAwACAAJmAAAHogMAA6cDAARTAAAETQAiAwQBBANmAAAHXAAAAEwAKgChBQQFAAYABpQEAAOUBAAAlAoAAGYGAAmiBwQBpwcECgAEAAlmBAAFXQQAAEwAHgGgBwgCAAQACWQEBAROAAoCog",
    "sEAqUJCBcACgAQnA4ABmYKAAZcCAAATwACAqEICApdCAAATAACAKoHCBF6BAADfgfx/E4ACgOiAwQDpQMIBAAGAAGcBgAHZgIAB1wAAABPAAIDoQAAC10AAABMAAIAqgcIAGwCAAAsAAAAEA2lkBBBHZXRNYWluVHlwZUJ5SWQECkVJdGVtVH",
    "lwZQQJUmVjZWl2ZXIED0dldFJhd1Byb3BJbmZvBBVHZXRJdGVtSURzQnlQcm9wSW5mbwQGdGFibGUECGlzZW1wdHkEB2lwYWlycwQJaXNJbkxpc3QBAQUAAAAAAgABAAMBAAECAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOAgAAUAI",
    "AAAEABAgAAADmAAAA5QCAAOYAAABoAEAAgAAAAFoAAAFbAAAAGwCAAAEAAAAEG0NoZWNrUGxheWVyQm9keUl0ZW1zQnlMaXN0AQAAAAEDAAAAAAAAAAAAAAAAAAAAAABRAgAAUwIAAAEABAgAAADmAAAA5QCAAOYAAABoAEAAgAAAAFoAAAFb",
    "AAAAGwCAAAEAAAAEG0NoZWNrUGxheWVyQm9keUl0ZW1zQnlMaXN0AQAAAAEDAAAAAAAAAAAAAAAAAAAAAABUAgAAmQIAAAEAFGcAAADmBAAA5QSAAOYEAABoAEAAgAAAAOUAgABZgIABAACAAG3AAACoQEAAqYBAAWzAQAGoQEAAqQBBAWzAQ",
    "AGoQEAAqUBBAWzAQAGogEEAqcBBAYEAQgGZgAABFwAAABOAAIDhAAAA10AAABMAAIDhQAAAIYEAAGhBQgCogUICWQEBAROAA4CogkEAqcJCBYECQwUAA4AEQAMAAZmCAAKXAgAAE4ABgMFCQwXZggAB1wIAABOAAIAAAwACQAOABRlDAAFegQ",
    "AA34H7f2hBQgCogUMCWQEBARMAB4CogkEAqcJCBYECQwUAA4AEQAMAAZmCAAKXAgAAEwAFgMHCQwXZggAB1wIAABMABIAoA0QAKUNEBkADgAUZgwABF0MAABOAAoAoQ0IAQAOABRkDAQETAAGAFwQAABOAAIBABAACgAQACFlEAAEegwAAnwP",
    "+f16BAADfAfh/ZwGAAqiBRACpwUQD4wEFAAACAABoQkUAaYLFBGlCggCoQkUAqcJFBamCggDoQkUA6QLGBenCggCZAQADWUEAAFsAAAEbAIAAGQAAAAQLc2V0ZGVmYXVsdAQKRVNsb3RUeXBlBAdIZWxtZXQT//////////8EDEJyZWFzdFBs",
    "YXRlBAtCdWxsZXRMZWZ0BAdTZXJ2ZXIEEUFybWVkRm9yY2VTZXJ2ZXIEEkdldEN1clNsb3RHcm91cElkBAdpcGFpcnMEDkVxdWlwVHlwZUxpc3QEEEludmVudG9yeVNlcnZlcgQIR2V0U2xvdAQNR2V0RXF1aXBJdGVtBBJDb250YWluZXJUe",
    "XBlTGlzdAQJR2V0SXRlbXMEBnRhYmxlBAhpc2VtcHR5BAdzdHJpbmcEB2Zvcm1hdBR7Q2hlY2tFcXVpcExvZ2ljLkNoZWNrUGxheWVyQm9keUl0ZW1zRW50cnlRdWFsaXR5IFtiTGltaXRNYXggPSAlcywg5aS055uU5ZOB6LSoID0gJXMsIO",
    "aKpOeUsuWTgei0qCA9ICVzLCDlrZDlvLnlk4HotKggPSAlc10ECkVTbG90VHlwZQQHSGVsbWV0BAxCcmVhc3RQbGF0ZQQLQnVsbGV0TGVmdAYAAAAAAAEEAQUBBgEDAQIDAAAAAFwCAABeAgAAAgAECQAAAOYAAADlAIAA5gAAAFUAgAATAAC",
    "ApUAAAKUAgACbAAABGwCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeAgAAYAIAAAIABAkAAADmAAAA5QCAAOYAAABVQAAAEwAAgKVAAAClAIAAmwAAARsAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYQIAAIACAAABABODAAAApgQA",
    "AKUEgACmBAAAaQBAAKhAQADAAIAAmYAAAeiAQAAAAYAA2YAAASjBwABAAYAAGYEAAWgBQQFpQcECFEABAROAC4BBgUEAWYEAAajBwQHAAYACmYEAAZcBAAATQBqA6AFCAelBwgMAAgAD2YEAAddBAAATwBiA6IFCAQACAAPZAQEBE4AGgCkDw",
    "AVoQ0AAgAMABlmDAAGoA0EBqcNCBxSAgwYTgASAqMPAAMADAAaZgwAB6ANDAelDwwfowwMCVIDDBxPAAYDnA4ACAAQAB2gEQwFpRMMIaEQEAtmDgAHXAwAAE4AAgOgDQwHpQ8MHKoGDB96BAABfgvh/E0AQgGgBQQFpwcMCFEABARNACoBoAU",
    "QBaUHEAhRAgQETAASAaAFDAWlBxAJoQQECVIDDAhPAAYBnAYACgAEAAugBQwHpQcQD6MEBAlmBgAFXAQAAEwALgGgBQwFpQcQCKgGBAhMACoBoAUQBaYHEAhRAgQETAAmAaAFDAWmBxAJoQQECVIDDAhPAAYBnAYACgAEAAugBQwHpgcQD6ME",
    "BAlmBgAFXAQAAE8AFgGgBQwFpgcQCKgGBAhPABIBoAUEBacHCAhRAAQETwAOAaAFDAWlBwwJoQQECVIDDAhPAAYBnAYACgAEAAugBQwHpQcMD6MEBAlmBgAFXAQAAE4AAgGgBQwFpQcMCKgGBAhsAgAATAAAABANpZAQQR2V0TWFpblR5cGVC",
    "eUlkBA9HZXRTdWJUeXBlQnlJZAQPR2V0SXRlbVF1YWxpdHkECkVJdGVtVHlwZQQJUmVjZWl2ZXIED0dldFJhd1Byb3BJbmZvBBFHZXRXZWFwb25CdWxsZXRzBAZ0YWJsZQQIaXNlbXB0eQQHaXBhaXJzBAdCdWxsZXQECkVTbG90VHlwZQQLQ",
    "nVsbGV0TGVmdBP//////////wQKRXF1aXBtZW50BA9FRXF1aXBtZW50VHlwZQQHSGVsbWV0BAxCcmVhc3RQbGF0ZQYAAAAAAQACAAAAAwEBAQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJoCAACqAgAAAAAIMwAAAOYBAADlAYAA5g",
    "EAACgAQAApQEAAKYBAAAHAQACoAEAAqUBAAakAQQGpQEEBqYBBAePAAQAZgAACFwAAABNACIBpAEIAVwAAABOAB4BoQEIAaYDCAEHAwgBZgAABFUCAgxMABoCoAEAAqUBAAYEAQwEAAYAAmYCAAZdAAAATQASA6ABAAOlAwAHpgMABwUDDAW0",
    "BAQCpgUMAbIEBh6gBQACpQUADqQFBA6lBQQOpgUEDbIGBh6lBRABsgQGIrQEAAGyBAYnZQIABGwCAABMAAAAEB01vZHVsZQQLQXJtZWRGb3JjZQQGRmllbGQEFkdldEVxdWlwbWVudENoZWNrRGF0YQQHQ29uZmlnBA5FQWJub3JtYWxUeXBl",
    "BChSZW50YWxWb3VjaGVyRG9Ob3RNZWV0RW50cnlSZXF1aXJlbWVudHMTAAAAAAAAAAAEB3N3aXRjaAQHU2VydmVyBBFBcm1lZEZvcmNlU2VydmVyBB5HZXRDdXJSZW50YWxQbGFuX0NvbnN1bWFibGVJRAQcQ2hlY2tDb25zdW1hYmxlSURDY",
    "W5CZUFwcGx5BBFBZGRFcXVpcEFibm9ybWFsBARrZXkEDWFibm9ybWFsVHlwZQQEbG9jBA1hYm5vcm1hbERlc2MEBnBhcmFtAQAAAAAAAAAAAAAAAAAAAAAAAAAAAACsAgAAtQIAAAMACRkAAAAmAgAAJQKAACYCAAAXAAAAE4AEgOgAQADpQM",
    "ABwYDAAUABAADZgIAB10AAABOAAoCXAAAAEwACgCiBgAAXQQAAE0ABgCcBAAFjwQAAgAGAAMABAAEZQQACagBBAdsAAAEbAIAABQAAAAQHTW9kdWxlBAxMaXRlUGFja2FnZQQZSXNEb3dubG9hZGVkQnlNb2R1bGVOYW1lFINbIERvd25sb2F",
    "kQ2hlY2sgTUExIF0gQ2hlY2tFcXVpcExvZ2ljLl9DaGVja0l0ZW1XaXRoQ29tcHNEb3dubG9hZGVkKGl0ZW0pIOW9k+WJjemBk+WFt+WMheWQq+mBk+WFty/phY3ku7Yv55qu6IKk6LWE5rqQ5bCa5pyq5LiL6L29AQEDAAAAAAABDAEBAAAA",
    "AAAAAAAAAAAAAAAAAAC2AgAA7gIAAAEACx8AAACmAgAApQKAAKYCAABlAIAAFABAABMAAIBbAAABoQAAAOlAQADXAAAAE8AAgAABAAFAAYABGUEAARNAA4ApgUAAFwEAABOAAoBowUAAaQHBAkFBwQLAAQACWYGAAaiBwQDAAYACAAIAAkACA",
    "AKZgQACQAAAA1sAAAEbAIAABwAAAAAEDHJhd1Byb3BJbmZvBANpZAQHTW9kdWxlBAxMaXRlUGFja2FnZQQUR2V0RG93bmxvYWRDYXRlZ2FyeQQeX0NoZWNrUHJvcGluZm9Eb3dubG9hZFdpdGhMb2cCAAAAAAABAwEAAAAAuwIAAOECAAABAA",
    "1bAAAAJgMAACUDgAAmAwAAaQBAAKhAQACpgEABgcBAASkBQACZgIAB6ABBAOlAwQEAAQAA2YAAAShBQAApgUACAcFAAoABgAEZgYABaIFBAGnBwQJZgYAAV0EAABOACIAXAQAAE0ACgGgBwgCAAQACwAGAAAACgAFZgQACpwEAAZcBAAATAAC",
    "AgAGAAqsBAAGXAAAAE4ACgGkBQACoAcIAwAEAAQACgABAAoACmYEAAucBAAHXAQAAEwAAgMABAAPrAQABaEFCAKmBQgBZAQEBE4AAgKcCgAHpwsIEmUIAAV6BAADfgf5/E8AHgBcBAAATAAKAaAHCAIABAALAAYAAAAKAAVmBAAJXQQAAE0AA",
    "gGsBAAEbAIAAlwAAABNAAoBpAUAAqAHCAMABAAEAAoAAQAKAApmBAAKXQQAAE0AAgKsBAAEbAIAAaEFCAKmBQgBZAQEBE4AAgKcCgAHpwsIEmUIAAV6BAADfgf5/GwCAAAwAAAAEA2lkBAdNb2R1bGUEDExpdGVQYWNrYWdlBBRHZXREb3dub",
    "G9hZENhdGVnYXJ5BAlJdGVtQmFzZQQcR2V0V2VhcG9uU2tpbklERnJvbVByb3BJbmZvBAxWZXJzaW9uVXRpbAQLSXNTaGlwcGluZwQeX0NoZWNrUHJvcGluZm9Eb3dubG9hZFdpdGhMb2cEB2lwYWlycwQLY29tcG9uZW50cwQKcHJvcF9kYX",
    "RhBAAAAAAAAAEBAQECAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwAgAA+AIAAAEABxsAAACmAQAApQGAAKYBAABoAEAAaUDAAEGAwADAAAAAWYCAAagAQACpQEABgcBAAQABgACZgIABl0AAABNAAoAXAAAAE8ABgOgAgADXQAAAEwA",
    "BgOcAAAEjAQEAQAEAANlAgAFqQEEAmwAAARsAgAAGAAAABAdNb2R1bGUEDExpdGVQYWNrYWdlBBRHZXREb3dubG9hZENhdGVnYXJ5BBlJc0Rvd25sb2FkZWRCeU1vZHVsZU5hbWUUbVsgRG93bmxvYWRDaGVjayBTSEUxIF0gQ2hlY2tFcXVp",
    "cExvZ2ljLl9DaGVja0l0ZW1JZERvd25sb2FkZWQoaXRlbUlkKSDlvZPliY3pgZPlhbdpZOWvueW6lOi1hOa6kOWwmuacquS4i+i9vQEBAwAAAAAAAQ0BAQAAAAAAAAAAAAAAAAAAAAAA+QIAAP8CAAAAAAUPAAAAJgEAACUBgAAmAQAAKABAA",
    "ClAQAABgEAAGYAAARdAAAATwACAZwCAAKPAAADAAAAAWUCAARsAAAEbAIAABAAAAAQHTW9kdWxlBBlFeHBhbnNpb25QYWNrQ29vcmRpbmF0b3IEH0dldFdlYXBvblBhcnRJdGVtUmVzRG93bmxvYWRlZBRpWyBEb3dubG9hZENoZWNrIFNIRT",
    "EgXSBDaGVja0VxdWlwTG9naWMuX0NoZWNrQWxsV2VhcG9uUGFydERvd25sb2FkZWQoKSDmrablmajlpKflsI/ljIXotYTmupDlsJrmnKrkuIvovb0CAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAAAAMAACkDAAABAAs7AAAApgIAAKUCgACmAgA",
    "AFwAAABPAC4BpAEAAqEBAAMAAgACZgAAB6IBAAAABgADZgAABKMFAAEABAAAZgQABF0EAABMAAoAoAcEAKUFBAhQAAQETgAaAKIHBACnBQQIpAUICFACBARNABYABQUIAGYEAARdBAAATgAKAaIHCAGnBwgJBAcMCwAGAAFmBgAGnAQAB40ED",
    "AAACgABAAoACmUEAAlsBAAFhAQAAgAGAAsABAAKZgQABmwEAAVNBAYATAAGAKIHDACnBQwIBAUQCGYEAARsBAAFogMMAacDDAEEAxABZgAABWwAAARsAgAARAAAABANpZAQQR2V0TWFpblR5cGVCeUlkBA9HZXRTdWJUeXBlQnlJZAQdSXNBc",
    "m1lZEZvcmNlVW5pcXVlUHJvcEJ5SXRlbQQKRUl0ZW1UeXBlBAtXZWFwb25Ta2luBAtJdGVtQ29uZmlnBBBFV2VhcG9uSXRlbVR5cGUECUhlcm9Qcm9wBA9HZXRSYXdQcm9wSW5mbwQHTW9kdWxlBAxMaXRlUGFja2FnZQQUR2V0RG93bmxvYW",
    "RDYXRlZ2FyeRSBWyBEb3dubG9hZENoZWNrIFVIRTEgXSBDaGVja0VxdWlwTG9naWMuR2V0TmVlZERvd25sb2FkQ2F0ZWdhcnlLZXkoaXRlbSkg6YGT5YW357y65bCRcHJvcEluZm/vvIznm7TmjqXov5Tlm57pgZPlhbfkuIvovb3liIbnsbt",
    "rZXkEB01vZHVsZQQMTGl0ZVBhY2thZ2UEHkdldFJ1bnRpbWVXZWFwb25QYXJ0TW9kdWxlS2V5AwAAAAEEAAABAQEAAAAADAMAAB8DAAABAAwwAAAA5gIAAOUCgADmAgAAaABAAGlAwABBgMAA6cBAAFmAgAGoAEEAqUBBAcAAAACZgAAB6ABA",
    "AOlAwAHBgMABQAEAAdmAgAHXAAAAE8ABgCgBQAApQUACAYFBAoABgAEZgYABF0EAABMAAIDbAAABVwAAABPAAYAoAUAAKUFAAgGBQQKAAYAAGYGAARdBAAATAACAWwAAASjBQQBpAUIAGQEBARPAAIBnAoAAqUJCBFoCAAFbAgAAHoEAAJ9B/",
    "n8bAIAACgAAAAQHTW9kdWxlBAxMaXRlUGFja2FnZQQUR2V0RG93bmxvYWRDYXRlZ2FyeQQDaWQECUl0ZW1CYXNlBBxHZXRXZWFwb25Ta2luSURGcm9tUHJvcEluZm8EGUlzRG93bmxvYWRlZEJ5TW9kdWxlTmFtZQQHaXBhaXJzBAtjb21wb2",
    "5lbnRzBApwcm9wX2RhdGECAAAAAAEBBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKwMAAG0QAAADAJGuBAAAJiQAACUkgAAmJAAA6ABAAAABAADZgAABVEDAARMAAIAbAIAA44AAACnBQAAswICBaQFBAK0BAAAsgAGCqEFBAO0BAAI",
    "jggEAY8IBAKMCAgDjQgIA4EEAApkBAQETwAKA6QJBACgDQABAA4ACGYMAARRAQAYTgACAKYOCAlSAQgYTAACAJUMAACUDgADsAgMFnoEAAB9C/H+pAUEAqQFCAxSAQgMTQAGAqQFBAKlBQgMUgEIDE0AAgKkBQQCswcKEqQFDABSAQgMTgACA",
    "FMAAAhMAAIAbAIAALIBChqEBAADpQUMA10EAABMAAIDtAQAALMCBhsABAAPZgYAALMABh8ABAAPZgYAALMCBhyxARIgswESJLEBFiixARIvpwUUA10EAABOAAIDtQQAALQIAAOwBAowswIGL6UFGABRAxAMTAACALIDCjO2BAAAtAgACY8IEA",
    "KPCBgDjwgYAI8MEACBCAALsAQKNLQIAAmPCBgCjwgQA48IGACPDBAAgQgAC7AECji3CAAAsQkeNLIJHjiwCyI9tggAAbEJIjWyCSI6tAgAJ48IIACMDCQBjQwkAo4MJAOPDCQAjBAoAY0QKAKOECgDjxAoAIwULAGNFCwCjhQsA48ULACMGDA",
    "BjRgwAo4YMAOPGDAAjBw0AY0cNAKOHDQCgQgAK48INACMDDgBjQw4Ao0MOAOMDDgAjhA4AaERAAGnEzghXRAAAEwAAgGjETgChRAAA4YQAACHFAABhBQEAoUUBAOGFAQAhxgEAYQYCAKFGAgDtBgEALQcAAmMHDwCjRw8A44cPACPIDwAgRwA",
    "C7AYHgy0HgANjBxAAo0cQAOOHEAAjyBAAYwgRAKNIEQDjiBEAIEeAA+wGh4MtBwAJY8cRAKMHEgDjRxIAI4gSAGPIEgCjCBMA40gTACOJEwBjyRMAowkUAONJFAAjihQAY8oUAKMKFQDjShUAI4sVAGPLFQCjCxYA40sWACOMFgAgRwAK7AYH",
    "hC0HAAJjBw8Ao0cPAOOHDwAjyA8AIEcAAuwGh4QtBwMALAfXrSwH164sB1evLAfXrywHV7AsB9ewLAdXsSwH17EsB1eyLAfXsiwHV7MsB9ezbQeAE6MHGgDjRxoAI4gaAGPIGgCjCBsA40gbACOJGwBjyRsAowkcAONJHAAjihwAY8ocAKMKH",
    "QDjSh0AI4sdAGPLHQCjCx4A40seACOMHgBjzB4AowwfAONMHwAjjR8AY80fAKMNIADjTSAAI44gAGPOIACjDiEA404hACOPIQBjzyEAow8iAONPIgAjkCIAY9AiAKMQIwDjUCMAI5EjAGPRIwCjESQA41EkACOSJABj0iQAoxIlAONSJQAjky",
    "UAY9MlAKMTJgDjUyYAYEcAGaOHJgDjxyYAIwgnAGNIJwCjiCcA48gnACMJKABjSSgAo4koAOPJKAAjCikAY0opAKOKKQDjyikAIwsqAGNLKgCjiyoA48sqACMMKwBjTCsAo4wrAOPMKwAjDSwAY00sAKONLADjzSwAIw4tAGNOLQCjji0A484",
    "tACMPLgBjTy4Ao48uAOPPLgAjEC8AY1AvAKOQLwDj0C8AIxEwAGNRMACjkTAA49EwACMSMQBjUjEAo5IxAOPSMQAjEzIAY1MyAKOTMgDj0zIAYIcAGaMHMwDjRzMAI4gzAGPIMwCjCDQA40g0ACOJNABjyTQAowk1AONJNQAjijUAY8o1AKMK",
    "NgDjSjYAYMcAB6GHAgDhxwIAIQgDAGFIAwChiAMA4cgDACEJBABhSQQAoYkEAOHJBAAhCgUAYUoFAKGKBQDhygUAIQsGAGFLBgChiwYA7UsEAOzLdu3sy3bu7Mv27uzLdu/sy/bv7Mt28OzL9vDsy3bx7Mv28ezLdvLsy/by7Mt28+zL9vPsy",
    "3b07Mv29OzLdvXsy/b1LQwACmMMOwCjTDsA44w7ACPNOwBjDTwAo008AOONPAAjzjwAYw49AKNOPQDjjj0AI889AGMPPgCjTz4A4w82ACNQNgBjkD4Ao9A+AOMQPwAjUT8AY5E/AKPRPwDj0SAAIEyAC2HMBgChDAcA4UwHAC2NAQBjDUAArQ",
    "0GAONNQAAjjkAArA2OG+PNQAAjDkEArA2OG+NNQQAjjkEArA2OG+PNQQAjDkEArA2OG+MNQgAjTkIArA2OG+ONQgAjzkIArA2OG+MNQwAjTkMArA2OG+ONQwAjDkEArA2OG+PNQwAjzkIArA2OG+MNRAAjTkQArA2OG+ONRAAjzkQArA2OG+M",
    "NRQAjzkQArA2OG+NNRQAjjkUArA2OG+PNRQAjjkUArA2OG+MNRgAjTkMArA2OG+NNRgAjDkEArA2OG+ONRgAjzkQArA2OG+PNRgAjzkQArA2OG+MNRwAjjkUArA2OG+NNRwAjjkUArA2OG+ONRwAjzkcArA2OG+MNSAAjzkcArA2OG+NNSAAj",
    "jkgArA2OG+PNSAAjDkkArA2OG+NNSQAjzkIArA2OG+ONSQAjzkQArA2OG+PNSQAjzkQArA2OG+MNSgAjTkMArA2OG+NNSgAjDkEArA2OG+ONSgAjzkQArA2OG+PNSgAjzkQArA2OG+MNSwAjzkQArA2OGyyNjRpjTUsArQ0GAONNQAAjjkAAr",
    "A2OG+PNQAAjDkEArA2OG+NNQQAjjksArA2OG+PNQQAjDkEArA2OG+ONQgAjzkIArA2OG+PNSwAjDkEArA2OG+MNTAAjDkEArA2OG+MNQwAjTkMArA2OG+ONQwAjDkEArA2OG+PNQwAjzkIArA2OG+MNRAAjjkUArA2OG+ONRAAjzkQArA2OG+",
    "MNRQAjzkQArA2OG+NNRQAjzkQArA2OG+PNRQAjzkQArA2OG+MNRgAjTkwArA2OG+ONTAAjDkEArA2OG+ONRgAjzkQArA2OG+PNRgAjzkQArA2OG+MNRwAjzkQArA2OG+NNRwAjzkQArA2OG+ONRwAjzkcArA2OG+MNSAAjzkcArA2OG+NNSAA",
    "jzkwArA2OG+PNSAAjTkIArA2OG+NNSQAjzkIArA2OG+ONSQAjzkQArA2OG+PNSQAjzkQArA2OG+MNSgAjDk0ArA2OG+ONSgAjDkEArA2OG+PNSgAjzkQArA2OG+MNSwAjzkQArA2OGyyNjRpjTU0Arc0FAONNQAAjjkAArA2OG+PNQAAjDkEA",
    "rA2OG+NNQQAjjk0ArA2OG+PNQQAjDkEArA2OG+ONQgAjzkIArA2OG+PNSwAjDkEArA2OG+MNTAAjDkEArA2OG+MNQwAjTkMArA2OG+ONQwAjDkEArA2OG+PNQwAjzkIArA2OG+MNRAAjjkUArA2OG+ONRAAjzkQArA2OG+MNRQAjzkQArA2OG",
    "+NNRQAjzkQArA2OG+PNRQAjzkQArA2OG+MNRgAjzk0ArA2OG+ONTAAjDkEArA2OG+ONRgAjzkQArA2OG+PNRgAjzkQArA2OG+MNRwAjzkQArA2OG+NNRwAjzkQArA2OG+ONRwAjzkcArA2OG+MNSAAjzkcArA2OG+NNSAAjzkwArA2OG+NNSQ",
    "AjzkIArA2OG+ONSQAjzkQArA2OG+PNSQAjzkQArA2OG+ONSgAjzkQArA2OG+PNSgAjzkQArA2OG+MNSwAjzkQArA2OGyyNjRpjDU4ArQ0GAONNQAAjjkAArA2OG+PNQAAjDkEArA2OG+NNQQAjjk0ArA2OG+PNQQAjDkEArA2OG+ONQgAjzkI",
    "ArA2OG+PNSwAjDkEArA2OG+MNTAAjDkEArA2OG+MNQwAjTkMArA2OG+ONQwAjDkEArA2OG+PNQwAjTk4ArA2OG+MNRAAjjkUArA2OG+ONRAAjzkQArA2OG+MNRQAjzkQArA2OG+NNRQAjzkQArA2OG+PNRQAjzkQArA2OG+MNRgAjzk0ArA2O",
    "G+ONTAAjjk4ArA2OG+ONRgAjzkQArA2OG+PNRgAjzkQArA2OG+MNRwAjzkQArA2OG+NNRwAjzkQArA2OG+ONRwAjzkcArA2OG+MNSAAjzkcArA2OG+NNSAAjzkwArA2OG+PNSAAjTkIArA2OG+NNSQAjzkIArA2OG+ONSQAjzkQArA2OG+PNS",
    "QAjzkQArA2OG+MNSgAjTkMArA2OG+ONSgAjDkEArA2OG+PNSgAjzkQArA2OG+MNSwAjzkQArA2OGyyNjRpjzU4ArQ0GAONNQAAjjkAArA2OG+PNQAAjDkEArA2OG+NNQQAjjk0ArA2OG+PNQQAjDkEArA2OG+ONQgAjzkIArA2OG+PNSwAjDk",
    "EArA2OG+MNTAAjDkEArA2OG+MNQwAjTkMArA2OG+ONQwAjDkEArA2OG+PNQwAjzkIArA2OG+MNRAAjjkUArA2OG+ONRAAjzkQArA2OG+MNRQAjzkQArA2OG+NNRQAjzkQArA2OG+PNRQAjzkQArA2OG+MNRgAjTkwArA2OG+ONTAAjjk4ArA2",
    "OG+ONRgAjzkQArA2OG+PNRgAjzkQArA2OG+MNRwAjzkQArA2OG+NNRwAjzkQArA2OG+ONRwAjDk8ArA2OG+MNSAAjzkcArA2OG+NNSAAjzkwArA2OG+PNSAAjTkIArA2OG+NNSQAjzkIArA2OG+ONSQAjzkQArA2OG+PNSQAjzkQArA2OG+MN",
    "SgAjDk0ArA2OG+ONSgAjDkEArA2OG+PNSgAjzkQArA2OG+MNSwAjzkQArA2OGyyNjRpjTU8ArU0EAONNQAAjjkAArA2OG+PNQAAjDkEArA2OG+NNQQAjjk0ArA2OG+PNQQAjDkEArA2OG+ONQgAjzkIArA2OG+PNSwAjDkEArA2OG+MNTAAjD",
    "kEArA2OG+MNQwAjjk8ArA2OG+ONQwAjDkEArA2OG+PNQwAjzkIArA2OG+MNRgAjjk8ArA2OG+ONTAAjDkEArA2OG+ONRwAjzkcArA2OG+MNSAAjzkcArA2OG+PNSAAjTkIArA2OG+NNSQAjzkIArA2OG+MNSgAjzk8ArA2OG+ONSgAjDkEArA",
    "2OGyyNjRphjQcAoc0HAOENCAAhTggAYY4IAKHOCADhDgkAIU8JAGGPCQChzwkA4Q8KACFQCgBhkAoAodAKAO0QAQAjEVAAbZEBAKMRUABskXQjo1FQAGyRdCOjkVAAbJF0I6PRUABskXQjoxFRAGyRdCOjUVEAbJF0I+xQESIjkVEAbZEBAKM",
    "RUABsEXUjo1FQAGwRdSOjkVAAbBF1I6PRUABsEXUjoxFRAGwRdSOjUVEAbBF1I+xQESIj0VEAbZEBAKMRUABs0XUjo1FQAGyRdSOjkVAAbNF1I6PRUABskXUjoxFRAGyRdSOjUVEAbNF1I+xQESIjEVIAbZEBAKMRUABskXQjo1FQAGzRdCOj",
    "kVAAbBF1I6PRUABsUXUjoxFRAGyRdSOjUVEAbNF1I+xQESItkQEAYxFQAKNRUgAskZEiY1FQAKNRUgAskZEiY5FQAKNRUgAskZEiY9FQAKNRUgAskZEiYxFRAKNRUgAskZEiY1FRAKNRUgAskZEiYRELAKFRCwDhkQsAIdILAGESDAChUgwA4",
    "ZIMACHTDABhEw0AoVMNAOGTDQAh1A0AYRQOAKFUDgDhlA4AIdUOAGEVDwChVQ8A4ZUPACHWDwBhFhAAoVYQAOGWEAAh1xAAYRcRAKFXEQDhlxEAIdgRAGEYEgChWBIA4ZgSACHZEgBhGRMAoVkTAOOZUgAsgJgz49lSACyAmTPhmRMAIdoTAG",
    "EaFAChWhQA4ZoUACHbFABhGxUAoVsVAOYbgABhnBUAodwVAOEcFgAtHQAAYV0WAKGdFgDh3RYAIR4XAGFeFwChnhcA4d4XACYfAABhHxgAoV8YAOGfGAAAH4A/4d8YACEgGQBhYBkAoaAZAOMgUwAsQKBB42BTACyAoEHjoFMAIeEZACwAoUH",
    "j4FMAACEAQGPhUwBpYSEAV2EAABMAAIBjIVQAGaEAASwAoUHjYFQAI+FTACkhIQBjoVQAFEAhQhMAAIAlYQAAJSGAACwAoUHj4FQAI2FUACkhIQAXIQAAE8AAgCPhUwApISEAF2EAABOAAYAAIYA/Y+FUAGlhIQBXYQAAEwAAgGMhVAAZoQAB",
    "LAChQeMgVQAAIYA/YyFVAGlhIQBXYQAAEwAAgGNhVQAZoQABLAChQeEgGgAhYRoAY6FVACwAoUJj4VUAaGEhAKMhVgCooSEA42FWAAAiAEJZYQACQCGAQKOhVgCpoSEAWWEAAUAhAEGj4VYAqaEhAFlhAAFAIYBBWWGAAGGhGgCh4RoAwCEAQ",
    "tmhgAAjIlcAFACiQxOAA4AjYlcAKCIiAG0igAGjolcA4+JXACMjWABgYoABGSIBARPAAIBAI4AMgCMARuEjGwBZY4ABHqIAAJ9i/n8AIgBDGaKAABdiAAATgACAACKAQmMiVwAZYgABGwCAAGEBAAAEBXR5cGUEBnRhYmxlBCZ2NjItY2hhcm",
    "FjdGVyLWNvbG9yLXJlZnJlc2gtc2tpbi1tZXNoBBZjdXN0b21fZG9uZ2RvbmdfYnVpbGQEHWN1c3RvbV9kb25nZG9uZ190b2dnbGVfc3RhdGUEB2lwYWlycwQKbm9fcmVjb2lsBAljb252ZXJnZQQEYWltBAthbnRpX3NoYWtlAQEBAAQeY3V",
    "zdG9tX2NoYXJhY3Rlcl9jb2xvcl9hY3RpdmUEIGN1c3RvbV9jaGFyYWN0ZXJfeHJheV9tYXRlcmlhbHMEHWN1c3RvbV9jaGFyYWN0ZXJfeHJheV9tZXNoZXMEHWN1c3RvbV9jaGFyYWN0ZXJfbm9ybWFsX3NlZW4EJWN1c3RvbV9jaGFyYWN0",
    "ZXJfc2Nhbl9hY3Rvcl9zbmFwc2hvdAAEI2N1c3RvbV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9jdXJzb3ITAQAAAAAAAAAULWN1c3RvbV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9zbmFwc2hvdF9hdHRlbXB0E///////////FC9jdXN0b21fY2hhc",
    "mFjdGVyX3NjYW5fYWN0b3Jfc25hcHNob3RfY2hhcmFjdGVyBB1jdXN0b21fZG9uZ2RvbmdfYXBpX3NldHRpbmdzBAl3cmFwcGVycwQeY3VzdG9tX2NoYXJhY3Rlcl94cmF5X2VuYWJsZWQEBHJlZBMAAAAAAAAAAAQGZ3JlZW4EB+e6ouiJsg",
    "QH57u/6ImyBAVub25lBArkuI3nnYDoibIUYy9HYW1lL01hdGVyaWFsTGliL01hdGVyaWFscy9DaGFyYWN0ZXIvQXJtc0VmZmVjdC9NSV9YcmF5T3V0TGluZV8wM19MUV9SZWQuTUlfWHJheU91dExpbmVfMDNfTFFfUmVkFHUvR2FtZS9NYXR",
    "lcmlhbExpYi9NYXRlcmlhbHMvQ2hhcmFjdGVyL0FybXNFZmZlY3QvTUlfU2ltcGxlX1hyYXlPdXRMaW5lX1Njb3V0X0dyZWVuLk1JX1NpbXBsZV9YcmF5T3V0TGluZV9TY291dF9HcmVlbgQKQmFzZUNvbG9yBApTa2luQ29sb3IECzJVRHll",
    "Q29sb3IECUR5ZUNvbG9yBAZDb2xvcgQKVGludENvbG9yBA5CYXNlQ29sb3JUaW50BA1CYXNlQ29sb3JBZGQEClJvb3RDb2xvcgQJVGlwQ29sb3IED0hpZ2hsaWdodENvbG9yBApNYWluQ29sb3IEDVByaW1hcnlDb2xvcgQKQm9keUNvbG9yB",
    "A9DaGFyYWN0ZXJDb2xvcgQKQ29sb3JUaW50BA5FbWlzc2l2ZUNvbG9yBAlSaW1Db2xvcgQNRnJlc25lbENvbG9yBA1PdXRsaW5lQ29sb3IDAAAAAAAA0D8TBAAAAAAAAAATAgAAAAAAAAATCAAAAAAAAAAEB3VucGFjawQdV2VhcG9uQmFzZS",
    "9XZWFwb25SZWNvaWxUYWJsZQQdd2VhcG9uQmFzZS93ZWFwb25yZWNvaWx0YWJsZQQSV2VhcG9uUmVjb2lsVGFibGUULi9HYW1lL0RhdGFUYWJsZXMvV2VhcG9uQmFzZS9XZWFwb25SZWNvaWxUYWJsZQQdV2VhcG9uQmFzZS9XZWFwb25TcHJ",
    "lYWRUYWJsZQQdd2VhcG9uQmFzZS93ZWFwb25zcHJlYWR0YWJsZQQSV2VhcG9uU3ByZWFkVGFibGUULi9HYW1lL0RhdGFUYWJsZXMvV2VhcG9uQmFzZS9XZWFwb25TcHJlYWRUYWJsZQQkV2VhcG9uQmFzZS9XZWFwb25NYWluQXR0cmlidXRl",
    "VGFibGUEJHdlYXBvbkJhc2Uvd2VhcG9ubWFpbmF0dHJpYnV0ZXRhYmxlBBlXZWFwb25NYWluQXR0cmlidXRlVGFibGUEIldlYXBvbkJhc2UvV2VhcG9uQWltQXNzaXN0b3JUYWJsZQQid2VhcG9uQmFzZS93ZWFwb25haW1hc3Npc3RvcnRhY",
    "mxlBBdXZWFwb25BaW1Bc3Npc3RvclRhYmxlFDMvR2FtZS9EYXRhVGFibGVzL1dlYXBvbkJhc2UvV2VhcG9uQWltQXNzaXN0b3JUYWJsZRQsV2VhcG9uQmFzZS9XZWFwb25BaW1Bc3Npc3RvclRhYmxlRm9yR2FtZXBhZBQsd2VhcG9uQmFzZS",
    "93ZWFwb25haW1hc3Npc3RvcnRhYmxlZm9yZ2FtZXBhZAQhV2VhcG9uQWltQXNzaXN0b3JUYWJsZUZvckdhbWVwYWQUPS9HYW1lL0RhdGFUYWJsZXMvV2VhcG9uQmFzZS9XZWFwb25BaW1Bc3Npc3RvclRhYmxlRm9yR2FtZXBhZAQlV2VhcG9",
    "uQmFzZS9XZWFwb25Bc3Npc3RlZEFpbWluZ1RhYmxlBCV3ZWFwb25CYXNlL3dlYXBvbmFzc2lzdGVkYWltaW5ndGFibGUEGldlYXBvbkFzc2lzdGVkQWltaW5nVGFibGUUNi9HYW1lL0RhdGFUYWJsZXMvV2VhcG9uQmFzZS9XZWFwb25Bc3Np",
    "c3RlZEFpbWluZ1RhYmxlFCpXZWFwb25CYXNlL1dlYXBvbkFzc2lzdGVkQWltaW5nR3JvdXBUYWJsZRQqd2VhcG9uQmFzZS93ZWFwb25hc3Npc3RlZGFpbWluZ2dyb3VwdGFibGUEH1dlYXBvbkFzc2lzdGVkQWltaW5nR3JvdXBUYWJsZRQ7L",
    "0dhbWUvRGF0YVRhYmxlcy9XZWFwb25CYXNlL1dlYXBvbkFzc2lzdGVkQWltaW5nR3JvdXBUYWJsZQQdV2VhcG9uQmFzZS9XZWFwb25CdWxsZXRUYWJsZQQdd2VhcG9uQmFzZS93ZWFwb25idWxsZXR0YWJsZQQSV2VhcG9uQnVsbGV0VGFibG",
    "UULi9HYW1lL0RhdGFUYWJsZXMvV2VhcG9uQmFzZS9XZWFwb25CdWxsZXRUYWJsZQQUZW5hYmxlc3ByaW5nZ3Vua2ljawEBBBFyZWNvaWxzaGFrZXBpdGNoBBpyZWNvaWxzaGFrZXBpdGNod2l0aGN1cnZlBA9yZWNvaWxzaGFrZXlhdwQYcmV",
    "jb2lsc2hha2V5YXd3aXRoY3VydmUEHHNpZGVhaW1pbmdyZWNvaWxzaGFrZWZhY3RvcgQOc3ByaW5nZ3Vua2ljawQYd2VhcG9uZGF0YXNwcmluZ2d1bmtpY2sEEndlYXBvbnJlY29pbHNoYWtlBB93ZWFwb25yZWNvaWxzaGFrZWVsZW1lbnRj",
    "b25maWcEJHdlYXBvbnJlY29pbHNoYWtlbWFudWFsY3VydmVjb25maWdzBBt3ZWFwb25yZWNvaWxzaGFrZXdpdGhjdXJ2ZQQZYkxpbWl0U3ByZWFkUmVjb3ZlclNwZWVkBBlEaXN0cmlidXRpb25JblNwcmVhZEZ1bmMEGURpc3RyaWJ1dGlvb",
    "kluU3ByZWFkVHlwZQQMRXh0cmFTcHJlYWQEHEZpcmVTcHJlYWRFeHRyYVJlY292ZXJDdXJ2ZQQRRmlyZVNwcmVhZEZhY3RvcgQQRmlyZVNwcmVhZEl0ZW1zBBdGaXJlU3ByZWFkUmVjb3ZlclNwZWVkBBdMdWFEaXNwbGF5U3ByZWFkRmFjdG",
    "9yBBlMdWFEaXNwbGF5U3ByZWFkVUlGYWN0b3IEB1NwcmVhZAQJU3ByZWFkSWQEClNwcmVhZE1heAQPU3ByZWFkTWF4RmluYWwEE1NwcmVhZFJlY292ZXJTcGVlZAQURW5hYmxlU3ByaW5nR3VuS2ljawQRUmVjb2lsU2hha2VQaXRjaAQaUmV",
    "jb2lsU2hha2VQaXRjaFdpdGhDdXJ2ZQQPUmVjb2lsU2hha2VZYXcEGFJlY29pbFNoYWtlWWF3V2l0aEN1cnZlBBxTaWRlQWltaW5nUmVjb2lsU2hha2VGYWN0b3IEDlNwcmluZ0d1bktpY2sEGFdlYXBvbkRhdGFTcHJpbmdHdW5LaWNrBBJX",
    "ZWFwb25SZWNvaWxTaGFrZQQfV2VhcG9uUmVjb2lsU2hha2VFbGVtZW50Q29uZmlnBCRXZWFwb25SZWNvaWxTaGFrZU1hbnVhbEN1cnZlQ29uZmlncwQbV2VhcG9uUmVjb2lsU2hha2VXaXRoQ3VydmUEDGJUYWtlRWZmZWN0BBBab29taW5nS",
    "W5Db25maWcEFUFjdGl2ZVRyYWNraW5nQ29uZmlnBBdDcm9zc2hhaXJEYW1waW5nQ29uZmlnBBlDcm9zc2hhaXJGb2xsb3dpbmdDb25maWcED1Nob290aW5nQ29uZmlnBA9BbmdsZVRocmVzaG9sZAQOQ29uZUFuZ2xlQmFzZQQPQ29uZUFuZ2",
    "xlUG93ZXIED0NvbmVIZWlnaHRCYXNlBBBDb25lSGVpZ2h0UG93ZXIEF0NvbmVGaWx0ZXJBY3RvcnNNYXhOdW0EB0NkVGltZQQKRGVsdGFUaW1lBBJFZmZlY3RpdmVGT1ZSYW5nZQQJSW5SYW5nZUEECUluUmFuZ2VCBA1JbnRlcnZhbFRpbWU",
    "EC0xvY2tvblRpbWUEHk91dGVyMklubmVyUmFuZ2VGb3JSYXlDaGVja2VyBApPdXRSYW5nZUEECk91dFJhbmdlQgQMUGl0Y2hGYWN0b3IED1BpdGNoRmFjdG9yQWRzBA9QaXRjaEZhY3RvckhpcAQVUGl0Y2hGYWN0b3JMb2Nrb25BZHMEFVBp",
    "dGNoRmFjdG9yTG9ja29uSGlwBA1QaXRjaFJhdGVBZHMEDVBpdGNoUmF0ZUhpcAQbUGxheWVySW5wdXRBd2F5VGFyZ2V0QW5nbGUEG1BsYXllcklucHV0QXdheVRhcmdldFZhbHVlBBZQbGF5ZXJJbnB1dFJlY29yZFRpbWUEC1JhbmdlU2Nhb",
    "GUECllhd0ZhY3RvcgQNWWF3RmFjdG9yQWRzBA1ZYXdGYWN0b3JIaXAEE1lhd0ZhY3RvckxvY2tvbkFkcwQTWWF3RmFjdG9yTG9ja29uSGlwBAtZYXdSYXRlQWRzBAtZYXdSYXRlSGlwBBBDb25lRmlsdGVyQm9uZXMEFENvbmVGaWx0ZXJCb2",
    "5lc09mQUkEEkVuYWJsZURpc3RhbmNlTWluBBJFbmFibGVEaXN0YW5jZU1heAQVQXNzaXN0ZWRCb3hNaW5SYWRpdXMEFUFzc2lzdGVkQm94TWF4UmFkaXVzBBlBc3Npc3RlZEJveFZlcnRpY2FsU2NhbGUEE1BhdXNlVGltZUFmdGVyRmlyZQQ",
    "WSG9yaXpvbnRhbFJlY29pbFNwZWVkBBRWZXJ0aWNhbFJlY29pbFNwZWVkBBZSZWNvaWxTcGVlZFRvdWNoUGFyYW0EG1JlY29pbFJlZHVjZUFjdGl2YXRpb25UaW1lBCFFbmFibGVEaXN0YW5jZU1pbkZvclJvdGF0ZVN0aWNreQQhRW5hYmxl",
    "RGlzdGFuY2VNYXhGb3JSb3RhdGVTdGlja3kEJEFzc2lzdGVkQm94TWluUmFkaXVzRm9yUm90YXRlU3RpY2t5BCRBc3Npc3RlZEJveE1heFJhZGl1c0ZvclJvdGF0ZVN0aWNreQQoQXNzaXN0ZWRCb3hWZXJ0aWNhbFNjYWxlRm9yUm90YXRlU",
    "3RpY2t5BAxTdGlja3lQYXJhbQQSTWFnbmV0aWNDRFNlY29uZHMEG01hZ25ldGljRW5hYmxlRm9jdXNTZWNvbmRzBCNFbmFibGVEaXN0YW5jZU1pbkZvck1hZ25ldGljU3RpY2t5BCNFbmFibGVEaXN0YW5jZU1heEZvck1hZ25ldGljU3RpY2",
    "t5BCZBc3Npc3RlZEJveE1pblJhZGl1c0Zvck1hZ25ldGljU3RpY2t5BCZBc3Npc3RlZEJveE1heFJhZGl1c0Zvck1hZ25ldGljU3RpY2t5FCpBc3Npc3RlZEJveFZlcnRpY2FsU2NhbGVGb3JNYWduZXRpY1N0aWNreQQfSG9yaXpvbnRhbFJ",
    "lY29pbFNwZWVkRm9yWm9vbUluBB1WZXJ0aWNhbFJlY29pbFNwZWVkRm9yWm9vbUluBBlSZWNvaWxTcGVlZERpc3RhbmNlQ3VydmUEB1JhZGl1cwQTYlByZXZlbnRNaXNzRW5hYmxlBCBQcmV2ZW50TWlzc0FkZEJ1bGxldFJhZGl1c0RlbHRh",
    "BBJQcmV2ZW50TWlzc051bWJlcgQQUHJldmVudE1pc3NUaW1lBA9BaW1pbmdTaW5nbGVJZAQNQWltaW5nQXV0b0lkBA5BaW1pbmdCdXJzdElkBBJBaW1pbmdTaW5nbGVJZFBWRQQQQWltaW5nQXV0b0lkUFZFBBFBaW1pbmdCdXJzdElkUFZFB",
    "AVIZWFkBAVOZWNrBAdTcGluZTIEBUhpcHMECExlZnRMZWcECVJpZ2h0TGVnBAJYBAJZBAphbXBsaXR1ZGUBAQQNYW1wbGl0dWRlbWF4BA1hbXBsaXR1ZGVtaW4ECmZyZXF1ZW5jeQQLaG9yaXpvbnRhbAQJbWF4dmFsdWUECW1pbnZhbHVlBA",
    "hwZXJjZW50BAZwaXRjaAQMcHJvYmFiaWxpdHkEBXJvbGwEBnNjYWxlBAl2ZXJ0aWNhbAQCeAQCeQQEeWF3BAJ6BApBbXBsaXR1ZGUEDUFtcGxpdHVkZU1heAQNQW1wbGl0dWRlTWluBApGcmVxdWVuY3kEC0hvcml6b250YWwECU1heFZhbHV",
    "lBAlNaW5WYWx1ZQQIUGVyY2VudAQGUGl0Y2gEDFByb2JhYmlsaXR5BA1SYW5kb21WYWx1ZXMEBVJvbGwEBlNjYWxlBAlWZXJ0aWNhbAQEWWF3BAJaBAdFbmFibGUECEVuYWJsZWQECGJFbmFibGUECWJFbmFibGVkEwEAAAAAAAAABA5jb25l",
    "YW5nbGViYXNlAwAAAAAAAC5ABA9jb25lYW5nbGVwb3dlcgMAAAAAAAAIQAQPY29uZWhlaWdodGJhc2UDAAAAAAAKqkAEEGNvbmVoZWlnaHRwb3dlcgQpY3Jvc3NoYWlyZGFtcGluZ2NvbmZpZ2VmZmVjdGl2ZWZvdnJhbmdleAMAAAAAAAAmQ",
    "AQpY3Jvc3NoYWlyZGFtcGluZ2NvbmZpZ2VmZmVjdGl2ZWZvdnJhbmdleQMAAAAAAEyYQAQpY3Jvc3NoYWlyZGFtcGluZ2NvbmZpZ3Jhbmdlc2NhbGVpbnJhbmdlYgMAAAAAoEbgQBQqY3Jvc3NoYWlyZGFtcGluZ2NvbmZpZ3Jhbmdlc2NhbG",
    "VvdXRyYW5nZWIUK2Nyb3NzaGFpcmZvbGxvd2luZ2NvbmZpZ2VmZmVjdGl2ZWZvdnJhbmdleQQlY3Jvc3NoYWlyZm9sbG93aW5nY29uZmlnaW50ZXJ2YWx0aW1lAwAAAAAAAOA/BCdjcm9zc2hhaXJmb2xsb3dpbmdjb25maWdwaXRjaGZhY3R",
    "vcmFkcwMAAAAAAADwPwQnY3Jvc3NoYWlyZm9sbG93aW5nY29uZmlncGl0Y2hmYWN0b3JoaXAULWNyb3NzaGFpcmZvbGxvd2luZ2NvbmZpZ3BpdGNoZmFjdG9ybG9ja29uYWRzAwAAAAAAAABAFC1jcm9zc2hhaXJmb2xsb3dpbmdjb25maWdw",
    "aXRjaGZhY3RvcmxvY2tvbmhpcBQrY3Jvc3NoYWlyZm9sbG93aW5nY29uZmlncmFuZ2VzY2FsZWlucmFuZ2ViFCxjcm9zc2hhaXJmb2xsb3dpbmdjb25maWdyYW5nZXNjYWxlb3V0cmFuZ2VhBCVjcm9zc2hhaXJmb2xsb3dpbmdjb25maWd5Y",
    "XdmYWN0b3JhZHMEJWNyb3NzaGFpcmZvbGxvd2luZ2NvbmZpZ3lhd2ZhY3RvcmhpcBQrY3Jvc3NoYWlyZm9sbG93aW5nY29uZmlneWF3ZmFjdG9ybG9ja29uYWRzFCtjcm9zc2hhaXJmb2xsb3dpbmdjb25maWd5YXdmYWN0b3Jsb2Nrb25oaX",
    "AEC2xvY2tvbnRpbWUDAAAA4E1iUD8EFXNob290aW5nY29uZmlnY2R0aW1lBBhzaG9vdGluZ2NvbmZpZ2RlbHRhdGltZQMAAACgmZm5PwQhc2hvb3Rpbmdjb25maWdlZmZlY3RpdmVmb3ZyYW5nZXgDAAAAAAAAJEAEIXNob290aW5nY29uZml",
    "nZWZmZWN0aXZlZm92cmFuZ2V5BB1zaG9vdGluZ2NvbmZpZ3BpdGNoZmFjdG9yYWRzBB1zaG9vdGluZ2NvbmZpZ3BpdGNoZmFjdG9yaGlwBCFzaG9vdGluZ2NvbmZpZ3Jhbmdlc2NhbGVpbnJhbmdlYgQic2hvb3Rpbmdjb25maWdyYW5nZXNj",
    "YWxlb3V0cmFuZ2VhBCJzaG9vdGluZ2NvbmZpZ3Jhbmdlc2NhbGVvdXRyYW5nZWIEG3Nob290aW5nY29uZmlneWF3ZmFjdG9yYWRzBBtzaG9vdGluZ2NvbmZpZ3lhd2ZhY3RvcmhpcBPpAwAAAAAAAAMAAAAAgGnmQBQ8Y3Jvc3NoYWlyZGFtc",
    "GluZ2NvbmZpZ291dGVyMmlubmVycmFuZ2Vmb3JyYXljaGVja2VyaW5yYW5nZWIUPWNyb3NzaGFpcmRhbXBpbmdjb25maWdvdXRlcjJpbm5lcnJhbmdlZm9ycmF5Y2hlY2tlcm91dHJhbmdlYgMAAAAAgLPFQBQsY3Jvc3NoYWlyZm9sbG93aW",
    "5nY29uZmlncmFuZ2VzY2FsZW91dHJhbmdlYgMAAACgmZmpPwMAAAAAgLPVQBPqAwAAAAAAAAMAAAAAgLPlQAMAAAAAgIfDQBPrAwAAAAAAAAMAAAAAAJCWQAMAAAAAAAAYQBP5KgAAAAAAAAMAAABA4XqEPxPsAwAAAAAAAAMAAAAAAGG+QAM",
    "AAAAAAFi7QAQFaGVhZAQFbmVjawQHc3BpbmUyBAVoaXBzBAhsZWZ0bGVnBAlyaWdodGxlZwQGY2hlc3QEBGxlZwQFZnJlZQEBBBxzZXRfZG9uZ2RvbmdfZmVhdHVyZV9jb25maWcEFnNldF9kb25nZG9uZ19haW1fcGFydAQNc2V0X2FpX2Nv",
    "bG9yBBZzZXRfcmVhbF9wbGF5ZXJfY29sb3IEE3NldF9jaGFyYWN0ZXJfeHJheQQUY3VzdG9tX2FpX2NvbG9yX2tleQQEcmVkBBhjdXN0b21fYWlfY29sb3JfZW5hYmxlZAQFbm9uZQQZY3VzdG9tX2FpX2NvbG9yX2xhc3Rfa2V5BBZjdXN0b",
    "21fcmVhbF9jb2xvcl9rZXkEBmdyZWVuBCZpbnN0YWxsX2NoYXJhY3Rlcl9jb2xvcl9zZXR0aW5nX2hvb2tzBAdyYXdzZXQEA19HBCFJbnN0YWxsRG9uZ0RvbmdOYXRpdmVTZXR0aW5nUGFnZQQUY3VzdG9tX2FpX2NvbG9yX2tleQQWY3VzdG",
    "9tX3JlYWxfY29sb3Jfa2V5EwAAAAAAAAAABAdpcGFpcnMDmpmZmZmZ2T8DMzMzMzMz8z8DZmZmZmZmBkABAAAAAABtAAAAAD0DAAA/AwAAAAAECgAAAOYAAADlAIAA5gAAACgAQABtAAAArUAAAKyAwIAaAIABGwAAABsAgAADAAAABA1zZXR",
    "tZXRhdGFibGUEB19fbW9kZQQCawEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZAMAAGYDAAAAAQUNAAAAJgEAACUBgAAmAQAALUAAAGhAQACjgAAA4gAAAFmAAAAsQACAYgAAACBAAAAbAAABGwCAAAMAAAAEAm4EB3NlbGVjdAQCIwEAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAaAMAAGwDAAACAAYRAAAAZgEAAGUBgABmAQAAFABAABNAAICmAAAAmwAAAahAQADhAAAAmcAAAZcAAAATQACAGEGAARMAAIAmAQAAGwEAARsAgAACAAAAAAQGcGNhbGwBAAAAAAABAAAAAGoDAABqAwAAAAADBwAAA",
    "KYAAAClAIAApgAAACcAgAAoAAAAGwAAARsAgAAAAAAAAgAAAAEAAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG4DAAB2AwAAAgEKKwAAAGYCAABlAoAAZgIAAKcAAADAAAAAAAGAAJmAgAHoAMAAAAEAAdmAAAFUQMABE4AAgOUAAA",
    "AmAQAA2wCAAeiAwAAAAQABQAEAAKIBAADZAAEA1wAAABPAAIClAYAAwAEAAgACgAKbAQACqIHAAMABAAEiAgAAmQEBAEABAAQAAYADwAAAA9cAAAATwACApQGAAMABAAIAAoACmwEAAqUBAADmAQAAmwGAARsAgAADAAAABAV0eXBlBAlmdW5",
    "jdGlvbgQGcGNhbGwCAAAAARMAAAAAAAAAAAAAAAAAAAAAAAAAeAMAAIADAAACAQsrAAAApgIAAKUCgACmAgAApwAAAMAAAAAAAYAAmYCAAegAwAAAAQAB2YAAAVRAwAETgACA5QAAACYBAADbAIAB6IDAAAABAAFiAQAA2QABANcAAAATwACA",
    "pQGAAMABAAIAAoACmwEAAqiBwADAAQABAAIAAGICAACZAQEAQAEABAABgAPAAAAD1wAAABPAAIClAYAAwAEAAgACgAKbAQACpQEAAOYBAACbAYABGwCAAAMAAAAEBXR5cGUECWZ1bmN0aW9uBAZwY2FsbAIAAAABEwAAAAAAAAAAAAAAAAAAA",
    "AAAAACCAwAAhAMAAAIABw8AAACmAQAApQGAAKYBAACoAEAA5wCAAAABAABAAYAA2QCAAZmAAABUQEABEwAAgKVAAAClAIAAmwAAARsAgAACAAAABAV0eXBlBAlmdW5jdGlvbgIAAAAAAAETAAAAAAAAAAAAAAAAAAAAAACGAwAAjQMAAAEACy",
    "EAAACmAgAApQKAAKYCAAAUAEAAE0AAgGNAAABbAAABaIBAAK0AAAHjwAAAIwEBAKBAAAFZAAEBE8ACgKcBgADAAQAAAAKAApnBgAGXAQAAE0ABgFQAwAMTwACAKEJBAEACgAMaAgABGwIAAF6AAADfQPx/aEBBAIAAAABaAAABWwAAABsAgAA",
    "GAAAAAAQBBAdpcGFpcnMEDEdldEZ1bGxOYW1lBAhHZXROYW1lBAl0b3N0cmluZwIAAAAAAAEUAAAAAAAAAAAAAAAAAAAAAACPAwAAmAMAAAEABx0AAACmAQAApQGAAKYBAABoAEAAqEBAAMAAAABZgIABVIDAABMAAIBbAAABqABAAOhAQAAj",
    "wQAAmYCAAegAQQAAAQAB2YAAARRAwQETgAGA6IBBAAABAAFAAQAA2cCAAdcAAAATAACAGwEAAeYAAADbAAABGwCAAAcAAAAEB3Jhd2dldAQDX0cABAdpbXBvcnQEBXR5cGUECWZ1bmN0aW9uBAZwY2FsbAEAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAAmgMAAKMDAAACAAshAAAApgIAAKUCgACmAgAAqABAAOhAQAAjgQAAmYCAAecAgAAAAQABY8EAANmAgAEoAUEAQAGAARmBAAFUQEECE4AAgAABgAAZQYAAGwCAACiBQQBAAYABgAEAAMABgAAZgQACF0EAABNAAYBogUEAgAGAAcABAAEAAg",
    "AAQAKAAFlBgAIbAIAABwAAAAQHcmF3Z2V0BANfRwQGVGltZXIECkRlbGF5Q2FsbAQFdHlwZQQJZnVuY3Rpb24EBnBjYWxsAgAAAAAAARMAAAAAAAAAAAAAAAAAAAAAAKUDAACrAwAAAQAGHgAAAGYBAABlAYAAZgEAABQAQAATQACAZQAAAFs",
    "AAAFoQEAAqIBAAOPAAABZgIABqABBAMAAgACZgAABVEBBARNAAIClAIAAmwAAAaiAQQDAAIAAAAEAAJnAgAGXAAAAE4AAgFTAwQETAACAJUEAACUBgAAbAQABGwCAAAgAAAAABAdyYXdnZXQEA19HBAhpc3ZhbGlkBAV0eXBlBAlmdW5jdGlv",
    "bgQGcGNhbGwBAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFgQAABgEAAABAAYRAAAAZgEAAGUBgABmAQAAaABAAGlAwACogEAA2EAAABMAAIDjwAAAmQAAAVmAAABBAMEA40ABACPBAABaAAACWwAAABsAgAAGAAAABAdzdHJpbmcEBmxvd2VyB",
    "Al0b3N0cmluZwQBBAVnc3ViBAZbXiV3XQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGgQAAB0EAAAAAAUTAAAAJgEAACUBgAAmAQAAKABAAGhAQACjgAAAGYCAAWcAgACAAAAA48AAAFmAgAFXQAAAE8AAgGgAQACoQEAA48AAAFmAgAFbAAABGw",
    "CAAAQAAAAEB3Jhd2dldAQDX0cEB0ZhY2FkZQQNVGFibGVNYW5hZ2VyAgAAAAAAARMAAAAAAAAAAAAAAAAAAAAAAB8EAAAlBAAAAgEIHwAAAOYBAADlAYAA5gEAAKgAQADAAAAAmYAAAVRAQAETgACApQAAAOYAAACbAIABqIBAAMAAAAAAAYA",
    "AYgEAAJnAAACXAAAAE4AAgCUBgABAAYABGwGAASiBQABAAQAAogEAABnBAADAAIACgAAAAgABAAFAAYABGwGAARsAgAADAAAABAV0eXBlBAlmdW5jdGlvbgQGcGNhbGwBAAAAAAAAAAAAAAAAAAAAAAAAAAAAACcEAAAtBAAAAQAIFAAAAOYB",
    "AADlAYAA5gEAAGcAAABZgIAApwCAAMAAgAAjAQAAmYCAAecAAAEAAQABQAGAAIABAADZwAAC1wAAABMAAIAbAQABZgEAAFsBAAEbAIAAAQAAAAQJR2V0VGFibGUDAAAAAR8BEwEgAAAAAAAAAAAAAAAAAAAAAAAvBAAAOwQAAAEABhsAAABmA",
    "QAAZQGAAGYBAABoAEAAqEDAAMAAgACZgAABVIBAAROAAICtAAAAQAAAASpAAICpAIAA6EDAAAABAAHZgAABVIDAAROAAYDtgAAALQEAAOwAgYEtAQAA7AABgoAAgAFsgAAAmwAAARsAgAAFAAAABCJjdXN0b21fZG9uZ2RvbmdfZmVhdHVyZV",
    "9zbmFwc2hvdHMEBXR5cGUEBnRhYmxlBAhyZWNvcmRzBAVzZWVuAgAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAD0EAABMBAAABAALMAAAAKYCAAClAoAApgIAAFQAwAATQACAFABAARNAAIAlAQAAGwEAAScBAABAAYAAgAEAARmBgAEUwAACE0A",
    "AgGUBgABbAQABZwGAAIABAABZgQABqEFAAcABgACZgQAB44EAAChCQAFAAgABGYIAAZIBAgPpwcAC6YGBA1QAwQMTgAKA6cHAAuwBQQPpQcECKULBAhECAAQCgkEEbcIAAGxCgINsggCEbAKBhOxBAgTogUIBIQIAANoBAAHbAQAAGwCAAAsA",
    "AAAABAl0b3N0cmluZwQCAAQFc2VlbgEBBAhyZWNvcmRzEwEAAAAAAAAABAdvYmplY3QEBGtleQQGdmFsdWUEBnBjYWxsAwAAAAETASIAAAEAAAAASwQAAEsEAAAAAAMHAAAApgAAAKUAgACmAAAAJwCAAGcAAAEqQAAAGwCAAAAAAAADAAAAA",
    "QEBAgEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOBAAAUQQAAAEABQsAAAAmAQAAJQGAACYBAABoAEAAqEDAAMAAgACZgAABFIBAARMAAIBswEAAGwCAAAQAAAAEImN1c3RvbV9kb25nZG9uZ19mZWF0dXJlX3NuYXBzaG90cwQFdH",
    "lwZQQGdGFibGUAAgAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAFMEAABnBAAAAQAMNwAAAOYCAADlAoAA5gIAAGgAQACoQMAAwACAAJmAAAFUgEABE0AAgKUAAACbAAABqQCAAOhAwAAAAQAB2YAAARSAwAETAAGA6EDAACnBQAHZgAABVIDAARO",
    "AAIBsAEEA5QAAANsAAAHlAAAAKcFAAREBAAJjQQEAo4EBAB3BBIApwkABKcIBBGhCwACAAgAEWYIAARSAwARTAgOAacJBBFQAwQRTQgKAaQJCBFQAwQRTggGAaELCAKECAABZggABVwIAAFNCAIDlAIAAU8L/fxyB+n9sAEEA2wAAARsAgAAK",
    "AAAABCJjdXN0b21fZG9uZ2RvbmdfZmVhdHVyZV9zbmFwc2hvdHMEBXR5cGUEBnRhYmxlBAhyZWNvcmRzABMBAAAAAAAAABP//////////wQHb2JqZWN0BARrZXkEBnBjYWxsAgAAAAEAAAABAAAAAF8EAABhBAAAAAAECAAAAOYAAADlAIAA5",
    "gAAACgAQABoQEAAqIBAACyAgAAbAIAAAwAAAAQHb2JqZWN0BARrZXkEBnZhbHVlAQAAAAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABpBAAAcQQAAAEABygAAACmAQAApQGAAKYBAABoAEAAgAAAAFmAAAFUQMAAEwAAgBsAAAFnAI",
    "AAgAAAAOOAAABZgIABqABAAMAAgACZgAABVMBAARMAAIAbAAABqABBAMAAgAAAAQAAmcCAAZdAAAATAAGAKAFBAEABgAAZwQABwACAAoAAAAKXAAAAE0ABgCgBQABAAYABGYEAARRAQQITAACA2wAAARsAAAEbAIAABgAAAAQFdHlwZQQJdXN",
    "lcmRhdGEEDFRhYmxlRXh0ZW5kBAlmdW5jdGlvbgQGcGNhbGwEBnRhYmxlAgAAAAAAARMAAAAAAAAAAAAAAAAAAAAAAHMEAACBBAAAAgAINAAAAOYBAADlAYAA5gEAABQAQAATQACApgAAAJsAAAGnAAAAwAAAAAABgACZgIAB6EDAAAABAAHZ",
    "gAABFIDAARNACIDnAAABAAEAAdmAAAEoQcAAQAGAARmBAAEUwEACE0ACgChBwABAAQAAGYEAARTAQAITAAGAKAHBAGEBAAAZQQABgACAARPBA4AoQcAAQAEAABmBAAEUwEACE4ECgCcBAABAAQAAgAGAABmBgAFoQcAAgAEAAlmBAAEUwMACE",
    "0EAgIAAAAITwf9/mwAAARsAgAAFAAAAAAQFdHlwZQQJdXNlcmRhdGEEBnRhYmxlBAZwY2FsbAMAAAABEwAAASYBAAAAAHkEAAB5BAAAAAADBwAAAKYAAAClAIAApgAAACcAgABnAAABKkAAABsAgAAAAAAAAwAAAAEAAQEBAwAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAAgwQAAIkEAAACAAURAAAAJgEAACUBgAAmAQAApwAAAMAAAACZgAABAAAAAagAwADAAAAAmYAAAVRAQAETAACAGwCAAKiAwADhAAAAmUAAARsAgAADAAAABAV0eXBlBAZ0YWJsZQQGcGNhbGwCAAAAASYAAAE",
    "AAAAAhgQAAIgEAAAAAAoPAAAAZgIAAGUCgABmAgAAKABAAGcAgAAZAAEBEwABgGcBAAGnAYAAwAGAAQACAAJZQQACHoAAAJ8A/n8bAIAAAQAAAAQGcGFpcnMDAAAAAAEBAAEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLBAAAlgQA",
    "AAMACiQAAABmAgAAZQKAAGYCAADnAAAAAAGAAEABAAHZgIABKAHAAEABgAEZgQABFEBAAhPAAYAnAQABQAEAAIABgADAAQABI4IAABlBgAIlAYAAGwEAASgBwABAAYABGYEAARTAQAITwAGAJwEAAUABAACAAYAAwAEAASUCAAAZQYACJQGAA",
    "BsBAAElAQAAGwEAARsAgAAEAAAABAV0eXBlBAdudW1iZXIDAAAAAAAAAAAECGJvb2xlYW4DAAAAARMAAAEjAAAAAAAAAAAAAAAAAAAAAACYBAAArgQAAAQACSAAAAAmAgAAJQKAACYCAAAnAQAAQAGAABmBAAFAAAACVADAABNAAIAVgICAEw",
    "AAgBsAgAAogcAAQAGAABmBAAFUwEACE4AAgFQAQQITAACAGwCAAGlBgAFXAQAAEwAAgBsAgADsQMEAFMBAAhPAAIBnAQABgAGAAOEBAABZQYABGwCAAAYAAAAAEwkAAAAAAAAABAV0eXBlBAZ0YWJsZQQJdXNlcmRhdGEBAQUAAAABJgAAASg",
    "BIwEqAQAAAACgBAAArAQAAAMACjEAAABmAgAAZQKAAGYCAADoAEAAAAEAAdmAAAEUQMABE4ABgOcAgAAnAQABQAEAAIABgADjgQAA2UCAAhMACIDoAEAAAAEAAdmAAAEUwMABE4ABgOcAgAAnAQABQAEAAIABgADlAQAA2UCAAhMABYDnAIAB",
    "AAEAAdmAAAEoAUAAQAGAARmBAAEUAEECEwABgFSAgAETgACAKEFBAGEBAAAZQQABJwEAAmcBAAGAAYAB5wGAAsKBwQMnAgADGUGAAhPB/38bAIAABwAAAAQFdHlwZQQHbnVtYmVyAwAAAAAAAAAABAhib29sZWFuBAZ0YWJsZQQGcGNhbGwTA",
    "QAAAAAAAAAHAAAAAAEAAwEAAAAABAECAQMBAAAAAKgEAACoBAAAAAADBwAAAKYAAAClAIAApgAAACcAgABnAAABKkAAABsAgAAAAAAAAwAAAAEAAQEBAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsAQAAL0EAA",
    "ACAAcdAAAApgEAAKUBgACmAQAApwAAAMAAgACZgAABQAAAARQAwAATAACAGwCAAKcAgADAAAAAAAGAAGNBAACZQAACpwCAAMAAAAAAAYAAY4EAAJlAAAKnAAABwACAACPBAACZgIAB5wCAAQABAAFhAQAA2UCAARsAgAAEAAAAAAQJTWluVmF",
    "sdWUECU1heFZhbHVlBA1SYW5kb21WYWx1ZXMEAAAAASYBKQEnASgBAAAAALYEAAC8BAAAAwAIFAAAAOYBAADlAYAA5gEAAOcAAAAAAQAB2YAAAYAAgAFUAEABE0ACgOcAgAAnAQABQAEAAaNBAADZQAAC5wCAACcBAAFAAQABo4EAANlAAAIb",
    "AIAAAwAAAAAECU1pblZhbHVlBAlNYXhWYWx1ZQMAAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL8EAADPBAAAAgAGDAAAAGYBAABlAYAAZgEAAKcAAADAAIAAmYAAAUAAAAGnAIAAwACAACEBAACZQIABGwCAAAAAAAAGA",
    "AAAASYBKAAAASMBKwEpAQAAAADBBAAAzgQAAAMACTYAAAAmAgAAJQKAACYCAADoAEAAAAEAAdmAAAEUQMABE4ABgOcAgAAnAQABQAEAAIABgADjgQAA2UCAAhNACYDnAIABAAEAAdmAAAGAAIAB5wAAAicBAAFAAQAB2UCAAecAgAInAQABQA",
    "EAAaPBAADZQAAC5wCAAicBAAFAAQABowEBANlAAALnAIACJwEAAUABAAGjQQEA2UAAAucAgAInAQABQAEAAaOBAQDZQAAC5wCAAicBAAFAAQABo8EBANlAAALnAIACJwEAAUABAAGjAQIA2UAAAhsAgAAJAAAABAV0eXBlBAdudW1iZXIDAAA",
    "AAAAAAAAEC0hvcml6b250YWwECVZlcnRpY2FsBAhQZXJjZW50BAxQcm9iYWJpbGl0eQQNQW1wbGl0dWRlTWluBA1BbXBsaXR1ZGVNYXgGAAAAAAIAAwEAAAAABAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADRBAAA3AQAAAIACD8A",
    "AADmAQAA5QGAAOYBAACnAAAAwACAAJmAAAFAAAABFADAABMAAIAbAIAApwCAAMAAAAAnAQABQAGAAKNBAAAZAYABmUAAAKcAgAHAAAAAJwEAAUABgACjgQAAGQGAAZlAAACnAAACwAAAAAABgABjwQAAmUAAAqcAgADAAAAAJwEAAUABgACjA",
    "QEAGQGAAZlAAACnAIABwAAAACcBAAFAAYAAo0EBABkBgAGZQAAApwAAAsAAAAAAAYAAY4EBAJlAAAKnAIABwAAAACcBAAFAAYAAo8EBABkBgAGZQAAApwCAAcAAAAAnAQABQAGAAKMBAgAZAYABmUAAABsAgAAJAAAAAAQXSG9yaXpvbnRhbF",
    "JhbmRvbVJlY29pbAQYSG9yaXpvbnRhbFJhbmRvbVJlY29pbHMEEEhvcml6b250YWxTY2FsZQQVVmVydGljYWxSYW5kb21SZWNvaWwEFlZlcnRpY2FsUmFuZG9tUmVjb2lscwQOVmVydGljYWxTY2FsZQQSSG9yaXpvbnRhbFJlY29pbHMEEFZ",
    "lcnRpY2FsUmVjb2lscwUAAAABJgErAScBLAEpAAAAAAAAAAAAAAAAAAAAAADeBAAA8QQAAAEADEgAAADmAgAA5QKAAOYCAABnAAAAgAAAAFmAAAEAAIAAFABAABMAAIAbAIAAaEDAAK0AAAPjgAAAI8EAAGMBAQCjQQEA44EBACPCAQCgQAAD",
    "WQABAROAAYCnAQAB4wECACcCgAFAAgAAgAKAAhkCgAGZQQAAXoAAAN+A/X9oQMAArQAAAeNAAgAjgQIAoEAAAVkAAQETQASApwEAAOcBgAEAAgAAQAKAAtkBgAGZgQAAVABAAxNAAoDnAQACIwICAEACAAOjwgIA2UEAAucBAAIjAgIAQAIAA",
    "6MCAwDZQQACXoAAAN/A+n9nAIACowACAOcAgAEAAQAAY0EDANkAgAFZQAAAZwCAAqMAAgDnAIABAAEAAGOBAwDZAIABWUAAABsAgAAPAAAAAAQHaXBhaXJzBBlTaW5nbGVPckJ1cnN0U2hvb3RSZWNvaWwEGlNpbmdsZU9yQnVyc3RTaG9vdF",
    "JlY29pbHMEFENvbnRpbnVlU2hvb3RSZWNvaWwEFUNvbnRpbnVlU2hvb3RSZWNvaWxzBBhDb250aW51ZVNob290UmVjb2lsTG9vcAQZQ29udGludWVTaG9vdFJlY29pbExvb3BzBApub19yZWNvaWwEF1NpZGVBaW1pbmdSZWNvaWxGYWN0b3I",
    "EGFNpZGVBaW1pbmdSZWNvaWxGYWN0b3JzBAtIb3Jpem9udGFsBAlWZXJ0aWNhbAQSSG9yaXpvbnRhbFJlY29pbHMEEFZlcnRpY2FsUmVjb2lscwYAAAABJgAAAS0BJwEpASwAAAAAAAAAAAAAAAAAAAAAAA8FAAA7BQAABQAVTAAAACYFAAAl",
    "BYAAJgUAABXAAIATAACAGwCAAGhBQACAAQABWYEAAacBgADAAYAAmYEAARSAwAITQAKA6IEBARTAwAMTgAGA5wGAASMCAQBAAgAAgAKAAONCAQDZQYACGwCAABSAwQITgAGA5wGAASMCAQBAAgAAgAKAAOUCAADZQYACGwCAAOcBAAIAAgAB2",
    "YEAAYAAgAPoQUAAAAIAAdmBAAFUwMEDE0AAgBQAwgMTgACAKYIAAhcCAAATAACAGwCAACzBQAEUwMEDEwABgCcCgAJAAgABoQIAABlCgAEbAIAAKEJCAGcCgAMZAgEBEwADgGcDAASAAwABwAMABlmDgAFUgMIGE4ABgKcDAAPAAwABAAQABk",
    "AEgAaCxMIBwAQAAplDAAMeggAAnwL8fxsAgAAMAAAAEwoAAAAAAAAABAV0eXBlBAdudW1iZXIBAQQLYW50aV9zaGFrZQMAAAAAAAAAAAQIYm9vbGVhbgQGdGFibGUECXVzZXJkYXRhBAdpcGFpcnMAEwEAAAAAAAAACQAAAAAAAR4BLwEjASY",
    "BKAExATABEwEAAAAAIAUAADIFAAADAAwnAAAA5gIAAOUCgADmAgAA5wAAAAABgADZgAABKAHAAEABAAEZgQABFEBAAhNAAoBowQABFIDAAhPABYBnAYABo8EAAMABAAAAAoAAYwIBAFlBgAITAASAFEBBAhOAAYBnAYABo8EAAMABAAAAAoAA",
    "ZQIAAFlBgAITwAGAZwEAAoABAADAAYAAAAIAAWcCgAJCgsEEpwIAA1lBAAMbAIAABwAAAAQFdHlwZQQHbnVtYmVyAQEEC2FudGlfc2hha2UDAAAAAAAAAAAECGJvb2xlYW4TAQAAAAAAAAAHAAAAAAEAAAACAAMABgEDAQQAAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAD0FAABaBQAAAQAPVgAAAKYDAAClA4AApgMAAGcAAACAAAAAWYAAAQAAgAAUAEAAEwAAgBsAgABnAIAAgAAAAONAAABZgIABVADAABNAAoCnAAAB44AAAAABgABjwQAAmUAAAqcAAAHjgAAAAAGAAGMBAQCZQA",
    "ACqEDBAecAAAKZAAEBEwANgKYBAADogcEBJwKAAtkBAQETgAGAJwMAA0ADgAUZgwABFEABBhNAAICAAYAFE0AAgN6BAABfgv1/VABAAxMACYDnAYADAAIAAEACAAPZgYABVADAAxOAB4AowsEBQAKAAxmCAAEUAEIEE4ABgCcCAARjggAAgAI",
    "AAMACAAMjQwIAGUKAAhOABIAowsEBQAKAAxmCAAEUgEIEE4ABgCcCAARjggAAgAIAAMACAAMlAwAAGUKAAhOAAYAnAoAEQAIAAIACAAPAAoADI8MCAG0DAAAZQgADnkAAAB8B8n8bAIAADAAAAAAEHFNpZGVBaW1pbmdSZWNvaWxTaGFrZUZh",
    "Y3RvcgQLYW50aV9zaGFrZQQLSG9yaXpvbnRhbAQJVmVydGljYWwEBnBhaXJzBAdpcGFpcnMEBXR5cGUEB251bWJlcgMAAAAAAAAAAAQIYm9vbGVhbhMAAAAAAAAAAAoAAAABJgEnASkAAAEcAR0BHgETASMBMQAAAAAAAAAAAAAAAAAAAAAAX",
    "AUAAIsFAAAGABhyAAAA5gUAAOUFgADmBQAAFcAAgBMAAIAbAIAApwEAAMABgACZgQAB6EHAAOmBwAMAAgADY8IAAKMCAQDlAoAA2YGAAhRAwQMTgASA6EHAAOmBwAMAAgADY4IBAKMCAQDlAoAA2YGAAhRAwQMTQAKA6EHAAOmBwAMAAgADY8",
    "IBAKMCAQDlAoAA2YGAAhRAwQMTAACA5UEAAOUBgABUAMICE4AAgAACgAMTQACAJUIAACUCgAAXAgAAE8AFgGhCwgCAAgABWYIAARSAwgQTgAGAZwIAAaPCAgDAAgAAAAOAAGMDAwBZQoACGwCAAGhCwgCAAgABWYIAARRAwwQTgAGAZwIAAaP",
    "CAgDAAgAAAAOAAGUDAABZQoACGwCAAGcCgAGAAgABWYIAAYAAgARoQsIAgAIAAVmCAAFUgMMEE0AAgBTAwwQTgACAqYIAApcCAAATAACAGwCAACwBQgEUgMMEEwABgKcCAALAAgABIQMAAJlCgAEbAIAAqALEAOcCAAOZAgEBE0ADgOcDgAMA",
    "BAABQAQAB9mDgAFUQMEHE8ABgCcEgAJABAABgAQAB8AEgAcCRcQBQAUAAoAFAAQZRIADnoIAAB/D+38bAIAAEgAAABMKAAAAAAAAAAQHc3RyaW5nBAVmaW5kBAdzcHJlYWQTAQAAAAAAAAAABAtkaXNwZXJzaW9uBAZibG9vbQEBBAV0eXBlB",
    "AdudW1iZXIECWNvbnZlcmdlAwAAAAAAAAAABAhib29sZWFuBAZ0YWJsZQQJdXNlcmRhdGEEB2lwYWlycxMBAAAAAAAAAAgAAAABHgAAASMBJgEoATMBHQETAQAAAAByBQAAewUAAAMACw0AAACmAgAApQKAAKYCAADnAAAAAAEAAEABgACAAQ",
    "AB5wGAAMIBwAMnAgABZwKAAdlAgAMbAIAAAQAAABMBAAAAAAAAAAQAAAAABQEDAQQBCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATAYAAFAGAAAEAAcSAAAApgEAAKUBgACmAQAAKAFAAEABAAAZgQABGEAAAhMAAIAAAIABFUAAABN",
    "AAIAAAIAAE4AAgBUAAAETAACAAAAAARsAAAEbAIAAAQAAAAQJdG9udW1iZXIBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFIGAABUBgAAAAAGCwAAAGYBAABlAYAAZgEAACcAAABoAMAAo0AAAOOAAAAjwQAAGgCAAhsAAAAbAIAABAAAAAQRY3Vz",
    "dG9tX2FpbV9zcGVlZBMBAAAAAAAAABNkAAAAAAAAABMyAAAAAAAAAAIAAAABNQEAAAAAAAAAAAAAAAAAAAAAAABWBgAAWAYAAAAABgsAAABmAQAAZQGAAGYBAAAnAAAAaADAAKNAAADjgAAAI8EAABoAgAIbAAAAGwCAAAQAAAAEEWN1c3Rvb",
    "V9haW1fcmFuZ2UTAQAAAAAAAAATaAEAAAAAAAATWgAAAAAAAAACAAAAATUBAAAAAAAAAAAAAAAAAAAAAAAAWgYAAF4GAAAAAAMPAAAApgAAAKUAgACmAAAAJwAAABmAgAAWAEAAE0AAgEcAQABbAAABQwBAAEdAwABEgMAAQkCAgVsAAAEbAI",
    "AABAAAAAMAAAAAAIBWQAMAAAAAAOBwQAMAAAAAAAAUQAMAAAAAAADwPwEAAAABNwAAAAAAAAAAAAAAAAAAAAAAYAYAAGIGAAAAAAYLAAAAZgEAAGUBgABmAQAAJwAAAGgAwACjQAAA44AAACPBAAAaAIACGwAAABsAgAAEAAAABBRjdXN0b21",
    "fYWltX2Rpc3RhbmNlEwEAAAAAAAAAE/QBAAAAAAAAE5YAAAAAAAAAAgAAAAE1AQAAAAAAAAAAAAAAAAAAAAAAAGQGAABmBgAAAAAGCwAAAGYBAABlAYAAZgEAACcAAABoAMAAo0AAAOOAAAAjQQAAGgCAAhsAAAAbAIAAAwAAAAQVY3VzdG9t",
    "X2FpbV9sb2NrX3RpbWUTAQAAAAAAAAATZAAAAAAAAAACAAAAATUBAAAAAAAAAAAAAAAAAAAAAAAAaAYAAG4GAAAAAAQYAAAA5gAAAOUAgADmAAAAKABAAGhAwACAAAAAWYAAAVSAwAATQACAZgAAAFsAAAFpwEAAFADBABNAAIBjQAEAWwAAA",
    "WmAQQAUAMEAE0AAgGPAAQBbAAABZgAAAFsAAAEbAIAACAAAAAQdY3VzdG9tX2Rvbmdkb25nX3RvZ2dsZV9zdGF0ZQQFdHlwZQQGdGFibGUEBGFpbQEBBAVmaXJlBAthbnRpX3NoYWtlBARhZHMCAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAcA",
    "YAAHIGAAAAAAMIAAAApgAAAKUAgACmAAAAJwAAABmAgAAHAEAAGwAAARsAgAABAAAAAwAAAAAAAElAAQAAAAE2AAAAAAAAAAAAAAAAAAAAAAB0BgAAeAYAAAAAAxAAAACmAAAApQCAAKYAAAAnAAAAGYCAAAcAAIAEAICAFYBAABNAAIAjgAA",
    "AE4AAgBUAgIETAACAI8AAABsAAAEbAIAABAAAAAMAAAAAAABJQAOamZmZmZmpPwP8qfHSTWJQPwMAAAAAAADwPwEAAAABNgAAAAAAAAAAAAAAAAAAAAAAegYAAIAGAAAAAAQWAAAA5gAAAOUAgADmAAAAJwAAABmAgABDAACAR0DAAESAwABC",
    "QICBpwCAAJmAgACEgIAAhEBBARXAQAETQACAo8AAABOAAIAVgACCEwAAgKMAAQCbAAABGwCAAAYAAAADAAAAAAAAWUADAAAAAADAWEADK4cW2c737z8D/Knx0k1iUD8DZmZmZmZm1j8DexSuR+F6hD8CAAAAATYBOgAAAAAAAAAAAAAAAAAAA",
    "AAAgwYAAJgGAAACAA81AAAApgMAAKUDgACmAwAApwAAAMAAAACZgAAB5wAAAAABgADZgAABQACAAe0AgAIjAQAAY0EAAKOBAADjwQAAIwIBAOBAgAIoQcEAQAGAARkBAQETwAaAaILBAGnCwQSAAgABwAIABCMDAgBlA4AAWYKAAlRAwgQTgA",
    "SAqILBAKmCQgXAAgABAAOABJmCgAFUwMIAE4ACgOiCwQDpgsIFAAMABVEDgABOA4AG2YKAAVRAgAUTgACAwAIABQADgACSAoMFmwIAAR6BAACfQfh/WwAAARsAgAAMAAAABA9zaG9vdGluZ2NvbmZpZwQZY3Jvc3NoYWlyZm9sbG93aW5nY29",
    "uZmlnBBdjcm9zc2hhaXJkYW1waW5nY29uZmlnBBB6b29taW5naW5jb25maWcEFWFjdGl2ZXRyYWNraW5nY29uZmlnBAdpcGFpcnMEB3N0cmluZwQFZmluZBMBAAAAAAAAAAAEBHN1YgQBAgAAAAEeAAAAAAAAAAAAAAAAAAAAAAAAAJoGAACf",
    "BgAAAwAIFgAAAOYBAADlAYAA5gEAAOgAwAAAAQAA2YAAAejAAAAoQcAAQAGAARmBAAFUgEACE0AAgCYBgAAbAYABJwEAAUABgACAAQABGYGAAWkBgQGAAQACWwGAARsAgAADAAAABAl0b251bWJlcgQFdHlwZQQGdGFibGUDAAAAATQAAAE/A",
    "AAAAAAAAAAAAAAAAAAAAAChBgAApgYAAAQABxYAAACmAQAApQGAAKYBAAAoAUAAQAEAABmBAAEXQQAAEwAAgCNBAAAEQQACVIBAAROAAIAVgAACEwAAgAABAAFUgMABE4AAgBUAgQETAACAAAGAARsBAAEbAIAAAwAAAAQJdG9udW1iZXIDAA",
    "AAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAACoBgAArwYAAAAACBoAAADmAQAA5QGAAOYBAAAnAAAAGYCAAGcAgABZgIAApwAAAZmAgADEAMAABEFAAGiBwAFpwcACgAEAAVmBAAEEQQECwgCBARUAwQETQACA4wABABOAAIAVwICCEwA",
    "AgONAAQDbAAABGwCAAAYAAAADMzMzMzMz8z8DZmZmZmZm9j8EBW1hdGgEBXNxcnQDAAAAAAAAPkADAAAAAABAn0AEAAAAATcBOQE4AAAAAAAAAAAAAAAAAAAAAAAAAMkGAADdBgAAAQANZAAAACYDAAAlA4AAJgMAAGcAAACAAAAAWYAAAahA",
    "gACXAAAAEwAAgFsAAAGoAEABwAAAAJmAAAFUQEABEwABgKgAQAHAAAAAmYAAARSAQAETQA2AqMBAAe0AAAMjAQEAY0EBAKOBAQDjwQEAIwICAGNCAgDgQAADmQABAROAAoDnAYABAAIAAEACAAPZgYABJwIAAEACgAMZggABaAKCAFcCAAATA",
    "ACAGwIAAZ6AAAAfgfx/qMBAAe0AgAEjgQIAY8ECAKMBAwDgQIABmQABARPABIDnAYABAAIAAEACAAPZgYABJwIAAkACgAOAAgAAGcKAARcCAAATAAGApwIAAMACgASZggABl0IAABMAAICjQgMA6IKCANcCAAATAACAmwIAAZ6AAAAfQfp/qM",
    "BAAe0AAAMjgQMAY8EDAKMBBADjQQQAI4IEAGPCBADgQAADmQABARNAAoDoAUUB6UHFAwACgABAAgADo4IFAOUCgADZgYACVMDFAxMAAICbAQABnoAAAB/B/H+mAAAAmwAAARsAgAAYAAAABAV0eXBlBAZ0YWJsZQQJdXNlcmRhdGEEB2lwYWl",
    "ycwQGVmFsdWUEBnZhbHVlBAVOYW1lBAVuYW1lBAlCb25lTmFtZQQJYm9uZU5hbWUECVRvU3RyaW5nBAhHZXROYW1lBAdUb05hbWUEAQQJcmlnaHRsZWcECGxlZnRsZWcEB3NwaW5lMgQFaGVhZAQFbmVjawQFaGlwcwQHc3RyaW5nBAVmaW5k",
    "EwEAAAAAAAAAAAUAAAABHgFEAAABEwEgAAAAAAAAAAAAAAAAAAAAAADfBgAA5gYAAAEABhoAAABmAQAAZQGAAGYBAABoAEAAqEDAAJdAAAATAACAo4AAAFmAAAEUwMAAEwAAgGMAAQCoQAABl0AAABMAAICogEAB5wCAAQABAADZgAABFEDBA",
    "RNAAIAmAQAAGwEAASnBAAEbAQABGwCAAAYAAAAECXRvc3RyaW5nBBdjdXN0b21fYWltX3RhcmdldF9wYXJ0BAVoZWFkBAVtaXNzBAVmcmVlAAQAAAAAAAEAAUMBRQAAAAAAAAAAAAAAAAAAAAAA6AYAAPIGAAACAAwpAAAA5gIAAOUCgADmAg",
    "AAqABAAMAAAACZgAABFEBAARMAAIBbAAABqIBAAO0AgAIjwQAAYwEBAKNBAQDjgQEAI8IBAOBAgAKZAAEBE0AEgOgBQgAoQkIAQAIAA9mBgAEoAkAAQAKAAxmCAAEUgEIEEwACgCjCQgBAAoADgAKAABnCgAEXAgAAE4AAgFQAwwQTAACAWwI",
    "AAZ6AAAAfwfp/WwAAARsAgAANAAAABAV0eXBlBAdzdHJpbmcEB2lwYWlycwQGRk5hbWUEBU5hbWUEEE1ha2VMaXRlcmFsTmFtZQQNU3RyaW5nVG9OYW1lBBJDb252X1N0cmluZ1RvTmFtZQQHcmF3Z2V0BANfRwQJZnVuY3Rpb24EBnBjYWxs",
    "AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AYAAP0GAAACABA0AAAA5gMAAOUDgADmAwAAqABAAMAAAACZgAABVEBAAROAAYCoAEAAwAAAAJmAAAFUgEABE0AAgKUAAACbAAABqMBAAO0AAAMjAQEAY0EBAKOBAQDjwQEAIwICAGNCAgDgQAADm",
    "QABARMABYDnAYAAAAIAAEACAAPZgYABVIDCAxOAA4AnAgABQAKAAxmCAAFUgEIEE0ACgCcCgAFjwgIAgAIAAMACAAMnAwACQAOAA4ADgAAZA4ABGgIAABsCAACegAAAHwH6f6UAAACbAAABGwCAAAwAAAAEBXR5cGUEBnRhYmxlBAl1c2VyZG",
    "F0YQQHaXBhaXJzBAZWYWx1ZQQGdmFsdWUEBU5hbWUEBW5hbWUECUJvbmVOYW1lBAlib25lTmFtZQAEBGFpbQUAAAAAAAETAUUBIwFHAAAAAAAAAAAAAAAAAAAAAAD/BgAADQcAAAEADFgAAADmAgAA5QKAAOYCAABoAEAAgAAAAFmAAAEUQMA",
    "AE0AAgFEAAABbAAABaABAAIAAAABZgAABVIDAABNAAIBjwAAAWwAAAWcAgACAAAAA4wABAFmAgAGnAAABwACAAAABAACZwIABlwAAABNAA4AoQUEAKYFBAmPBAACoQUEAqcFBA+gBQgAAAoAB2YEAAddBAAATAACA48EAAJkBAAEaAQAAGwEA",
    "AChBQgBogUIAo8ECABmBgAFnAYAAgAEAAuMBAQBZgYABqAFAAMABgAKZgQABFABDAxOAB4CoQUMAwAGAAgACAACZwYABwACAA4AAAAOXQAAAE4ABgKhBQwDAAYACAAIAAkACAACZwQACwACAA4AAAAOXAAAAE0ADgKhBQQCpgUED48EAAChCQ",
    "QApwkEEaAJCAIACgAFZggABV0IAABMAAIBjwgAAGQIAAZoBAACbAQAAo8EAAJsBAAEbAIAADgAAAAQFdHlwZQQGdGFibGUECXVzZXJkYXRhEwAAAAAAAAAABAROdW0EBW1hdGgEBG1heAQGZmxvb3IECXRvbnVtYmVyBAdyYXdnZXQEA19HBB",
    "BVTHVhQXJyYXlIZWxwZXIECWZ1bmN0aW9uBAZwY2FsbAMAAAAAAAETASAAAAAAAAAAAAAAAAAAAAAAAA8HAAAeBwAAAgAORwAAAGYDAABlA4AAZgMAAKgAQADAAAAAmYAAARRAQAETgACAgoDAAKmAAACbAAABqABAAMAAAACZgAABVMBAARN",
    "AAICmAAAAmwAAAYKAwADnAIAAAAEAAGMBAQDZgIABJwEAAUABgAGAAQAAwAEAARnBAAIXAQAAE4AAgFRAwQITAACAWwEAAaiBQQDowUEAIwICAJmBgAHnAYAAAAIAA2MCAQDZgYABKAJAAEACgAMZggABFEBCBBNABYAogkIAQAKAA4ACAADA",
    "AgABGcIAAkABgAQAAQAEF0EAABPAAYAogkIAQAKAA4ACAAPAAgAAAAMAARnCgAJAAYAEAAEABBcBAAATgACAVEDBAhMAAIBbAQABJgIAABsCAAEbAIAACwAAAAQFdHlwZQQGdGFibGUTAQAAAAAAAAAECXVzZXJkYXRhBARHZXQABAdyYXdnZ",
    "XQEA19HBBBVTHVhQXJyYXlIZWxwZXIECWZ1bmN0aW9uBAZwY2FsbAMAAAAAAAETASAAAAAAAAAAAAAAAAAAAAAAACAHAAAnBwAAAAAEDgAAAOYAAADlAIAA5gAAACgAQABoQMAAgAAAAFmAAAFUgMAAE4AAgG0AAAAAAIAAKgAAgBsAAAEbAI",
    "AAAwAAAAQfY3VzdG9tX2Rvbmdkb25nX2JvbmVfbmFtZV9wb29sBAV0eXBlBAZ0YWJsZQIAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAApBwAAMgcAAAAABCAAAADmAAAA5QCAAOYAAAAoAEAAaEDAAIAAAABZgAABVIDAABOAAYBtgAAArQAAAGy",
    "AgIGtAAAAbIAAggAAgAAqAACAaEDAAKnAQABZgAABVIDAABNAAIBtAAAALECAgWhAwACpAEEAWYAAAVSAwAATQACAbQAAACxAAIIbAAABGwCAAAUAAAAEJWN1c3RvbV9kb25nZG9uZ19ib25lX2FycmF5X3NuYXBzaG90cwQFdHlwZQQGdGFi",
    "bGUECHJlY29yZHMEBXNlZW4CAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAANAcAADoHAAABAAskAAAApgIAAKUCgACmAgAAaABAAIAAAABZgAABVEDAABNAAIBjgAAAWwAAAWhAQABpwMAArQCAAugAQQApQUEA2YAAASgBQQBpgUEAGYEAAWgBQ",
    "QCpwUEAWYEAAagBQQDpAUIAmYEAAegBQQApQkIA2YEAASgCQQBpgkIAGQIAAaBAAADjwAIAWgCAAVsAAAAbAIAADAAAAAQFdHlwZQQGdGFibGUEAQQHY29uY2F0BAl0b3N0cmluZwQGb3duZXIEBGtleQQNcGFyZW50X2FycmF5BA1wYXJlbn",
    "RfaW5kZXgEDXBhcmVudF9vd25lcgQLcGFyZW50X2tleQQCAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPAcAAEUHAAACAAYzAAAAZgEAAGUBgABmAQAAqABAAMAAAACZgAABFEBAARMAAYCoAEAAwACAAJmAAAFUQEABEwAAgBsAgACpgMAAVMB",
    "AAROAAICpAMEAFMBAARMAAIAbAIAAqABAAOlAQQCZgAABVEBAARNAAICtAAAALICAgqgAQADpgEEAmYAAAVRAQAETQACArQAAACyAAIOnAIAAwACAAJmAAAHpgEEA6YCAAdcAAAATAACAGwCAAOmAQQDswEEB6UBBAClBQQARAQACAgFCAuxA",
    "AAIbAIAACQAAAAQFdHlwZQQGdGFibGUEBm93bmVyAAQEa2V5BAliaW5kaW5ncwQNYmluZGluZ19zZWVuAQETAQAAAAAAAAACAAAAAAABTQAAAAAAAAAAAAAAAAAAAAAARwcAAF4HAAACAA9PAAAApgMAAKUDgACmAwAAqABAAMAAAACZgAABV",
    "EBAARPAAIBUgEABE0AAgOYAAADbAAAB5wCAANmAgAApwcABKQEAAmgBQACAAQACWYEAARRAwAITAAGAZwEAAYABAALAAYAAWUGAARsBAAFnAYABgAEAAFmBAAEWAMECE0AAgKYBAACbAQABrUEBAKwBgIKsQQGD7QEAAKzBgYPtAQAArMEBhO",
    "0BAACswYGEAAEAA6cBAAKZgYAA4wEBAAOCwgJjggIA3cEDgOcCgAIAAwAAQAMABdmCgAEpw0ECQoNCBSzDggYnAwADQAOABRmDAAFUwEIGE8AAgGkDAwMUwMIGEwAAgKzBAgbcgft/5wEAAQACAAJAAoAA2UGAAenBwAHsAQEA6QHDASkCwwE",
    "RAgAEAoJCBOwBAQQbAQABGwCAAA0AAAAEBXR5cGUEBnRhYmxlBAl1c2VyZGF0YQQFc2VlbhMAAAAAAAAAAAQGYXJyYXkEBmNvdW50BAd2YWx1ZXMECWJpbmRpbmdzBA1iaW5kaW5nX3NlZW4TAQAAAAAAAAAABAhyZWNvcmRzBwAAAAAAAUwB",
    "TgFJAUsBSgFFAAAAAAAAAAAAAAAAAAAAAABgBwAAZQcAAAIACBIAAADmAQAA5QGAAOYBAACnAAAAmYCAAOcAgAAAAYAA2YAAAenAAAFUAMABEwAAgNsAAAEnAQABQAEAAIABgAAaAYABGwEAABsAgAABAAAAAAMAAAABSwEeAUcAAAAAAAAAA",
    "AAAAAAAAAAAAGcHAACBBwAABAARZQAAACYEAAAlBIAAJgQAACcBAABAAQABgAGAARmBgAFlAQAAggHAAOhBwAAAAgAA2YEAARSAwAMTAAGA6MHAACECAADZgQABQAGAAxNAD4DoQcAAAAIAANmBAAEUAMEDEwAOgOcBAAEAAgAAY0IBANmBgA",
    "EoQsAAQAKAAxmCAAEUgEEEE0ACgCjCwQBjAgAApwKAAcACgAMAAwAAQAMAA4ADAAKZAoACGYIAAEABAARXQQAAE0AHgCgCwgBoQsIAo4ICABmCgAFnAgABgAIABONCAQBZgoABqELAAMACgASZggABFIBBBRMABICowsAAwAKABAADAABAAwA",
    "DgAMAApmCgAJAAQAFV0EAABPAAYCowsAAwAKABAADAARAAwAAgAMAA8ADAAKZggADQAEABVdBAAATwACAKMLAAGFCAAAZggABQAEABFdBAAATQACA5QEAANsBAAHnAQACAAIAAEACgADZgYABJwKAAkACgAMZggABZwIAA4ACgAFZggABVEAC",
    "BBMAAIAlQgAAJQKAABsCAAEbAIAACwAAABMBAAAAAAAAAAQFdHlwZQQGdGFibGUEBnBjYWxsBAl1c2VyZGF0YQQEU2V0BAlmdW5jdGlvbgQHc2VsZWN0BAdyYXdnZXQEA19HBBBVTHVhQXJyYXlIZWxwZXIHAAAAAVAAAAETASABSgFFAR4CA",
    "AAAAGwHAABsBwAAAAADBwAAAKYAAAClAIAApgAAACcAgABnAAABKkAAABsAgAAAAAAAAwAAAAEAAQYBBAAAAAAAAAAAAAAAAAAAAAAAewcAAHsHAAAAAAMHAAAApgAAAKUAgACmAAAAJwCAAGcAAAEqQAAAGwCAAAAAAAADAAAAAQABBgEEAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDBwAAlgcAAAMAD1AAAACmAwAApQOAAKYDAADCAMAAKEFAAEABAAAZgQABFIBAAhPAAIAowUAAYQEAABoBAAEbAQAAKEFAAEABAAAZgQABVABBAhNAAIAlAQAAGwEAAScBgABAAQAAo0EBABm",
    "BgAFoQUAAgAEAAlmBAAEUgMECEwADgGjBQQCjAQAA5wEAAQACAAJAAgAAgAKAAcACAAHZAYACWYEAAFcBAAATQACApQGAAJsBAAFoAUIAqEFCAOOBAgBZgYABpwGAAMABgAIjQgEAmYGAAehBQAAAAgAD2YEAARSAwQMTwASA6MFAAAACAANA",
    "AgAAgAKAAcACAAHZgYAC10EAABPAAYAowkAAQAIAA4ACgALAAgAAAAOAAUADAAEZggADwAEABNcBAAATQACAJQKAABsCAAHowUAAIUIAANoBAAHbAQAAGwCAAAsAAAATAQAAAAAAAAAEBXR5cGUEBnRhYmxlBAZwY2FsbAQJdXNlcmRhdGEEB",
    "FNldAQJZnVuY3Rpb24EB3NlbGVjdAQHcmF3Z2V0BANfRwQQVUx1YUFycmF5SGVscGVyAwAAAAAAARMBIAIAAAAAhgcAAIYHAAAAAAMHAAAApgAAAKUAgACmAAAAJwCAAGcAAAEqQAAAGwCAAAAAAAADAAAAAQABAwECAAAAAAAAAAAAAAAAAA",
    "AAAACVBwAAlQcAAAAAAwcAAACmAAAApQCAAKYAAAAnAIAAZwAAASpAAAAbAIAAAAAAAAMAAAABAAEDAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJgHAACmBwAAAgAIMgAAAOYBAADlAYAA5gEAAKgAQADAAAAAmYAAARRAQAETQAG",
    "AqYBAAFTAQAETgACAqQBBABTAQAETQACApQAAAJsAAAGoQEEA4QAAAJmAAAHpgEEAVMDAARNABoDpwEEAVMDAAROABYDpAEIAVMDAARPABIDnAIAAKYFBAGnBQQCpAUIA2YAAAtcAAAATAACApQCAAOlAQgBUwMABEwACgOmAQgBUwMABE0AB",
    "gOhAQQAhQQAA2YAAAdcAAAATAACApQCAAJsAAAEbAIAACwAAAAQFdHlwZQQGdGFibGUEBm93bmVyAAQEa2V5BAZwY2FsbAQNcGFyZW50X2FycmF5BA1wYXJlbnRfaW5kZXgEDXBhcmVudF92YWx1ZQQNcGFyZW50X293bmVyBAtwYXJlbnRfa",
    "2V5AgAAAAAAAVICAAAAAJoHAACaBwAAAAAECAAAAOYAAADlAIAA5gAAACgAQABoQEAApwCAACyAgAAbAIAAAgAAAAQGb3duZXIEBGtleQIAAAABAAEBAAAAAAAAAAAAAAAAAAAAAACgBwAAoAcAAAAABAgAAADmAAAA5QCAAOYAAAAoAEAAaE",
    "BAAKiAQAAsgIAAGwCAAAMAAAAEDXBhcmVudF9vd25lcgQLcGFyZW50X2tleQQNcGFyZW50X2FycmF5AQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACoBwAArwcAAAEACx8AAACmAgAApQKAAKYCAABoAEAAgAAAAFmAAAEUQMA",
    "AEwABgGgAQACpgEAAWYAAAVRAwAATQACAZQAAAFsAAAFlAAAAqMBAAOmAQACZAAEBE4ABgOcBgAAAAgADaQJBANmBgAHXAQAAEwAAgGUAgACegAAAH4H9f1sAAAEbAIAABQAAAAQFdHlwZQQGdGFibGUECWJpbmRpbmdzBAdpcGFpcnMEBmFy",
    "cmF5AgAAAAAAAVMAAAAAAAAAAAAAAAAAAAAAALEHAADFBwAAAAAUWQAAAOYEAADlBIAA5gQAACgAQABoQMAAgAAAAFmAAAEUgMAAEwABgGhAwACpwEAAWYAAAVSAwAATQACAZQAAAFsAAAFlAAAAqADBAOnAQACZAAEBE0AMgOhBwAAAAgAD2",
    "YEAARSAwAMTAAuA6UFBA1SAwQMTQAqA6EHAACnCQQPZgQABFIDAAxMACYDlAQAAIwICAGhCwgCpgkIDWYIAAVdCAAATAACAYwICAEPCwgSjwgIAHQIEgCnDQQNCw8IFKUMDBmcDAAGAAwAGWYMAAVSAwQYTAAKApwOAAelDQQMABIAFQAQABo",
    "AEgAaZg4AClwMAABMAAIDlAYAAHEL7f9cBAAATQAGAJwIAAkACAAMZggABFwIAABMAAIBlAIAAnoAAAB/B8n+oQMIA6ABDAJmAAAGXQAAAEwAAgKMAAgBXAAAAE4AAgOPAAgDXQAAAEwAAgOMAAgCCwAABKoAAhlsAAAEbAIAADQAAAAQlY3V",
    "zdG9tX2Rvbmdkb25nX2JvbmVfYXJyYXlfc25hcHNob3RzBAV0eXBlBAZ0YWJsZQQIcmVjb3JkcwQHaXBhaXJzBAZhcnJheQAEB3ZhbHVlcxMAAAAAAAAAAAQJdG9udW1iZXIEBmNvdW50EwEAAAAAAAAABCdjdXN0b21fZG9uZ2RvbmdfYWlt",
    "X2JvbmVfcmVzdG9yZV9jb3VudAUAAAABAAAAAUUBUQFUAAAAAAAAAAAAAAAAAAAAAADHBwAA2gcAAAIAETcAAAAmBAAAJQSAACYEAACnAAAAwAAAAAABgACZgIAB6ADAAAABAAHZgAABVEDAARNAAIDlAAAA2wAAAeUAAAAjgQAAY4EAAKnBQ",
    "AGDAUED4wEBAF1BBIBpQkEBggJBBGmCggSnAgABwAKABJmCAAFUgEEFE0ACgOcCgAEAAwAAQAMABIADgATAAwAF2YKAAtcCAAATQACA5QCAAAIBQQJcAft/1wAAABOAAoBnAQACgAEAAVlBAAFoAcIAqMHBAlmBAAFXQQAAEwAAgGOBAABCAY",
    "ECakGBg9sAAAEbAIAACQAAAAQFdHlwZQQGdGFibGUTAAAAAAAAAAAEBmNvdW50EwEAAAAAAAAABAd2YWx1ZXMABChjdXN0b21fZG9uZ2RvbmdfYWltX2JvbmVfdmVyaWZpZWRfY291bnQECXRvbnVtYmVyBgAAAAFPAAABRgFRAVQBAAAAAAA",
    "AAAAAAAAAAAAAAAAA3AcAABQIAAACABWeAAAAJgUAACUFgAAmBQAAqABAAMAAAACZgAABVEBAARPAAIBUgEABE0AAgOUAAADbAAAB5wCAAAABAADZgAABFsDAARNAAIAlAQAAGwEAASUBAABjwQAAo8EAAMMBwQEjAgEAncEdgKcCAAHAAgAA",
    "AAOABJmCgAHoAkAAAAMABdmCAAFUQMAFE0AAgBSAwAUTABuAJQMAAGcDgAGAAwAF40MBAFmDgAGnA4ABwAMABSOEAQCZg4AB6ANAAAAEAAfZgwABVEDABxMAAYDoA0AAAAQAB9mDAAEUgMAHE4AGgO3DAQDsg4KD7INBhOwDgITsQwKF7IOCh",
    "VcAAAATgACAKcTBABdEAAATAACAJgQAAOwDBIZXAAAAE4AAgCkEwgAXRAAAEwAAgCYEAADsA4SGJwQAAkAEAAeABIAHGYSAARcEAAATAACAJQOAAFSAwwYTAAqA5wOAAQAEgAZjhAEA2YOAASgEQABABIAHGYQAAVRAQAgTAAGAKARAAEAEgA",
    "cZhAABFIBACBOABoAtxAEALESDgyyEQYQsBICELEQChSyEgoVXAAAAE4AAgGnEwQBXRAAAEwAAgGYEAAAsRASGVwAAABOAAIBpBMIAV0QAABMAAIBmBAAALESEhmcEAAKABIAHwAQACFmEgAFXBAAAEwAAgCUDgAAXAwAAE0AEgOcDgAIABAA",
    "AQASABIAEAAXZQwACVwAAABMAAoDpw8EAVIDDBxNAAYDpA8IAVIDDBxOAAIDow0MAIQQAANlDAAElAYAAQgHBApyB4X8VQIGBE8ABgKhBRADoAUQDmYEAAZdBAAATAACAo8EAAIJBAQOqgQGIGwEAARsAgAASAAAABAV0eXBlBAZ0YWJsZQQJ",
    "dXNlcmRhdGETAAAAAAAAAAATAQAAAAAAAAAEBV9EYXQEEENvbmVGaWx0ZXJCb25lcwQGb3duZXIEBGtleQQNcGFyZW50X2FycmF5BA1wYXJlbnRfaW5kZXgEDXBhcmVudF92YWx1ZQQNcGFyZW50X293bmVyBAtwYXJlbnRfa2V5AAQGcGNhb",
    "GwEKGN1c3RvbV9kb25nZG9uZ19haW1fYWlfYm9uZV9ncm91cF9jb3VudAQJdG9udW1iZXIHAAAAAAABSQFKARMBVgFSAQABAAAAAAgIAAAICAAAAAAECAAAAOYAAADlAIAA5gAAACgAQABoQEAApwCAACyAgAAbAIAAAgAAAAQGb3duZXIEBG",
    "tleQIAAAABAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWCAAAOggAAAEACnsAAABmAgAAZQKAAGYCAABoAEAAgAAAAFmAAAFUQMAAE8AAgFSAwAATQACApQAAAJsAAAGlAAAA5wCAAAABAABjwQAA2YCAAVQAwQETQAuAJwGAAEA",
    "BgAGjQQEAGYGAAWgBQACAAQACWYEAAVRAwAITAAGAaAFAAIABAAJZgQABFIDAAhMAAoBnAQABgAEAAu2BAADswQCD7EHBg1mBgAFXAQAAEwAAgKUAgABnAYAAgAGAAeMBAgBZgYABqAFAAMABgAKZgQABVEBAAxMAAYCoAUAAwAGAApmBAAEU",
    "gEADEwACgKcBgAHAAYACLYIAACzCAIMsAsKDmYGAAZcBAAATAACApQCAACcBgABAAQAAo0EBABmBgAFoAUAAgAEAAlmBAAFUQMACEwABgGgBQACAAQACWYEAARSAwAITAAKAZwEAAYABAALtgQAA7AEAg+xBwYNZgYABVwEAABMAAIClAIAAZ",
    "wGAAIABAADjAQIAWYGAAagBQADAAYACmYEAAVRAQAMTAAGAqAFAAMABgAKZgQABFIBAAxMAAoCnAYABwAGAAi2CAAAsAgCDLALCg5mBgAGXAQAAEwAAgKUAgACXAAAAE8ABgKiBQgDoQUICmYEAAZdBAAATAACAo8ECAIIBQwMqgYGEmwAAAR",
    "sAgAANAAAABAV0eXBlBAZ0YWJsZQQJdXNlcmRhdGEEBV9EYXQABBBDb25lRmlsdGVyQm9uZXMEBm93bmVyBARrZXkEFENvbmVGaWx0ZXJCb25lc09mQUkEJWN1c3RvbV9kb25nZG9uZ19haW1fYm9uZV9wYXRjaF9jb3VudAQJdG9udW1iZXI",
    "TAAAAAAAAAAATAQAAAAAAAAAFAAAAAAABEwFWAVcBAAAAAAAAAAAAAAAAAAAAAAAAPAgAAEkIAAAAAAcmAAAApgEAAKUBgACmAQAAKABAABdAAAATAACALQAAAGlAQABUgMAAEwABgGnAQABUgMAAE0AAgGUAAABbAAABZwCAAFlAgABnAAAB",
    "owABAFmAAAGnAIABwACAAJmAAAFAAAABqEBBAsAAgACZgAABVIBBARNAAIClAAAAmwAAAaUAAADnAIACAAGAAGEBAADZQIABmwAAARsAgAAHAAAABB1jdXN0b21fZG9uZ2RvbmdfdG9nZ2xlX3N0YXRlBARhaW0BAQQLYW50aV9zaGFrZQQXV",
    "2VhcG9uQWltQXNzaXN0b3JUYWJsZQQFdHlwZQQGdGFibGUHAAAAAQABVQEhASYAAAEoAVgBAAAAAEQIAABHCAAAAwAGDwAAAGYBAABlAYAAZgEAAOcAAAAAAQAB2YAAAYAAgAHnAIAAAAEAAdmAAAHXAAAAE0AAgOUAgADrAAABGwCAAAAAAA",
    "ADAAAAAAMABgECAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLCAAAOQkAAAUAJkoDAABmCQAAZQmAAGYJAABnAQAAgAGAAFmBAAGnAQAAwAEAAZmBAAGAAAADpwGAAJmBgAAUAEADE4AAgOYBAAAlAgAA2wGAAecBAAHZgYAAB0LAA2c",
    "CgAFZgoAApwIAApmCgADnAoAC2YKAAAeDwAVEw8AFhAPBBucDAAPZg4AAKETBAymEQQhABIACo8QBAOMEAgAlBYAAGYSAAlQAQAgTAAKAKETBAymEQQhABIACo0QCAOMEAgAlBYAAGYSAAlQAQAgTAACAJUQAACUEgABoRMEDaYTBCIAEgALj",
    "hAIAIwUCAGUFgABZhIACVADACBMAAoBoRMEDaYTBCIAEgALjxAIAIwUCAGUFgABZhIACVADACBMAAIBlRAAAZQSAAKhEwQOphEEJwASAAiPFAgBjBQIApQWAAJmEgAIUAEAJEwAAgKVEAAClBIAA6ETBA+mEwQkABYACYwUDAKMFAgDlBYAA2",
    "YSAAhQAwAkTAACA5UQAAOUEgAAoRcEDKYVBCkAFgAKjRQMA4wUCACUGgAAZhYACFABAChMAAIAlRQAAJQWAAGhFwQNphcEKgAWAAuOFAwAjBgIAZQaAAFmFgAIUAMAKEwAAgGVFAABlBYAAqEXBA6mFQQvABYACI8YDAGMGAgClBoAAmYWAAh",
    "QAQAsTAACApUUAAKUFgADoRcED6YXBCwAGgAJjBgQAowYCAOUGgADZhYACFADACxMAAIDlRQAA5QWAAChGwQMphkEMQAaAAqNGBADjBgIAJQeAABmGgAIUAEAMEwAAgCVGAAAlBoAAFIBEAxPAIYAXRAAAE4AAgGYGAAClBgAAWwaAARTARAE",
    "TgACAZQaAAKUGgABbBoABFABFARPAAoBoRsEDaYbBDIAGgALjRgUAIwcCAGUHgABZhoACVADADBOAAIBABoAEpQaAAFsGgAFUgEUBE0AAgBTARQETgACAQAaABKUGgABbBoABFABGAROAAIBHRsYEpQaAAFsGgAEUgEYBE4AAgEAGgAalBoAA",
    "WwaAARTARgETwACAZwYABFmGgAClBoAAWwaAAVQARwETQACAFEBHAROAAIBABoADpQaAAFsGgAFUgEcBE0AAgBTARwETgACAZgYAAKUGAABbBoABFABIARNACIBoRsgDgAaAAVmGAAFUgMgME4AAgGYGAAClBgAAWwaAAWYGAAAWwICRE0AAg",
    "GMGCQATQASAFsCAkhNAAIBjhgkAE0ADgBbAgJMTQACAYwYKABNAAoAWwICUE4ABgBcFAAATgACAo4YKAFhGAA0TAACAY8YKABMAAIBjBgEAhAaDDOUGgACbBoABVABLARNAAIAUQEsBE4AAgGMGAQClBoAAWwaAARSASwETgACAY8YLAKUGgA",
    "BbBoABVABMARNAAIAUQEwBE4AAgGOGDAClBoAAWwaAARTATAETgAOAaAbNA2lGzQyEhgKbgsZNDVmGAAEVAM4ME0AAgGMGDgATgACAFUCGnBMAAIBjRg4AgAaADOUGgACbBoABZgYAAKUGAABbBoAB1wQAABOAA4AUgE4BE0ACgGhGyAOABoA",
    "BWYYAARSAyAwTAAGAFgDBAROAAIBjxg4ApQaAAFsGgAFmBgAApQYAAFsGgAGXBAAAE0AYgBQATwETQAOAaEbPA6cGgATABgAAI4cPAJkGgAFZhgAAVADADBMAFYAVQIafE4AUgIAGgAzlBoAAmwaAAROAE4AUAFABE0ADgGhGzwOnBoAEwAYA",
    "ACNHEACZBoABWYYAAFQAwAwTABGAFUCGnxOAEICABoAM5QaAAJsGgAETgA+AFIBQARNAA4BoRs8DpwaABMAGAAAjxxAAmQaAAVmGAABUAMAMEwANgBVAhp8TgAyAgAaADOUGgACbBoABE4ALgBQAUQETQAOAaEbPA6cGgATABgAAI0cRAJkGg",
    "AFZhgAAVADADBMACYAVQIafE4AIgIAGgAzlBoAAmwaAAROAB4AUgFEBE0ADgGhGzwOnBoAEwAYAACPHEQCZBoABWYYAAFQAwAwTAAWAFUCGnxOABICABoAM5QaAAJsGgAETgAOAFABSARMAA4BoRs8DpwaABMAGAAAjRxIAmQaAAVmGAABUAM",
    "AMEwABgBVAhp8TgACAgAaADOUGgACbBoABZgYAAKUGAABbBoABVwQAABNAHYBUgFIBE8AAgFTAUgETQACAFABTAROAAIBjhgwApQaAAFsGgAFUQFMBE8AAgFSAUwETQACAFMBTAROAAIBABgAHpQaAAFsGgAFUAFQBE8AAgFRAVAETQACAFIB",
    "UAROAAIBExtQHpQaAAFsGgAFUAFUBE8AAgFRAVQETQACAFIBVAROAAIBABoAHpQaAAFsGgAFUwFUBE8AAgFQAVgETQACAFEBWARMAA4BoBs0DaYbWDKOGDADDxlYFWYaAAUQG1wxCRoauFUAGrxMAAIBjhhcAgAaADOUGgACbBoABVMBXARNA",
    "AYBUAFgBE8AAgFRAWAETQACAFIBYAROAAIBABoADpQaAAFsGgAFUwFgBE0ABgFQAWQETwACAVEBZARNAAIAUgFkBE4AAgGOGDAClBoAAWwaAARTAWQETgACARAZaBKUGgABbBoABFEBaAROAAIBEBkEEpQaAAFsGgAEUgFoBE4AAgGUGgAClB",
    "oAAWwaAARTAWgETgAKAaAbNA2mG1gyEBtsHxEbbBlmGgAEVQAa3EwAAgGOGGwCABoAM5QaAAJsGgAEUwFsBE4AAgGMGHAClBoAAWwaAARRAXAETgACAY4YcAKUGgABbBoABZgYAAKUGAABbBoABF0QAABOAAIBmBgAApQYAAFsGgAEUwEQBE4",
    "AEgNdFAAATQACAFwYAABOAAIBlBgAApQaAAFsGgAEXRQAAE8AAgFdFAAATQACAlwUAABOAAIBlBoAApQaAAFsGgAFmBgAApQYAAFsGgAFnBgAFgAYAAsAGgAAABwABWcYAAlQAwAwTAD+AFMBGDRMAAoDnBoAFAAeADGcHAAZZh4AAo8ccAOP",
    "HFgDZhoACJQeAANsGgAHlBgAAJQcAABcFAAATQASAaEfBA2mHwQ6ABwAN4wcdACMIAgBlCIAAWYeAAhQAwA4TAACA5UYAAOUGgABUQF0BE4AAgFSAXQETAACAJUcAACUHgAATAASAVwUAABOAA4BoR8EDaYfBDoAHAA3jBx0AIwgCAGUIgABZ",
    "h4ACFADADhMAAIDlRgAA5QaAAFTAXQETAACAJUcAACUHgADXBgAAE8AMgEAHAASoR8EDqYdBD8AHAA0jCB4AYwgCAKUIgACZh4ACFABADxMAAIClRwAApQeAAOhHwQPph8EPAAgADWNIHgCjCAIA5QiAANmHgAIUAMAPEwAAgOVHAADlB4AAl",
    "wcAABNAA4AXBQAAE0AAgESH3g4TgAOAVwUAABMAA4DXBwAAE4AAgCPIHgAXSAAAEwAAgCMIHwBEB4gOEwABgFcFAAATgACA1wcAABMAAIBER98OJwiABUAIgAyACIAO44gMACMJAQAZiIACZQiAABsIgAEXBwAAE0AHgGcHgAWAB4AMxweCrS",
    "PIHABjiBwAWYeAAhcFAAATAAGAFEBdAROAAIAVQAe/EwAAgGOHHwAXBQAAEwABgBSAXQETgACAFUCHvxMAAIBjxx8AVwUAABMAAYAUwF0BE4AAgBVAh8MTAACAY8chAIAHgA7lB4AAmweAARQAYA0TAAmAZgcAABaAgq0TwAKAqEfPA8AHgAy",
    "ZhwABl0cAABMAAICjxxYA6AfNA+lH4A8ACAAF2YcAAUfHBw8TwAKAqEfPA8AHgAyZhwABl0cAABMAAICjxxYA6AfNA+mH1g8ACAAFY4ggANmHgAFHxwcPFcDNDhNAAIBjxw0AE4AAgBVAB5sTAACAY4cNAIAHgA7lB4AAmweAAVSARQ0TQASA",
    "aEfBA2mHwQ6ABwAN40cFACMIAgBlCIAAWYeAAhQAwA4TAAKAaEfBA2mHwQ6ABwAN48cFACMIAgBlCIAAWYeAAlQAwA4TwAGAZweABYAHgAzABwAFI8gcAGPIIABZh4ACpQeAAFsHgAFUgEYNE0AAgBQAYQ0TwAGAZweABYAHgAzABwAGI8gcA",
    "GNIIQBZh4ACpQeAAFsHgAFoR8EDaYfBDoAHAA3jBwYAIwgCAGUIgABZh4ACVADADhMAB4BnB4AFgAeADMAHAAYjyBwAY0ghAFmHgAIUAEgBE4AAgBWAgw4TAACAQAcAB1QASwETQACAFEBLAROAAoAXRQAAE0AAgFcFAAATwACAFYDhDhMAAY",
    "BjhyEAE4AAgBUAwQ4TAACAYwcBAIAHgA7lB4AAmweAARSASwETgACA48YLACUHgADbBoABVABMARNAAIAUQEwBE4AAgOOGDAAlB4AA2waAARTATAETgAOA6AbNA+lGzQ0EhwKbAsdNDtmGAAEVAM4NE0AAgOMGDgATgACAFcCGnBMAAIDjRg4",
    "AAAeADWUHgAAbB4AB5gYAACUHAADbBoABGwCAAIgAAAAAAwAAAAAAAElAAwAAAAAAwGJAAwAAAAAAAFlAAwAAAAAAAAhABAdzdHJpbmcEBWZpbmQEF3dlYXBvbmFpbWFzc2lzdG9ydGFibGUTAQAAAAAAAAAEIXdlYXBvbmFpbWFzc2lzdG9y",
    "dGFibGVmb3JnYW1lcGFkBBp3ZWFwb25hc3Npc3RlZGFpbWluZ3RhYmxlBB93ZWFwb25hc3Npc3RlZGFpbWluZ2dyb3VwdGFibGUEEndlYXBvbmJ1bGxldHRhYmxlBA9zaG9vdGluZ2NvbmZpZwQZY3Jvc3NoYWlyZm9sbG93aW5nY29uZmlnB",
    "Bdjcm9zc2hhaXJkYW1waW5nY29uZmlnBBVhY3RpdmV0cmFja2luZ2NvbmZpZwQQem9vbWluZ2luY29uZmlnBARhZHMEDGJ0YWtlZWZmZWN0BAJ4BBJlZmZlY3RpdmVmb3ZyYW5nZQQOY29uZWFuZ2xlYmFzZQQeb3V0ZXIyaW5uZXJyYW5nZW",
    "ZvcnJheWNoZWNrZXIEC3Jhbmdlc2NhbGUDAAAAAACAVkAED2NvbmVoZWlnaHRiYXNlBAtsb2Nrb250aW1lBA1waXRjaHJhdGVhZHMEC3lhd3JhdGVhZHMEDXBpdGNocmF0ZWhpcAQLeWF3cmF0ZWhpcAQJaW5yYW5nZWIEBXR5cGUEB251bWJ",
    "lchMoIwAAAAAAAAMAAAAAoEbgQBN8FQAAAAAAAAMAAAAAgLPVQBPwCgAAAAAAAAMAAAAAgIfDQBOYCAAAAAAAAAMAAAAAAFi7QAMAAAAAAGG+QAQKb3V0cmFuZ2VhBApvdXRyYW5nZWIEG3BsYXllcmlucHV0YXdheXRhcmdldGFuZ2xlAwAA",
    "AAAATJhABBtwbGF5ZXJpbnB1dGF3YXl0YXJnZXR2YWx1ZQQWcGxheWVyaW5wdXRyZWNvcmR0aW1lAwAAAAAAAAAABBdjb25lZmlsdGVyYWN0b3JzbWF4bnVtBAVtYXRoBAZmbG9vcgMAAAAAAAAgQAMAAAAAAADgPxMQAAAAAAAAABNAAAAAA",
    "AAAAAQHcmFkaXVzAwAAAAAAABRABAxzaW5nbGVpZHB2ZQQJdG9udW1iZXIECVNpbmdsZUlkEwAAAAAAAAAABAphdXRvaWRwdmUEB0F1dG9JZAQLYnVyc3RpZHB2ZQQIQnVyc3RJZAQSYWltaW5nc2luZ2xlaWRwdmUED0FpbWluZ1NpbmdsZU",
    "lkBBBhaW1pbmdhdXRvaWRwdmUEDUFpbWluZ0F1dG9JZAQRYWltaW5nYnVyc3RpZHB2ZQQOQWltaW5nQnVyc3RJZAQSZW5hYmxlZGlzdGFuY2VtaW4EIWVuYWJsZWRpc3RhbmNlbWluZm9ycm90YXRlc3RpY2t5BCNlbmFibGVkaXN0YW5jZW1",
    "pbmZvcm1hZ25ldGljc3RpY2t5BBJlbmFibGVkaXN0YW5jZW1heAQhZW5hYmxlZGlzdGFuY2VtYXhmb3Jyb3RhdGVzdGlja3kEI2VuYWJsZWRpc3RhbmNlbWF4Zm9ybWFnbmV0aWNzdGlja3kEFWFzc2lzdGVkYm94bWlucmFkaXVzBCRhc3Np",
    "c3RlZGJveG1pbnJhZGl1c2ZvcnJvdGF0ZXN0aWNreQQmYXNzaXN0ZWRib3htaW5yYWRpdXNmb3JtYWduZXRpY3N0aWNreQPNzMzMzMzkPwQVYXNzaXN0ZWRib3htYXhyYWRpdXMEJGFzc2lzdGVkYm94bWF4cmFkaXVzZm9ycm90YXRlc3RpY",
    "2t5BCZhc3Npc3RlZGJveG1heHJhZGl1c2Zvcm1hZ25ldGljc3RpY2t5BBlhc3Npc3RlZGJveHZlcnRpY2Fsc2NhbGUEKGFzc2lzdGVkYm94dmVydGljYWxzY2FsZWZvcnJvdGF0ZXN0aWNreRQqYXNzaXN0ZWRib3h2ZXJ0aWNhbHNjYWxlZm",
    "9ybWFnbmV0aWNzdGlja3kEBG1heAMAAAAAAADwPwOkcD0K16PAPwOamZmZmZn1PwMAAAAAAAAAQAQWaG9yaXpvbnRhbHJlY29pbHNwZWVkBBR2ZXJ0aWNhbHJlY29pbHNwZWVkBB9ob3Jpem9udGFscmVjb2lsc3BlZWRmb3J6b29taW4EHXZ",
    "lcnRpY2FscmVjb2lsc3BlZWRmb3J6b29taW4EE3BhdXNldGltZWFmdGVyZmlyZQQbcmVjb2lscmVkdWNlYWN0aXZhdGlvbnRpbWUEEm1hZ25ldGljY2RzZWNvbmRzBBttYWduZXRpY2VuYWJsZWZvY3Vzc2Vjb25kcwQWcmVjb2lsc3BlZWR0",
    "b3VjaHBhcmFtAwAAAAAAAPg/BAxzdGlja3lwYXJhbQQTYnByZXZlbnRtaXNzZW5hYmxlBCBwcmV2ZW50bWlzc2FkZGJ1bGxldHJhZGl1c2RlbHRhAwAAAAAAAPQ/A3sUrkfhepQ/AwAAAAAAcJdABBJwcmV2ZW50bWlzc251bWJlchMMAAAAA",
    "AAAAAQQcHJldmVudG1pc3N0aW1lAwAAAAAAANA/A/yp8dJNYlA/BAdmYWN0b3IECmRlbHRhdGltZQQHY2R0aW1lBA1pbnRlcnZhbHRpbWUEDHBpdGNoZmFjdG9yBA1mYWN0b3Jsb2Nrb24DzczMzMzM9D8DMzMzMzMz+z8DZmZmZmZm9j8DZm",
    "ZmZmZm8j8DuB6F61G4jj8D/Knx0k1igD8ED2NvbmVhbmdsZXBvd2VyBAVzcXJ0A5qZmZmZmak/AwAAAADwafhABBBjb25laGVpZ2h0cG93ZXIDAAAAAH6ELkEDAAAAAAAAGEAD+n5qvHSTiD8NAAAAAR4BOwE2ATcBOAE5AUIAAAE+ARMBQAF",
    "BAToAAAAAAAAAAAAAAAAAAAAAADsJAABnCQAABwAbUQAAAKYGAAClBoAApgYAABUAAYATAACAGwCAAOcBAAAAAoAA2YEAAScCAABAAoABGYIAAVRAwAMTQACAFIDAAxMAAIAbAIAAZwKAAIACAADAAoABAAOAAEADAAGAAwADWcIAA5cCAAAT",
    "gAGA5wIAASPDAABAAwAAgAOAAMADgATZQoACGwCAAOcCgAEAAwAB2YIAAYAAgAXoAkECAAMAAdmCAAFUQMEFE0AAgBSAwQUTgACAKYOAAhcDAAATAACAGwCAAGzBQQEUQMEFEwABgCcDgAJAAwABoQMAABlDgAEbAIAAKANCAmcDgAMZAwEBE",
    "0AEgGcEAASABAABwAQACFmEgAFUQMIIE8ACgKcEAAPABAABAAUACEAFgAiABYAB44UCAAAGAAiSBQYLwsVCAgAGgAJABgADmUQABB6DAACfw/p/GwCAAAwAAAATDQAAAAAAAAAEEGNvbmVmaWx0ZXJib25lcwQUY29uZWZpbHRlcmJvbmVzb2",
    "ZhaQQEYWltBAV0eXBlBAZ0YWJsZQQJdXNlcmRhdGEBAQQHaXBhaXJzAAQCLhMBAAAAAAAAAAkAAAABHgFaASMBJgAAASgBWwEdARMBAAAAAEwJAABWCQAAAwAMEwAAAOYCAADlAoAA5gIAAOcAAAAAAQAAQAGAAIABAAHnAYAAIwIAAGhCQAG",
    "AAoAAWYIAAdJBggMnAoABAoJABGcCAAKnAoAC2UAABBsAgAADAAAABAIuBAl0b3N0cmluZxMBAAAAAAAAAAYAAAAABgEDAAQBBAEFAQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkJAACQCQAAAwAIFQAAAOYBAADlAYAA5gEAAOcA",
    "AAAAAYAA2YAAAUAAgAHoAMAAAAGAANmAAAFUQMABE0AAgOUAAADbAAAB5QAAACcBAAFAAYAAoQEAABlBgAHbAAABGwCAAAIAAAAEBXR5cGUEBnRhYmxlCQAAAAEmAAABKAETAS4BMgEzAVgBWwEAAAAAbQkAAI4JAAADAA1sAAAAJgMAACUDg",
    "AAmAwAA5wAAAAABAAHZgAABgACAAegAwAAAAQAB2YAAARRAwAETAAKA5wAAAQABAABAAYAA2YCAAVTAAAETgACA6IDAACEBAADZQAAB5wCAARTAwAETwACA5wAAAgABAAHZQAABEwATgOcAgAEUAMEBE8AAgOcAgAIAAQAB2UAAARNAEYDnAI",
    "ABFEDBARMAAoDnAAADAAEAAEABgACAAQAB44EBAC0CAABlAgAA2UCAAxNADoDnAIABFMDBAROADYDoAMIAJwEAAUABAAGjQQIAGQGAAdmAAAAUgMIBEwAEgCcBAAFAAQABo0ECABmBgAFoAcIApwEAAcABAAIjwgIAmYGAAZdBAAATwACApwE",
    "AAcABAAIjAgMAmYGAAVmBAAHAAIACFIDCAROAAoAoQcMAQAGAABmBAAFtgQEAbMFDh2xBRIhswUSJbEFFimzBRYtsQUaM6QCBAicBgANAAQABGUEAAScBAARAAQAAgAGAAMABAAEnAoAEY4IGAKhCwwDAAoAAmYIAARKCAgRjggEArQIAAMAC",
    "gAEZQQAE5QCAAOsAAAUbAIAAGwAAAAQFdHlwZQQGdGFibGUEBnBjYWxsBApub19yZWNvaWwEC2FudGlfc2hha2UECWNvbnZlcmdlEwAAAAAAAAAABARhaW0ECXRvbnVtYmVyBA5BaW1Bc3Npc3RvcklkAAQGdmFsdWUEBlZhbHVlBAl0b3N0c",
    "mluZwQIRGVmYXVsdBMBAAAAAAAAAAQHTmV3Um93E+kDAAAAAAAABAlOZXdSb3dfMBPqAwAAAAAAAAQJTmV3Um93XzET6wMAAAAAAAAECU5ld1Jvd18yE/kqAAAAAAAABAlOZXdSb3dfMxPsAwAAAAAAAAQCLgsAAAAAAAABAAMBAAAEAAUABg",
    "AHAAgBAgEDAQAAAABwCQAAcAkAAAAAAwcAAACmAAAApQCAAKYAAAAnAIAAZwAAASpAAAAbAIAAAAAAAAMAAAABAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJIJAACfCQAAAQAPJgAAAKYDAAClA4AApgM",
    "AAGgAAACoAMAAwACAAJmAAAFUQEABE0AAgKUAAACbAAABpQAAAO0AAAAogcAAQAGAABkBAQETAASAZwIAAYACAARZggABVMDABBPAAoCpQoIBVABBBRMAAoDsAMEEpwKAAcACAAAAA4AEQAMABJmCAAKXAgAAEwAAgKUAgAAegQAAnwH7f5sA",
    "AAEbAIAABQAAAAQFdHlwZQQGdGFibGUEB2lwYWlycwABAQQAAAABGwAAASEBXAAAAAAAAAAAAAAAAAAAAAAAoQkAALEJAAABAAUxAAAAJgEAACUBgAAmAQAAaABAAFdAAAATAACAbQAAABRAQAATQAKApwCAAONAAACZQAABqUDAABSAQAETg",
    "ACApwAAAeNAAACZQAABGwCAABTAQAATQASApwCAAZlAgACnAIAA4wABAJlAAAGnAIAA48AAAJlAAAGpwMAAVIBAAROAAICpAMEAFIBAAROAAICnAAAB48AAAJlAAAEbAIAApwCAAMAAAACZQAABqQCAABSAQAETgACApwAAAcAAAACZQAABGw",
    "CAAAUAAAAEHWN1c3RvbV9kb25nZG9uZ190b2dnbGVfc3RhdGUECm5vX3JlY29pbAEBBARhaW0EC2FudGlfc2hha2UEAAAAAQABJQFdAVUAAAAAAAAAAAAAAAAAAAAAALMJAAC5CQAAAAAEIAAAAOYAAADlAIAA5gAAACgAQAAXQAAAEwAAgC0",
    "AAABnAIAAo0AAAFlAAAFpgEAAFMDAABOAAIBnAAABo4AAAFlAAAFpAEEAFMDAABOAAIBnAAABowABAFlAAAFpQEEAVMDAABOAAIBpQEAAFMDAABOAAIBnAAABo0ABAFlAAAEbAIAABgAAAAQdY3VzdG9tX2Rvbmdkb25nX3RvZ2dsZV9zdGF0",
    "ZQQLYW50aV9zaGFrZQQKbm9fcmVjb2lsAQEECWNvbnZlcmdlBARhaW0DAAAAAQABJQFeAAAAAAAAAAAAAAAAAAAAAAC8CQAA1QkAAAEAEmwAAABmBAAAZQSAAGYEAABoAEAAqEDAAMAAgACZgAABVIBAAROAAICtAAAAQAAAASpAAICowMAA6",
    "ADBACNBAQCZgIAB6MDAACgBwQBjgQEA2YCAAShBwABAAQABGYEAARTAQQITAAGAKEHAAEABgAEZgQABVMBBAhNAAIAlAQAAGwEAASgBwgBAAQABo0ECABnBgAGoAcIAwAGAAZnBAAEXAQAAE0ABgJcBAAATwACAVIDCAhNAAIAUgMIDE0AAgC",
    "UCAAAbAgABJwIAAUACgAKjwgIAGYKAAWcCgAGAAgAEwAKAAgADgANZwgACVwIAABNAAIAUgEIFE0AAgOUCAADbAgAB6QLDAFRAwwUTQAKAbEBDhucCAAEAAwAFY8MDANmCgAFUQMMFEwAAgOVCAADlAoAAbMAChxRAQwATgACA5QKAANdCAAA",
    "TAAGA6YLDAFRAwwUTAACA5UIAAOUCgAAoA8IAYQMAABmDAAFnAwABgAMABeMDBABZg4ABqEPAAMADgAaZgwABFMBBBxPAAICoA8IAwAOABgAEAAWZQ4ABVEBDABMAAIBsQESGGwMAARsAgAASAAAABCFjdXN0b21fZG9uZ2RvbmdfbmF0aXZl",
    "X2FpbV9zdGF0ZQQFdHlwZQQGdGFibGUEB3Jhd2dldAQDX0cEB2ltcG9ydAQJR2V0V29ybGQECWZ1bmN0aW9uBAZwY2FsbAQSQ2xpZW50QmFzZVNldHRpbmcABARHZXQEBnNhdmVkAQEEBnZhbHVlBBFiSXNBaW1Bc3Npc3RPcGVuBA9TYXZlR",
    "GF0YUNvbmZpZwEABAAAAAEAAAABEwEgAQAAAADQCQAA0AkAAAAAAwYAAACmAAAApQCAAKYAAAAnAIAAKgAAgBsAgAABAAAABBFiSXNBaW1Bc3Npc3RPcGVuAgAAAAEKAQsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANcJAADyCQAAAQ",
    "AIFgAAAOYBAADlAYAA5gEAABQAQAATgACAY0AAAFdAAAATAACAY4AAAKEAAADAAAAB2YCAACcBAAFjwQAAgAEAARlBgAEnAQABYwEBAIABAAEZQYAB2wAAARsAgAAFAAAAAQEEJ3dlYXBvbi5GaXJlQXNzaXN0ZWRBaW1pbmdEZWJ1Z0VuYWJ",
    "sZSAxBCd3ZWFwb24uRmlyZUFzc2lzdGVkQWltaW5nRGVidWdFbmFibGUgMANmZmZmZmbWPwMzMzMzMzPzPwMAAAAAAAETARkBAAAAANsJAADtCQAAAAANTAAAACYDAAAlA4AAJgMAACgAQABoQEAAo4AAABmAgAFoAEAAqEBAAOPAAABZgIAB",
    "FABBABPAA4CoAEAA6EBAACNBAQCZgIAB6IBBAAABAAHZgAABFMDBAROAAYDoAEIAAAEAAWOBAADZwIAB1wAAABMAAIAAAAACVABBABMAAYCogEEAwACAAJmAAAFUwEEBE0AAgKUAAACbAAABqABCAMAAgACZwAABlwAAABNAAIAUAMEBE0AAg",
    "CUBAAAbAQABJwGAAEABAACjQQIAGYGAAWiBQQCAAQACWYEAAVTAwQITQACAZQEAAFsBAAFoAUIAgAEAAsABgAEnAgABZgIAAFmBgAJXQQAAE8ABgKgBQgDAAQACAAIAAEACgAGnAgAB5gIAAJmBAANAAQADWwEAARsAgAAKAAAABAdyYXdnZX",
    "QEA19HBBVVS2lzbWV0U3lzdGVtTGlicmFyeQQQR2V0R2FtZUluc3RhbmNlAAQHaW1wb3J0BAV0eXBlBAlmdW5jdGlvbgQGcGNhbGwEFkV4ZWN1dGVDb25zb2xlQ29tbWFuZAMAAAAAAAABAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAPQJAAAPCgAAAgAHUQAAAKYBAAClAYAApgEAAKgAQADoQMAAAAEAAdmAAAFUgMABE4AAgO0AAACAAIABKoAAgFTAQAATQACAFABBABOACoAUQMEAE4ABgKxAQQAUwEAAE0AAgKyAQYITgACArIDBgRMAAICsgEEA5wAAAdlAgADnAIABIwEB",
    "ANlAAAHnAIABI8EAANlAAAHpwEABVEDBARPAAIDpAEEBVEDBARMAAIDlQAAA5QCAANcAAAATgACAJwEAAmPBAAAZQQABJwGAAkABgAEZQQABJwEAA2nBQAFUQMECEwAAgGVBAABlAYAAGUEAASUBgAAbAQABVEDBABMAAIDlQAAA5QCAAKzAA",
    "ABUwEEAE8AAgFQAQgATQACA5QAAANsAAAHnAIABAAEAANlAAAEUQMEAE4AAgOcAAAIAAQAA2UAAAeUAgADbAAABGwCAAAkAAAAEHWN1c3RvbV9kb25nZG9uZ190b2dnbGVfc3RhdGUEBXR5cGUEBnRhYmxlBARhaW0EC2FudGlfc2hha2UBAQ",
    "EABApub19yZWNvaWwECWNvbnZlcmdlBwAAAAEAAAABVQElAV0BYAFhAAAAAAAAAAAAAAAAAAAAAAATCgAATwoAAAAAF50AAACmBQAApQWAAKYFAAAtAAAAbQAAAKEAAADoAEAAKEFAAGOBAADZgIABJwGAAEABgAGjwQAAGYGAAWcBAAGnAYA",
    "AwAEAAiMCAQCZgYABwAEAAlnBgAEUQEEDE4AEgOgBQAAoQkAAY4IBANmBgAEnAoABQAKAA6PCAQAZwoABFwIAABMAAoBUQMEEE4ABgKcCAALAAoAEIwMCAJnCgAGXAgAAEwAAgIABgAXAAQABAAIAA9lBAAHnAYAAAAIAA2NCAgDZgYABAAIA",
    "AUACgAMZQgABJwKAAEACgAOjggIAGYKAARRAQQQTgAaAVEBBAxMABoBoAkAAqEJAAOPCAgBZgoABpwKAAMACgAQjAwMAmYKAAecCgAAAA4AEY0MDANmCgAEnA4AAQAMABaODAwAZg4ABZwMAAYADAAbAAwAFAAQAA0AEgAVZw4ACVwMAABMAA",
    "IAAAgAHQAIAAYACAARZQgABZgIAAKcCAALAAgADI8MDAJnCgAGXAgAAEwAAgEACgAUUQMEEEwACgCcDAAJAAwAEowMEABnDgAHAAoAGgAIABpcCAAATAACAQAKABQADAAFAA4AEGUMAAVRAwQQTgAqAKENEAG0DAASjgwQA48MEACMEBQBjRA",
    "UAo4QFAOPEBQAjBQYAY0UGAGBDAAQZAwEBE0ABgEAEAAGnBIAAwASABAAFAAiZBIABWUQAAB6DAACfw/1/KENEAG0DAAOjgwYA48MGACMEBwBjRAcAo4QHAOPEBwBgQwADGQMBARMAAoBnBAACgASABMAEAAhZxIABVwQAABOAAIDABAABAAU",
    "ACdlEAAEegwAAnwP9fxsAAAEbAIAAIAAAAAQHcmF3Z2V0BANfRwQHRmFjYWRlBBBHYW1lRmxvd01hbmFnZXIEDUdldENoYXJhY3RlcgAEEUluR2FtZUNvbnRyb2xsZXIEBEdldAQPR2V0R1BDaGFyYWN0ZXIEC0JsYWNrYm9hcmQEDldlYXBv",
    "bk1hbmFnZXIEA1VFBBhHYW1lcGxheUJsdWVwcmludEhlbHBlcgQXV2VhcG9uTWFuYWdlckNvbXBvbmVudAQVRmluZENvbXBvbmVudEJ5Q2xhc3MEDkdldFJlYWxXZWFwb24EFEJQX0dldEN1cnJlbnRXZWFwb24EB2lwYWlycwQaV2VhcG9uR",
    "GF0YUNvbXBvbmVudEFpbWluZwQZV2VhcG9uRGF0YUNvbXBvbmVudFByb3h5BBZXZWFwb25BaW1pbmdDb21wb25lbnQEEEFpbWluZ0NvbXBvbmVudAQVQWltQXNzaXN0b3JDb21wb25lbnQEG1dlYXBvbkFpbUFzc2lzdG9yQ29tcG9uZW50BB",
    "RXZWFwb25WaWV3Q29tcG9uZW50BA5WaWV3Q29tcG9uZW50BB1HZXRXZWFwb25EYXRhQ29tcG9uZW50QWltaW5nBBxHZXRXZWFwb25EYXRhQ29tcG9uZW50UHJveHkEGUdldFdlYXBvbkFpbWluZ0NvbXBvbmVudAQTR2V0QWltaW5nQ29tcG9",
    "uZW50BBhHZXRBaW1Bc3Npc3RvckNvbXBvbmVudAQeR2V0V2VhcG9uQWltQXNzaXN0b3JDb21wb25lbnQFAAAAAAABEwEgARUBFAEAAAAAFQoAABwKAAABAAQYAAAA5gAAAOUAgADmAAAAFABAABMAAIAbAIAAaEBAAIAAAABZgAABVIDAABOA",
    "AIBUwMAAEwAAgBsAgACoAIAAlwAAABMAAIAbAIAAagBBAKcAAAGRAAABgkBBAaoAAAEbAIAABgAAAAAEBXR5cGUEBnRhYmxlBAl1c2VyZGF0YQEBEwEAAAAAAAAAAwAAAAAAAQEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUQoAA",
    "GQKAAAAABU2AAAAJgUAACUFgAAmBQAAJQAAAG0AgAijAAAA40AAACOBAABjwQAAowEBAONBAQAjggEAY8IBAKMCAgDjQgIAI4MCAGPDAgCjAwMA40MDACOEAwBjxAMAowQEAONEBABgQAAJqIBEAOcAgADZAIAAmQABABMABYDogUQAAAKAAN",
    "kBAQETgAOAKMNEAGcDAAGAAwADwAOABVkDgAEZgwAAFABFBhOAAYAnA4ABQAMAA4ADgAUZg4ABFwMAABMAAIAlAIAA3oEAAF+C+3+egAAAHwH6fxsAAAEbAIAAFQAAAAQZUmVmcmVzaEFpbUFzc2lzdG9yQ29uZmlnBBhSZWxvYWRBaW1Bc3N",
    "pc3RvckNvbmZpZwQZUmVidWlsZEFpbUFzc2lzdG9yQ29uZmlnBBRSZWZyZXNoQWltaW5nQ29uZmlnBBNSZWxvYWRBaW1pbmdDb25maWcEFFJlYnVpbGRBaW1pbmdDb25maWcEElJlZnJlc2hBaW1pbmdEYXRhBBFSZWxvYWRBaW1pbmdEYXRh",
    "BBJSZWJ1aWxkQWltaW5nRGF0YQQRVXBkYXRlQWltaW5nRGF0YQQQQXBwbHlBaW1pbmdEYXRhBBRPbkFpbWluZ0RhdGFDaGFuZ2VkBBJSZWZyZXNoV2VhcG9uRGF0YQQRUmVsb2FkV2VhcG9uRGF0YQQSUmVidWlsZFdlYXBvbkRhdGEEEVVwZ",
    "GF0ZVdlYXBvbkRhdGEEEEFwcGx5V2VhcG9uRGF0YQQUT25XZWFwb25EYXRhQ2hhbmdlZAQHaXBhaXJzBAV0eXBlBAlmdW5jdGlvbgQAAAAAAAFjARMBFAAAAAAAAAAAAAAAAAAAAAAAZgoAAHQKAAAAAAs3AAAApgIAAKUCgACmAgAAKABAAG",
    "hAQACjgAAAGcCAARcAAAATAAGAqMBAAMAAgACZgAABVABBARNAAIClAAAAmwAAAacAgADAAIAAI0EBAGUBgACZwAAClwAAABNAAIAUgMEBE0AAgCUBAAAbAQABJwEAAUABgAGjwQEAGYGAAWcBAAGAAQAC4wECAFmBgAEUgMECE0AAgKUBAAC",
    "bAQABpwGAAMABgAAjQgIAQAKAApmBAAKXQQAAE0AAgOUBAADbAQAB5wGAASOCAgBhAgAA2UGAAeUBgADbAQABGwCAAAsAAAAEBnBjYWxsBAhyZXF1aXJlFDZERk0uQnVzaW5lc3MuTW9kdWxlLlJhbmdlTW9kdWxlLkxvZ2ljLlJhbmdlRXF1",
    "aXBMb2dpYwQFdHlwZQQGdGFibGUEG0dldEN1cnJlbnRQbGF5ZXJXZWFwb25JdGVtAAQHSW5TbG90BAlTbG90VHlwZQQLSW5pdFdlYXBvbgPsUbgehevRPwQAAAAAAAEVARMBGQEAAAAAcAoAAHIKAAAAAAUJAAAAJgEAACUBgAAmAQAAJwAAA",
    "GcAgACjAAAA5QAAABlAAAIbAIAAAQAAAAQKSW5pdEFtbW9zAgAAAAABAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHYKAACaCgAAAAAFEwAAACYBAAAlAYAAJgEAAChAwABoAEAAGYAAARdAAAATAACAI4AAAALAQAAqAACAKABAAG",
    "cAAAGjAAEA4QAAAFlAgAFlAIAAWwAAARsAgAAFAAAABCJjdXN0b21fZG9uZ2RvbmdfYWltX3BhcnRfcmV2aXNpb24ECXRvbnVtYmVyEwAAAAAAAAAAEwEAAAAAAAAAA7gehetRuL4/BwAAAAEAAAABGQFiAQMBZQFkAQAAAAB6CgAAmAoAAAA",
    "ABiYAAABmAQAAZQGAAGYBAAAnAAAAaADAAFRAAAATAACAGwCAAChAwAAXQAAAEwAAgC0AAABmAAAAqYBAABTAQAETQACAY4AAABPAAICpAEEAFMBAARMAAIBjAAEAFEDBABMAAIAbAIAApwAAAcAAgAAlAQAAmUCAAWpAQYNqQMGDpwCAAWqA",
    "AISnAAAC40ACACEBAACZQIABGwCAAAoAAAAEImN1c3RvbV9kb25nZG9uZ19haW1fcGFydF9yZXZpc2lvbgQdY3VzdG9tX2Rvbmdkb25nX3RvZ2dsZV9zdGF0ZQQEYWltAQEEC2FudGlfc2hha2UABCVjdXN0b21fZG9uZ2RvbmdfYm9uZV9hc",
    "nJheV9zbmFwc2hvdHMEH2N1c3RvbV9kb25nZG9uZ19ib25lX25hbWVfcG9vbAQkY3VzdG9tX2Rvbmdkb25nX2JvbmVfY2FjaGVfcmV2aXNpb24DexSuR+F6pD8HAAAAAQAAAAADAAQAAgAFAAYBAAAAAIgKAACXCgAAAAAEDAAAAOYAAADlAI",
    "AA5gAAACcAAABnAIAApQCAABlAgAEnAAABYwAAAKEAAAAZQIABGwCAAAEAAAADmpmZmZmZuT8HAAAAAAIBAQAEAAAAAQAFAAYBAAAAAIoKAACWCgAAAAAFEwAAACYBAAAlAYAAJgEAACcAAABoAMAAVEAAABMAAIAbAIAAJwAAARmAgAAXQAA",
    "AE0AAgGcAgAFZQIAAZwAAAqNAAADhAAAAWUCAARsAgAACAAAABCJjdXN0b21fZG9uZ2RvbmdfYWltX3BhcnRfcmV2aXNpb24DUrgehetR2D8HAAAAAAMABAAFAAYAAgABAAABAAAAAI4KAACVCgAAAAAFHQAAACYBAAAlAYAAJgEAACgAQAAX",
    "QAAAEwAAgC0AAABnAIAAFEDAABPAAYBpQEAAFIDAABMAAYBnAAABo0AAAOUAgABZQIABE0ACgGcAgAAUwMAAE4ABgGnAQAAUgMAAE8AAgGcAAAGjwAAA5QCAAFlAgAEbAIAABAAAAAQdY3VzdG9tX2Rvbmdkb25nX3RvZ2dsZV9zdGF0ZQQEY",
    "WltAQEEC2FudGlfc2hha2UDAAAAAAEABQAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACfCgAAtwoAAAMAEkoAAABmBAAAZQSAAGYEAAAUAEAAE0AAgOUAAADbAAAB5Q",
    "AAAChBQABAAQABGYEAAWiBQAChAQAAWUEAAdcAAAATQACAZQGAAFsBAAFnAYAAgAEAAOPBAABZwYABVwEAABMAAYDoAUEAAAIAA9mBAAFUQMEDEwABgOcBAAEAAgAAY8IAANmBgAGAAYAD6AFBAAACAAPZgQABFEDBAxNAAIAWgEEDE0AAgOU",
    "BAADbAQABFwEAABOAAYDowUEA6QHCAwACAANAAgAC2YGAAddBAAATAACAwAEAAyOCAQBDQsIDo0ICAB1CA4AnA4AAQAMAAKODAgDAA4AFGcMAAhcDAAATgAGAVMDCBhMAAYDlAIAAgAOAAMADgAYCRMIFmUOAARwC/H/bAAABGwCAAAwAAAAA",
    "BAl0b251bWJlcgQGcGNhbGwEBE51bQQFdHlwZQQHbnVtYmVyEwAAAAAAAAAABAVtYXRoBARtaW4TAQAAAAAAAAAEBEdldAADAAAAAAABFAETAQAAAACjCgAAqQoAAAAACRYAAAAmAgAAJQKAACYCAAAoAEAAZwCAABkAAQETwAKAZwEAAVRAw",
    "AITgACAZwEAAVXAgAITwAGAZQGAAGsBgAFnAQACgAEAAsABgAFZQYABHoAAAJ9A/H8bAIAAAgAAAAQHaXBhaXJzAAUAAAAAAAEAAQQBAwEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC5CgAAwAoAAAMABhcAAABmAQAAZQGAAGYBAA",
    "AUAEABEwAAgBsAgADoQEAAAAEAAdmAAAFUgMABE4AAgFTAwAETAACAGwCAACmBgAAXAQAAEwAAgBsAgABsAEEBEQEAAAJBQQIsgAACGwCAAAYAAAAABAV0eXBlBAl1c2VyZGF0YQQGdGFibGUBARMBAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAwgoAAMgKAAADAAgQAAAA5gEAAOUBgADmAQAA5wAAAAABAAFhAQAAowEAANmAAALXQAAAEwABgOcAgAAAAQAAQAGAAIABAAHZQAACGwCAAAEAAAATgAAAAAAAAAACAAAAAWcBaAEAAAAAwwoAAMUKAAABAAYJAAAAZgEAAGUBgABm",
    "AQAAZwAAAKcAgADnAAABAAEAAFlAAAIbAIAAAAAAAAMAAAAAAQEAAQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMoKAADOCgAAAQAFHgAAACYBAAAlAYAAJgEAAGcAAACAAAAAWYAAAVdAAAATQACAZQAAAFsAAAFnAIAAgAAAAOMAA",
    "ABZgIABV0AAABNAAIBlAAAAWwAAAWcAgACAAAAA40AAAFmAgAFXQAAAE8AAgGcAgACAAAAA44AAAFmAgAFbAAABGwCAAAMAAAAEEEdldE51bU1hdGVyaWFscwQMU2V0TWF0ZXJpYWwEE1NldE92ZXJsYXlNYXRlcmlhbAIAAAABGgEWAAAAAA",
    "AAAAAAAAAAAAAAAADQCgAA1AoAAAMABhEAAABmAQAAZQGAAGYBAADnAAAAAAEAAdmAAAHXAAAAE4AAgOmAgADXAAAAEwAAgBsAgABsAEAB0QAAAMJAwAEsgIABGwCAAAIAAAABARMBAAAAAAAAAAEAAAABagAAAAAAAAAAAAAAAAAAAAAA1go",
    "AAO0KAAADAAkiAAAAJgIAACUCgAAmAgAAFABAARMAAIAbAIAA5QAAACcBAABAAQABoQEAAONBAAAZgQACFwEAABOAAIDXAAAAEwAAgBsAgAAogcABQAEAARmBAAEUwEACE0ABgCMBAQBoQcEBoUEAAFlBAAFTQQGAEwABgCcBAAFAAQAAgAGA",
    "AMABAAEZQQACGwCAAAYAAAAAEwABAAAAAAAABAV0eXBlBAZ0YWJsZRMAAAAAAAAAAAQGcGNhbGwEAAAAAWcBagFrAAACAAAAANkKAADeCgAAAQAGEAAAAGYBAABlAYAAZgEAAGcAAACAAAAAWYAAAVcAAAATgAGAZwCAAKcAAAHnAIABAAEAA",
    "FlAAAJlAIAAawAAAhsAgAAAAAAABQAAAAABAAIBAAEBAQMAAAAAAAAAAAAAAAAAAAAAAOMKAADpCgAAAAAKFQAAAGYCAABlAoAAZgIAACgAQABnAIAAGQABAROAAoBnAQABQkHAAmsBAAFnAQABVUABgROAAYBnAYABpwEAAucBgAIAAgACWU",
    "EAAh6AAACfgPx/GwCAAAMAAAAEBnBhaXJzEwEAAAAAAAAAEwABAAAAAAAABgAAAAADAQIBBAACAQABAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7woAAGALAAABACxVAQAA5goAAOUKgADmCgAAbQAAAK0AAADtAAAALQEAAGEBAAC",
    "hQQAAwAGAAgACAADZQQAB6AFAAC0CAAVjQgAAo4IAAOPCAAAjAwEAY0MBAKODAQDjwwEAIwQCAGNEAgCjhAIAIEIABdkBAQETQAGAAAOAAmcDAAGAAwAAwAOABVkDgAEZQwAA3oEAAF/C/X/oAUAALQIAA2PCAgCjAgMA40IDACODAwBjwwMA",
    "owMEACBCAAPZAQEBEwACgCcDgAFAAwAAgAOABRnDgAEXAwAAE4AAgIADgALAA4AGmUMAAd6BAABfAv1/7QGADCNCBABjggQAo8IEAOMCBQAjQwUAY4MFAKPDBQDjAwYAI0QGAGOEBgCjxAYA4wQHACNFBwBjhQcAo8UHAOMFCAAjRggAY4YIA",
    "KPGCADjBgkAI0cJAGOHCQCjxwkA4wcKACNICgBjiAoAo8gKAOMICwAjSQsAY4kLAKPJCwDjCQwAI0oMAGOKDACjygwA4EGAES0CgAljAg0Ao0INAOOCDQAjww0AYwMOAKNDDgDjgw4AI8QOAGMEDwCjRA8A44QPACPFDwBjBRAAo0UQAOOFEA",
    "AjxhAAYwYRAKNGEQDjhhEAI8cRAGMHEgAgQoAKbQIAC6NCEgDjghIAI8MSAGMDEwCjQxMA44MTACPEEwBjBBQAo0QUAOOEFAAjxRQAYwUVAKNFFQDjhRUAI8YVAGMGFgCjRhYA44YWACPHFgBjBxcAo0cXAOOHFwAjyBcAYwgYAKNIGADjiBg",
    "AI8kYAGBCgA2tAgAH4wIIACODBgBjAxkAo0MZAOODGQAjxBkAYwQaAKMEBwDjRBoAI4UaAGPFGgCjxQYA40UGACMGGwCgQgAH40IbABEDgAEWAIMFEwArgBaA2wUTgCqAKcOCAcJC2wVnAwACgAOAAMADAAEABAAGWUMAAmgDQACAA4ADWQMB",
    "ARPAAYCnBAACwASAAAAFAAFnBQABgAUABsAFgAhZBYABmUQAAF6DAADfQ/1/aANAAIADAARZAwEBE8ABgKcEgALABIAAAAUAAWcFAAGABQAGwAWACFkFgAGZRAAAXoMAAN9D/X9oA0AAgAOABFkDAQETgAKApwSAAcAEAAYABYAImcSAAZcE",
    "AAATAAGAJwWAAkAFgACABQABwAWACRlFAAJegwAA34P8f2gDQACAAwAFWQMBAROACoCnBAADwASACJmEAAHtBIAAAAWACOBEgABUwFsJE4AAgBEFgAkCRVsK7IQECigFQABABYAJGQUBARNABoBnBoABgAYABuMGHAAABwAMWcYAAlcGAAAT",
    "AAGA5wYAAgAHgABABwABgAcADdlGAALnBoABAAcABmNHHACABwAM2cYAAoAGAA5ABoANVwYAABMAAYDnBoACAAeAAEAHAAGABwAN2UYAAh6FAACfxfh/XoMAAN+D9H9tAwAApwOAAcADAAYjhBwAQASABqUEgADlBIAAmcMAA5cDAAATgAOA",
    "AAQAA2jEXACABIAHWYQAAVQA3QgTAAGAaMRcAIAEgAdZhAABFEDdCBNAAIBYRIAHEwAAgEAEgAYZRAABLQQAAEADAAgnBIABQAQABqOEHQDABIAGJQWAABnEgALAA4AIgAMACJcDAAATgAOAAAQAA2jEXACABIAHWYQAAVQA3QgTAAGAaMRc",
    "AIAEgAdZhAABFEDdCBNAAIBYRIAHEwAAgEAEgAYZRAABKARAAG0EAAKjxB0A4wQeACNFHgBjhR4AYEQAAhkEAQETQAGAQAUAA6cFAAHABQAGAAYACpkFgAFZRQAAHoQAAJ/E/X8TwNN/WwAAARsAgAB7AAAABAdpcGFpcnMEGkNoYXJhY3Rl",
    "ckZhc2hpb25Db21wb25lbnQEGkRGTUNoYXJhY3RlckFwcGVhcmFuY2VUUFAEGkRGTUNoYXJhY3RlckFwcGVhcmFuY2VGUFAEF0NoYXJhY3RlckFwcGVhcmFuY2VUUFAEF0NoYXJhY3RlckFwcGVhcmFuY2VGUFAEDkFwcGVhcmFuY2VUUFAE",
    "DkFwcGVhcmFuY2VGUFAEGENoYXJhY3RlckVxdWlwQ29tcG9uZW50BBtTT0xDaGFyYWN0ZXJFcXVpcENvbXBvbmVudAQZQ2hhcmFjdGVyQXZhdGFyQ29tcG9uZW50BB1HZXRDaGFyYWN0ZXJGYXNoaW9uQ29tcG9uZW50BBpHZXRDaGFyYWN0",
    "ZXJBcHBlYXJhbmNlVFBQBBpHZXRDaGFyYWN0ZXJBcHBlYXJhbmNlRlBQBBFHZXRBcHBlYXJhbmNlVFBQBBFHZXRBcHBlYXJhbmNlRlBQBBtHZXRDaGFyYWN0ZXJFcXVpcENvbXBvbmVudAQFTWVzaAQNU2tlbGV0YWxNZXNoBA5DaGFyYWN0",
    "ZXJNZXNoBAdNZXNoM1AECFRQUE1lc2gEEFRoaXJkUGVyc29uTWVzaAQJTWFpbk1lc2gEFkNoYXJhY3RlclNrZWxldGFsTWVzaAQOTWVzaENvbXBvbmVudAQWU2tlbGV0YWxNZXNoQ29tcG9uZW50BBdDaGFyYWN0ZXJNZXNoQ29tcG9uZW50",
    "BBRTdGF0aWNNZXNoQ29tcG9uZW50BAlCb2R5TWVzaAQLVGFyZ2V0TWVzaAQKRHVtbXlNZXNoBBlERk1Ta2VsZXRhbE1lc2hDb21wb25lbnQECUhlYWRNZXNoBAlGYWNlTWVzaAQJSGFpck1lc2gEC0hlbG1ldE1lc2gEDlVwcGVyQm9keU1l",
    "c2gEDkxvd2VyQm9keU1lc2gEClRvcnNvTWVzaAQITGVnTWVzaAQKSGFuZHNNZXNoBAlGb290TWVzaAQLT3V0Zml0TWVzaAQMRmFzaGlvbk1lc2gEC0F2YXRhck1lc2gECVNraW5NZXNoBAlDYXBlTWVzaAQNQmFja3BhY2tNZXNoBA5BY2Nl",
    "c3NvcnlNZXNoBApFcXVpcE1lc2gEFFByZXZpZXdDaGFyYWN0ZXJTS00EB01lc2hlcwQPTWVzaENvbXBvbmVudHMEF1NrZWxldGFsTWVzaENvbXBvbmVudHMEFVN0YXRpY01lc2hDb21wb25lbnRzBBJBbGxNZXNoQ29tcG9uZW50cwQYQ2hh",
    "cmFjdGVyTWVzaENvbXBvbmVudHMEE0JvZHlNZXNoQ29tcG9uZW50cwQVQXZhdGFyTWVzaENvbXBvbmVudHMEFkZhc2hpb25NZXNoQ29tcG9uZW50cwQTU2tpbk1lc2hDb21wb25lbnRzBBNQYXJ0TWVzaENvbXBvbmVudHMEFEVxdWlwTWVz",
    "aENvbXBvbmVudHMEFUxvYWRlZE1lc2hDb21wb25lbnRzBBZEeW5hbWljTWVzaENvbXBvbmVudHMEEU1lc2hDb21wb25lbnRNYXAECE1lc2hNYXAEC1BhcnRNZXNoZXMEEENoYXJhY3Rlck1lc2hlcwQLQm9keU1lc2hlcwQORmFzaGlvbk1l",
    "c2hlcwQNQXZhdGFyTWVzaGVzBAhHZXRNZXNoBApHZXRNZXNoM1AEE0dldFRoaXJkUGVyc29uTWVzaAQRR2V0Q2hhcmFjdGVyTWVzaAQQR2V0U2tlbGV0YWxNZXNoBBlHZXRDaGFyYWN0ZXJTa2VsZXRhbE1lc2gEEUdldE1lc2hDb21wb25l",
    "bnQEGUdldFNrZWxldGFsTWVzaENvbXBvbmVudAQaR2V0Q2hhcmFjdGVyTWVzaENvbXBvbmVudAQXR2V0U3RhdGljTWVzaENvbXBvbmVudAQMR2V0Qm9keU1lc2gEDkdldFRhcmdldE1lc2gEDEdldEhlYWRNZXNoBAxHZXRGYWNlTWVzaAQM",
    "R2V0SGFpck1lc2gEEUdldFVwcGVyQm9keU1lc2gEEUdldExvd2VyQm9keU1lc2gEDkdldE91dGZpdE1lc2gED0dldEZhc2hpb25NZXNoBA5HZXRBdmF0YXJNZXNoBAxHZXRTa2luTWVzaAQVR2V0QWxsTWVzaENvbXBvbmVudHMEEkdldE1l",
    "c2hDb21wb25lbnRzBBtHZXRDaGFyYWN0ZXJNZXNoQ29tcG9uZW50cwQaR2V0U2tlbGV0YWxNZXNoQ29tcG9uZW50cwQZR2V0RmFzaGlvbk1lc2hDb21wb25lbnRzBBhHZXRBdmF0YXJNZXNoQ29tcG9uZW50cwQXVVNrZWxldGFsTWVzaENv",
    "bXBvbmVudAQVU2tpbm5lZE1lc2hDb21wb25lbnQEFlVTa2lubmVkTWVzaENvbXBvbmVudAQWUG9zZWFibGVNZXNoQ29tcG9uZW50BBdVUG9zZWFibGVNZXNoQ29tcG9uZW50BBVVU3RhdGljTWVzaENvbXBvbmVudAQZR1BDaGFyYWN0ZXJN",
    "ZXNoQ29tcG9uZW50BBpERk1DaGFyYWN0ZXJNZXNoQ29tcG9uZW50BA9VTWVzaENvbXBvbmVudBMBAAAAAAAAABMgAAAAAAAAAAAEFEdldENvbXBvbmVudEJ5Q2xhc3MEFUdldENvbXBvbmVudHNCeUNsYXNzBBJHZXRBdHRhY2hlZEFjdG9y",
    "cwQFdHlwZQQGdGFibGUECXVzZXJkYXRhBBJHZXRBbGxDaGlsZEFjdG9ycwQLQ2hpbGRBY3RvcgQPQXR0YWNoZWRBY3RvcnMECUNoaWxkcmVuBAxDaGlsZEFjdG9ycwcAAAAAAAFnARMBFAFrAWwBGAIAAAAA8goAAPkKAAABAAQYAAAA5gAA",
    "AOUAgADmAAAAFABAABMAAIAbAIAAaEBAAIAAAABZgAABVIDAABOAAIBUwMAAEwAAgBsAgACoAIAAlwAAABMAAIAbAIAAagBBAKcAAAGRAAABgkBBAaoAAAEbAIAABgAAAAAEBXR5cGUECXVzZXJkYXRhBAZ0YWJsZQEBEwEAAAAAAAAAAwAA",
    "AAAAAQQBAwAAAAAAAAAAAAAAAAAAAAAA+goAAAcLAAABAAYYAAAAZgEAAGUBgABmAQAAFABAABMAAIAbAIAAZwAAAIAAAADhAAAAI0EAAFmAAAJXQAAAE0ACgKiAQAHAAAAAmYAAARTAQAETAAGAowABAOhAQQEhQQAA2UAAAdPA/38bAIAA",
    "BgAAAAATQAAAAAAAAAAEBXR5cGUEBnRhYmxlEwAAAAAAAAAABAZwY2FsbAMAAAAAAQEFAAACAAAAAPwKAAD8CgAAAQAEBwAAAOYAAADlAIAA5gAAAGcAAACAAAAAWUAAARsAgAAAAAAAAQAAAAABAAAAAAAAAAAAAAAAAAAAAAD/CgAABQsA",
    "AAAACBMAAADmAQAA5QGAAOYBAAAoAEAAZwCAABkAAQETAAKAZwEAAUJBwAJrAQABZwEAAVVAAYETAAGAZwGAAYABAAJZQQABHoAAAJ8A/X8bAIAAAwAAAAQGcGFpcnMTAQAAAAAAAAATQAAAAAAAAAAEAAAAAAIBAAECAAEAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGILAAB4CwAAAQAUbgAAAOYEAADlBIAA5gQAAGgAQABpQMAApwCAAMAAAACZAAABWYAAAKiAQADtAIAHI8EAAGMBAQCjQQEA44EBACPCAQBjAgIAo0ICAOOCAgAjwwIAYwMDAKNDAwDj",
    "gwMAI8QDAGMEBACjRAQA4ECAB5kAAQETgAKA6AFAAOmBxAMAAoAAQAIAA6PCBADlAoAA2YGAAtcBAAATQACA5QGAANsBAAGegAAAH4H8f6iAQADtAAACIwEFAGNBBQCjgQUA48EFAOBAAAKZAAEBE4ACgOgBQADpgcQDAAKAAEACAAOjwgQA",
    "5QKAANmBgALXAQAAE0AAgOUBAADbAQABnoAAAB+B/H+ogEAA7QCAAyMBBgBjQQYAo4EGAOPBBgAjAgcAY0IHAKOCBwDgQIADmQABARPAAYDnAQABAAIAAEACAAPZgYABFMDHAxNAAIDlAYAA2wEAAZ6AAAAfQf1/qIBAAO0AAAIjQQYAYwEH",
    "AKMBCADjgQcA4EAAApkAAQETQAKA5wGAAQACAABAAgAD2cGAAdcBAAATwACAFMBHBBNAAIBlAoAAWwIAAZ6AAAAfwfx/pQAAAJsAAAEbAIAAIQAAAAQHc3RyaW5nBAZsb3dlcgQHaXBhaXJzBAxyYW5nZXRhcmdldAQNcmFuZ2VfdGFyZ2V0",
    "BBB0YXJnZXRjaGFyYWN0ZXIED3RyYWluaW5ndGFyZ2V0BAlwcmFjdGljZQQGZHVtbXkED2RmbWFpY2hhcmFjdGVyBBBkZm1jaGFyYWN0ZXJfYWkEBV9haV8EDGFpY2hhcmFjdGVyBAxjaGFyYWN0ZXJhaQQEYm90BARucGMECHNvbGRpZXIE",
    "B21pbmlvbgQFZmluZBMBAAAAAAAAAAQSYnBfZGZtY2hhcmFjdGVyX2MEFW5jX2JwX2RmbWNoYXJhY3Rlcl9jBBNkZm1wbGF5ZXJjaGFyYWN0ZXIEEHBsYXllcmNoYXJhY3RlcgQGYklzQUkEBUlzQUkEBGJBSQQHYklzQm90BAZJc0JvdAQH",
    "YklzTlBDBAZJc05QQwEBBA5Jc0FJQ2hhcmFjdGVyBAAAAAAAARcBEwEUAAAAAAAAAAAAAAAAAAAAAAB9CwAAlQsAAAAAEz8AAACmBAAApQSAAKYEAAAnAAAAVABAABNAAIAnAAAAGwAAAS0AAAArAAAAKEDAAG0AAAOjgAAA48AAACMBAQBj",
    "QQEAo4EBAOPBAQBgQAADGQABARMACYBnAQABgAEAAlmBAAGtAQAA7QEAACECAABAAgAEgAKAAllCAAFUAMACE0AEgGhCwACtAgAB4wICACNDAgCgQgABWQIBARMAAoCnA4ABwAOAAgAEgAaZw4ABlwMAABOAAIAABAAEQASABxlEAAFeggAA",
    "3wL9f2cCAABRAoAEQoLCBK2CAACsAoGFrIIBhiqAggSTwf9/HoAAAJ8A9n8nAAAAGwAAARsAgAANAAAAAAQHaXBhaXJzBA1ERk1DaGFyYWN0ZXIEE0RGTVBsYXllckNoYXJhY3RlcgQMR1BDaGFyYWN0ZXIEDVNPTENoYXJhY3RlcgQKQ2hh",
    "cmFjdGVyBAVQYXduBAxTdGF0aWNDbGFzcwQJR2V0Q2xhc3MTAQAAAAAAAAAEBW5hbWUEB3ZhbHVlcwQAAAABcAAAARgBFAEAAAAAgwsAAIcLAAABAAMPAAAApgAAAKUAgACmAAAAVABAABOAAIBoAAAAVwAAABMAAIAbAIAAKkBAAGcAgABR",
    "AIAAQoDAAGoAgAAbAIAAAwAAAAABARMBAAAAAAAAAAIAAAABBwEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACXCwAAwQsAAAIAGWMAAAAmBgAAJQaAACYGAACtAAAA7QAAACYBAABoAUAAqEFAAOOBAABZgYABqMFAAMABgAKZgQAB",
    "FABBAxNAAYCoQUEAwAGAApnBAAGXAQAAEwAAgAABgAMUgEECE8ABgKjBQQDjAQIAJwKAAEACgACjggAAGQKAAZmBAAAAAQADFIBBAhPAAYCowUEA4wECACcCgABAAgAAo4IAABkCgAGZgQAAAAEAA6cBAAGXQQAAE4AAgKcBgAHjQQIAmYEA",
    "AasBAAFUgEECE4AAgKcBAAEUgEEDEwAAgJsAAAGhAQAA6IFCACcCgAMZAoAA2QEBABOACIAog0IAacPCBRkDAQETwAaAbQQAAKcEgADnBAABIwUDAEAFAAKABQAIwAWACJnEAAOXBAAAE0AEgCjFQABABYAJGYUAAVRAQwoTAAGAKMVAAEAF",
    "gAkZhQABFIBDChNAAIAYRYAJEwAAgAAFgAhnBQAEgAUACuFFAABZRYAB04IAgB6DAACfQ/h/08L/f96BAABfgvZ/mwAAARsAgAAPAAAABAdyYXdnZXQEA19HBAlHZXRXb3JsZAQFdHlwZQQJZnVuY3Rpb24EBnBjYWxsAAQHc2VsZWN0EwIA",
    "AAAAAAAABBFVR2FtZXBsYXlTdGF0aWNzBAdpcGFpcnMEB3ZhbHVlcwQUR2V0QWxsQWN0b3JzT2ZDbGFzcwQGdGFibGUECXVzZXJkYXRhCQAAAAAAARQBbwEYARcBagETAXEBZwIAAAAApAsAALELAAACAApUAAAAZgIAAGUCgABmAgAAVABA",
    "ABNAAYCnAAAAVIAAABOAAICoAIAAlwAAABMAAIAbAIAAFEDAABNAD4CogEABqcBAAecAgAEAAQAA2QAAAZmAAADogEAB6QDBAQABAAFjQQEAo4EBAOUBgADZgIAC10AAABOAC4DogEAB6QDBAQABAAFjwQEAo4EBAOUBgADZgIAC10AAABNA",
    "CYDogEAB6QDBAQABAAFjAQIAo4EBAOUBgADZgIAC10AAABMAB4DogEAB6QDBAQABAAFjQQIAo4EBAOUBgADZgIAC10AAABPABIDnAAACJwGAAkABAACjgQIAGQGAAdmAAADXQAAAE8ACgOcAAAIowUIBYwEDAKcBAAPAAQAAI0IDAJkBgAEZ",
    "AQAA2YAAANdAAAATAACAGwCAAGqAQwCnAIADkQAAAYKAQQHtQAAA7ACAh+rBAAEbAIAAEAAAAAAEBVBhd24EB3N0cmluZwQGbG93ZXIEBWZpbmQECmNoYXJhY3RlchMBAAAAAAAAAAQMcmFuZ2V0YXJnZXQECW9wZXJhdG9yBAVoZXJvBAVN",
    "ZXNoBAdzZWxlY3QTAgAAAAAAAAAECEdldE1lc2gBAQQHb2JqZWN0CAAAAAEAAQMAAAAEAAUABgABAQIAAAAAAAAAAAAAAAAAAAAAALsLAAC7CwAAAQAFCAAAACYBAAAlAYAAJgEAAGcAAACAAAAA6ADAAFlAgAEbAIAAAQAAAAQFbmFtZQIA",
    "AAABBgELAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADDCwAAzQsAAAEADzEAAACmAwAApQOAAKYDAABoAAAAV0AAABMAAIBoAEAAqEDAAO0AgAEjgQAAY8EAAKMBAQDgQIABmQABARMABYDoQcEAKILBAEACAAPZgYABKMLBAEACgAMZ",
    "ggABFABCBBPAAoAoQsIAQAKAA6mCwgDpwsIAKQPDAGlDwwAZwgADFwIAABOAAIBUgMMEEwAAgFsCAAGegAAAHwH6f60AAQDpgMIArMCAh+nAwgCswACI6QDDAKzAgIjpQMMArMAAiZsAAAEbAIAAEwAAAAQEcmVkBAdpcGFpcnMEDUZMaW5l",
    "YXJDb2xvcgQMTGluZWFyQ29sb3IECFZlY3RvcjQEB3Jhd2dldAQDX0cEBXR5cGUECWZ1bmN0aW9uBAZwY2FsbBMBAAAAAAAAABMCAAAAAAAAABMDAAAAAAAAABMEAAAAAAAAAAAEAlIEAkcEAkIEAkECAAAAAQcAAAAAAAAAAAAAAAAAAAAA",
    "AAAA0AsAAN8LAAABAAwpAAAA5gIAAOUCgADmAgAAaAAAAFQAwAATAACAWwAAAahAwADtAIACI4EAAGPBAACjAQEA40EBACOCAQDgQIACmQABAROABIDowcEAKALCAEACAAPZgYABKELCAEACgAMZggABFIBCBBNAAoAowsIAQAKAA4ACAAAZ",
    "woABFwIAABPAAIBUAMAEE0AAgCpAAgBbAgABnoAAAB+B+n8qAAAAGwAAARsAgAAMAAAAAAQHaXBhaXJzBAZGTmFtZQQFTmFtZQQQTWFrZUxpdGVyYWxOYW1lBA1TdHJpbmdUb05hbWUEEkNvbnZfU3RyaW5nVG9OYW1lBAdyYXdnZXQEA19H",
    "BAV0eXBlBAlmdW5jdGlvbgQGcGNhbGwCAAAAAXQAAAAAAAAAAAAAAAAAAAAAAAAA4QsAAOULAAADAAoXAAAAZgIAAGUCgABmAgAA5wAAAAABAABjAQAAgAGAAMABAAHZgIAC1wAAABNAAIAlAYAAGwEAAScBAABAAQAAowEAAOcBgAAAAoAA",
    "2YEAAQACAAEaAYACGwEAABsAgAABAAAABBhTZXRWZWN0b3JQYXJhbWV0ZXJWYWx1ZQIAAAABFQF1AAAAAAAAAAAAAAAAAAAAAADnCwAACQwAAAEAD2sAAACmAwAApQOAAKYDAAAUAEAAE4AAgGMAAAAYQIAAEwAAgCNAAABogEAAaQCAAFTA",
    "wAATQAGApwCAAMAAgACZgAABlwAAABMAAIBbAAABqAAAAegAwQEoQcEBY4EBANmAgAEnAQACQAGAAaPBAQAZgYABaAHCAYABAAJZgQABFEDCAhPABIBogcIBgAEAAsABAAFZwYABV0EAABOAAYDogcIBAAIAAkACgAGAAgAB2cEAAoABAARA",
    "AYADVwEAABMAAYBUwEADE4AAgOiBQADsgQEAmwEAAWjBwgGtAQAC4wEDACNCAwBjggMAo8IDAKBBAAJZAQEBE8AEgKgCwQHoQsEBAAOABJmCgAHoAsIBAAMABdmCAAEUQMIFE4ACgOiCwgEAAwAFQAMAAdnCgAHXAgAAEwABgFTAQAYTgACA",
    "aINAAGwDAwAbAwABXoEAAN9B+n9oAcEBqEHBAeMBBABZgYABqAHCAcABgAKZgQABFEBCAxOAAoCogcIBwAGAAgACAAGZwYABlwEAABMAAYBUwMADE4AAgCiCQAAswgEA2wEAAaYBAACbAQABGwCAABEAAAAEBmdyZWVuBARyZWQEIGN1c3Rv",
    "bV9jaGFyYWN0ZXJfeHJheV9tYXRlcmlhbHMABAdyYXdnZXQEA19HBAVzbHVhBBNkb250Q2FsbExvYWRPYmplY3QEBXR5cGUECWZ1bmN0aW9uBAZwY2FsbAQHaXBhaXJzBAtMb2FkT2JqZWN0BBFTdGF0aWNMb2FkT2JqZWN0BAtGaW5kT2Jq",
    "ZWN0BApMb2FkQXNzZXQEB2ltcG9ydAUAAAABAAEaAQkAAAETAAAAAAAAAAAAAAAAAAAAAAALDAAAFQwAAAIADS4AAAAmAwAAJQOAACYDAABUAEAAEwABgKhAQADAAIAAmYAAAVSAQAETAACAGwCAAKhAQADpwMAAmYAAARSAQAETQAOAqABB",
    "AOnAwACZAAEBE8ABgOcBgAAAAgAAY0IBAIACgAIUgEEDE8D/f8ACAAPZQYACnoAAAB9B/X+nAIAAwAAAACPBAQBmAQAAmUAAAqcAgADAAAAAIwECAGUBAACZQAACpwCAAMAAAAAjQQIAY4ECAJlAAAIbAIAACwAAAAAEBXR5cGUEBnRhYmxl",
    "BAptYXRlcmlhbHMEBnBhaXJzBAxTZXRNYXRlcmlhbAEABBNTZXRPdmVybGF5TWF0ZXJpYWwEFVNldFJlbmRlckN1c3RvbURlcHRoBBtTZXRDdXN0b21EZXB0aFN0ZW5jaWxWYWx1ZRMAAAAAAAAAAAIAAAAAAAEUAAAAAAAAAAAAAAAAAAAA",
    "AAAXDAAARwwAAAQAGaMAAAAmBgAAJQaAACYGAAAnAQAAQAEAABmBAAEXAQAAE4AAgCgBwABUQEACEwAAgBsAgAAUgEABE4AAgCOBAACYQAACEwAAgKPAAAAoAcEAaQEAAqhBQQHAAYACmYEAAVSAQQMTQAKArcEAAO0BAACswYGD7QEAAKzB",
    "AYTnAYABzgGAA6zBgYRAAQADLEEBAKcBAALAAQABmYEAARSAQgMTAACAGwCAAOjBQgEAAoAA2YEAAddBAAATAACA4wEDAClCwgIXQgAAEwAAgCMCAwADAoIDZwKAAVYAggQTAACAJUIAACUCgABnAoACgAIAAONCAwBZwoABVwIAABMAAYDo",
    "wkIBAAMABdmCAAHXQgAAEwAAgOMCAwAWAMMFEwAAgOOCAwApw8MCFIAABhOAAIApA8QCVMACBhMAAIAlQwAAJQOAABcDAAATQASAF0IAABPAA4BjAwMAg4PDBeODAwBdgwKAZwSAAoAEAADjRAQAAAUACFnEAAJXBAAAE0AAgFSAAQkTQACA",
    "JQMAABMAAIBcw/x/ZwOAAoADAADjgwQAAAQAA1lDAAJnA4ACgAMAAOPDBAAlBIAAWUMAAmcDgAKAAwAA4wMFACNEBQBZQwACFwMAABPAAIAXQgAAE0AAgGzBAIsbAIAAbMECiGMDAwCDg8MF44MDAF3DB4BpBMICaQSECFRAwAgTAAOAZwSA",
    "AoAEAADjRAQAAAUACFnEAAJXBAAAE0ABgOkEwgLsREAI6cTBAhSAQgkTwP9/7IQECGcEgAKABAAA40QEAAAFAAhZxAACVwQAABNAAIBUgAEJE0ABgOcEgAIABQAAY8UFAIAFAAjABQAD2USAAlyD939sgYCHbMEAi2zBgYQbAIAAGAAAAAQe",
    "Y3VzdG9tX2NoYXJhY3Rlcl94cmF5X2VuYWJsZWQBAQQGZ3JlZW4EBHJlZAQdY3VzdG9tX2NoYXJhY3Rlcl94cmF5X21lc2hlcwQFdHlwZQQGdGFibGUECm1hdGVyaWFscwQGc2F2ZWQEDWxhc3RfYXR0ZW1wdAAECXRvbnVtYmVyEwAAAAAA",
    "AAAABBBHZXROdW1NYXRlcmlhbHMTAQAAAAAAAAAEBmNvbG9yBA9tYXRlcmlhbF9jb3VudAQMR2V0TWF0ZXJpYWwEE1NldE92ZXJsYXlNYXRlcmlhbAQVU2V0UmVuZGVyQ3VzdG9tRGVwdGgEG1NldEN1c3RvbURlcHRoU3RlbmNpbFZhbHVl",
    "ExQAAAAAAAAABAljYXRlZ29yeQQMU2V0TWF0ZXJpYWwGAAAAARoBAAAAAQ4BdwEUAAAAAAAAAAAAAAAAAAAAAABJDAAAcAwAAAMAGpYAAABmBgAAZQaAAGYGAADnAAAAAAEAANmAAAHXAAAAE4AAgOgAwAAUQMABEwAAgBsAgAAUgEABE4AA",
    "gOOAAACYQIABEwAAgKPAAADoAMEAKQGAAWhBQQGAAYAAWYEAAVdBAAATAACAY4EBAKjBQQHAAQACmYEAAVQAQgMTQACArQEAAAABAAPsAAEApwGAAcABAAAjQgIAmcGAAZcBAAATAAGAKEJBAUACgAMZggAB2EEABBMAAIDjgQEAKYJCAhSA",
    "AAQTAAOAKcJCAhTAAQQTQAKAKQJDAhdCAAATQACAJwIAAg4CAAQDAoICZwIAAlYAggQTAACAJUIAACUCgAAXQgAAEwAAgBsAgAAsgQCFLEEBhizBgYVjggEAg0LDA+NCAwBdwgKAZwOAAYADAADjgwMAAAQABlmDAAJXQwAAEwABgGcDgAGA",
    "AwAA48MDAAAEAAZZQwACXIL8f2cCgAKAAgABWYIAAacCAAPAAgAAIwMEAJmCgAGXAgAAE0ADgKhCRAHnAoADmQIBARPAAYDnA4ABAAQAAGMEBACnBAAEwAQAB5mEAAHABIAE2UOAAp6CAAAfQ/1/o4IBAMNCwwMjQwMAncIEgKcDgAHAAwAA",
    "I4QEAEAEgAaZwwAClwMAABMAA4BUwMQHE4ACgChERAFnBIADGQQBARMAAYBnBYAEgAWAB8AFAAoABoAEWUUAAh6EAACfBP5/nIL6f6cCgAHAAgAAIwMFAGYDAACZQgACpwKAAcACAAAjQwUAZQMAAJlCAAKnAoABwAIAACODBQBjgwEAmUIA",
    "AhsAgAAXAAAABB5jdXN0b21fY2hhcmFjdGVyX3hyYXlfZW5hYmxlZAEBBAZncmVlbgQEcmVkBB1jdXN0b21fY2hhcmFjdGVyX25vcm1hbF9zZWVuBAl0b251bWJlchMAAAAAAAAAAAQFdHlwZQQGdGFibGUEEEdldE51bU1hdGVyaWFscwQE",
    "a2V5BA9tYXRlcmlhbF9jb3VudAQNbGFzdF9hdHRlbXB0EwEAAAAAAAAABCRDcmVhdGVBbmRTZXRNYXRlcmlhbEluc3RhbmNlRHluYW1pYwQeQ3JlYXRlRHluYW1pY01hdGVyaWFsSW5zdGFuY2UEI1NldFZlY3RvclBhcmFtZXRlclZhbHVl",
    "T25NYXRlcmlhbHMEB2lwYWlycwQMR2V0TWF0ZXJpYWwABBNTZXRPdmVybGF5TWF0ZXJpYWwEFVNldFJlbmRlckN1c3RvbURlcHRoBBtTZXRDdXN0b21EZXB0aFN0ZW5jaWxWYWx1ZQoAAAABGgEAAAABFAEPAXMBFgEKAXUBdgAAAAAAAAAA",
    "AAAAAAAAAAAAcgwAAHoMAAABAAsYAAAApgIAAKUCgACmAgAAaABAAKhAwADAAIAAmQABARMAA4DogcAAAAIAA9mBAAEUwMADE8ABgOkBQQMUAIADEwABgOcBAAEAAoACQAIAA9lBgAFsQMECnoAAAB8B/H8bAIAABgAAAAQdY3VzdG9tX2No",
    "YXJhY3Rlcl94cmF5X21lc2hlcwQGcGFpcnMEBXR5cGUEBnRhYmxlBAljYXRlZ29yeQADAAAAAQAAAAF4AAAAAAAAAAAAAAAAAAAAAAB+DAAAgwwAAAAAAwgAAACmAAAApQCAAKYAAAAqQECAKsBAgSpAQYIqQECDGwCAAAcAAAAEJWN1c3Rv",
    "bV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9zbmFwc2hvdAAEI2N1c3RvbV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9jdXJzb3ITAQAAAAAAAAAULWN1c3RvbV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9zbmFwc2hvdF9hdHRlbXB0E///////////FC9j",
    "dXN0b21fY2hhcmFjdGVyX3NjYW5fYWN0b3Jfc25hcHNob3RfY2hhcmFjdGVyAQAAAAEAAAAAAAAAAAAAAAAAAAAAAACFDAAAkwwAAAAACiIAAABmAgAAZQKAAGYCAAAoQMAAaABAABmAAAEXQAAAEwAAgCOAAAACwEAAKgAAgCgAQABnAAAB",
    "WYCAACpAAIJnAIABWUCAAGhAwQCtAIAC44ABACPBAQBjAQIAo0ECAOOBAgCgQIACWQABARPAAICnAQACwAGAAiECAACZQYABXoAAAN9A/n8bAIAACwAAAAQnY3VzdG9tX2NoYXJhY3Rlcl9jb2xvcl9yZXNjYW5fcmV2aXNpb24ECXRvbnVt",
    "YmVyEwAAAAAAAAAAEwEAAAAAAAAABB1jdXN0b21fY2hhcmFjdGVyX25vcm1hbF9zZWVuBAdpcGFpcnMDAAAAAAAAAAADexSuR+F6tD8DuB6F61G4zj8DMzMzMzMz4z8DMzMzMzMz8z8GAAAAAQAAAAEGAX0BGQF8AQAAAACMDAAAkQwAAAAA",
    "BBIAAADmAAAA5QCAAOYAAAAnAAAAaADAAFRAAAATAACAGwCAAGqAwIBqAMGBKEBBAWcAgAGogMEAl0AAABMAAICjwAEAGUCAARsAgAAIAAAABCdjdXN0b21fY2hhcmFjdGVyX2NvbG9yX3Jlc2Nhbl9yZXZpc2lvbgQlY3VzdG9tX2NoYXJh",
    "Y3Rlcl9zY2FuX2FjdG9yX3NuYXBzaG90AAQjY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9yX2N1cnNvchMBAAAAAAAAAAQGcGNhbGwEH2N1c3RvbV9jaGFyYWN0ZXJfY29sb3JfYXR0ZW1wdBMAAAAAAAAAAAQAAAABAAAAAAEABQAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlQwAAMsMAAABAB/HAAAApgcAAKUHgACmBwAAaABAAIAAAABZgAABGECAABMAAIAjQAAAaIBAAKjAQADjAAEAWYCAAacAgADAAIAAI0EBAJmAgAHnAAABAAEAAWOBAQDZwIAB1wAAABNAAIAUwEEC",
    "EwAAgBsAgABoAcIBqAFAAOhBwgGZgQABl0EAABMAAICjgQIA6AFAACjCwgHZgQAB10EAABMAAIDjAQMAKELDAWiCQwCAAoACWYIAARTAwwQTgACAUQKAAldCAAATAACAY0IAAKiCQwDAAoACmYIAARTAQwUTwAGAFAABBBNAAYAVgIEEE0AD",
    "gIPCAQDnAgACFoCCBRNAAoCnAoACwAIAAgADAAGZgoABQAEABaOBAgDAAQAA6kABhOoAgIXqAIGGqAJEAKlCRAXRAoACJwMAAwIDAwMDg0IGmYKAAcACAAMAAwAFY4MCAN3CG4Dpg4MCKIRDAEAEgAcZhAABFMBDCBOAAIAphMQHF0QAABMA",
    "AIAmBAAAZwSAA4AEAAhZhAABVwQAABMAGIBpxMQHFMDBCBMABIBoBEUAaUTFCKgERQCphEUJ5wQABAAFAAjZBAABmYQAAOPEBQAjhQIAZQWAAFmEgAIUwMEIEwAAgGVEAABlBIAA7EOEiWnExAdXRAAAE0ASgGkExgcUwMEIE8AAgGcEgASA",
    "BAAIWYQAAexDBIxpBMYHVwQAABOAAIBoRMYBFIDGCBMAD4BpBMYHVwQAABOAAIBjxAYAV0QAABMAAIBjBAcAqQTGB5cEAAATgACAqETHAZdEAAATAACAqITHARTARwkTgACA48QHAJhEgAkTAACAowQIAOgEQAApRcgH2YQAAddEAAATAACA",
    "4wQDACiFQwBphcgHGYUAARTAQwoTwACAA8UEAGcFAAUWAIUKEwABgCcFgAVABQAIGYUAAewDBZHsA4CQKMVIAGmFyAcZBQEBE4ADgGgGyQEUgMYME4ABgGcGAAaABgAMwAYAAAAHAAlAB4AIWUaAAhMAAYBnBoAGgAYADMAGAAAABwAJWUYA",
    "Ah6FAACfhft/3ILjf8KCQgXqwIKEGwCAACUAAAAECXRvbnVtYmVyEwAAAAAAAAAABAdyYXdnZXQEA19HBAdGYWNhZGUEEEdhbWVGbG93TWFuYWdlcgQNR2V0Q2hhcmFjdGVyAAQlY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9yX3NuYXBz",
    "aG90BCNjdXN0b21fY2hhcmFjdGVyX3NjYW5fYWN0b3JfY3Vyc29yEwEAAAAAAAAAFC1jdXN0b21fY2hhcmFjdGVyX3NjYW5fYWN0b3Jfc25hcHNob3RfYXR0ZW1wdBP//////////xQvY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9yX3Nu",
    "YXBzaG90X2NoYXJhY3RlcgQFdHlwZQQGdGFibGUEBW1hdGgEBG1pbgQHb2JqZWN0BA9pc19sb2NhbF9wcm94eQQHc3RyaW5nBAVmaW5kBAZsb3dlcgQKc2VsZnByb3h5BAZpc19haQQYY3VzdG9tX2FpX2NvbG9yX2VuYWJsZWQBAQQDYWkE",
    "BXJlYWwEFGN1c3RvbV9haV9jb2xvcl9rZXkEFmN1c3RvbV9yZWFsX2NvbG9yX2tleQQGZ3JlZW4EBHJlZAQVbWVzaF9yZWZyZXNoX2F0dGVtcHQEB21lc2hlcwQHaXBhaXJzBB5jdXN0b21fY2hhcmFjdGVyX3hyYXlfZW5hYmxlZA4AAAAA",
    "AAETARQBAAEMAXIBEAEaARcBbgENAW0BeQF6AAAAAAAAAAAAAAAAAAAAAADNDAAAzwwAAAEAAwsAAACmAAAApQCAAKYAAAAUAEAAE4AAgGMAAABXQAAAEwAAgGNAAABbAAABGwCAAAIAAAAEBmdyZWVuBARyZWQAAAAAAAAAAAAAAAAAAAAA",
    "AAAAAADRDAAA1AwAAAEABBAAAADmAAAA5QCAAOYAAABUAEAAE8AAgFRAQAATQACAFIBAABNAAIBjAAAAWwAAAWcAAACAAAAAWgAAAVsAAAAbAIAAAwAAAAQFbm9uZQQEb2ZmBAlkaXNhYmxlZAEAAAABfwAAAAAAAAAAAAAAAAAAAAAA1gwA",
    "AN0MAAABAAQXAAAA5gAAAOUAgADmAAAAZwAAAIAAAABZgAABAACAABQAQAATgACAZwCAAKNAAABZQAABFABAABMAAIBlQAAAZQCAAKpAAIGqAICBaACAAapAAIJnAAACWUCAABsAgAAFAAAABAVub25lBANhaQQYY3VzdG9tX2FpX2NvbG9y",
    "X2VuYWJsZWQEFGN1c3RvbV9haV9jb2xvcl9rZXkEFWN1c3RvbV9haV9jb2xvcl9uYW1lBQAAAAGAAXsBAAEIAX4AAAAAAAAAAAAAAAAAAAAAAN8MAADkDAAAAQAEDQAAAOYAAADlAIAA5gAAAGcAAACAAAAAWYAAAQAAgABqAACAaAAAAWpA",
    "gIBnAIABWUCAABsAgAACAAAABBZjdXN0b21fcmVhbF9jb2xvcl9rZXkEF2N1c3RvbV9yZWFsX2NvbG9yX25hbWUEAAAAAX8BAAEIAX4AAAAAAAAAAAAAAAAAAAAAAOgMAADxDAAAAQAKGwAAAGYCAABlAoAAZgIAAFRAQAATAACAZUAAAGUA",
    "gAAqQACAaABAAFRAwAATAAOAaIDAAKjAQABZAAEBE8AAgKcBAAHAAQACAAKAAplBgAFegAAA30D+f2cAgAFZgIAAKkCAgWcAAAJZQIAAGwCAAAQAAAAEHmN1c3RvbV9jaGFyYWN0ZXJfeHJheV9lbmFibGVkAQEEBnBhaXJzBB1jdXN0b21f",
    "Y2hhcmFjdGVyX3hyYXlfbWVzaGVzBQAAAAEAAAABeAEGAX4AAAAAAAAAAAAAAAAAAAAAAPoMAAAUDQAAAAAMVAAAAOYCAADlAoAA5gIAACgAQABoQMAAgAAAAFmAAAEUgMAAEwAEgGnAQABUAMEAE0ADgGlAQQBUAMEAE4ACgGcAAAGpwEAA",
    "44ABAClBQQBpwUEAWUCAAmcAAAGpwEAA44ABAClBQQBZQAACZwCAAaMAAgBZgAABpgAAAFQAwQATwAGA6EDCACOBAgBnAQABgAGAAOPBAgBZAYAB2YAAAIAAgAEUAEEBE0AAgOUAAADbAAAB5wAAAgABAAFjAQMA2YCAARQAwQETQACAJQEA",
    "ABsBAAEtAQAAYQEAACxBgYZnAQABgAGAAeOBAwApQkMCQAIAAlnBgAJXQQAAE4ABgOcBAAEAAoABY4IDAKlCQwLZwQACgAEABEABgANXQQAAE0AAgOUBAADbAQAB7QEBAOzBgIEpQkMC7AGCguwBgYPsgYGHKsABgOUBgADbAQABGwCAABAA",
    "AAAEJmN1c3RvbV9jaGFyYWN0ZXJfZmFzaGlvbl9yZWZyZXNoX2hvb2sEBXR5cGUEBnRhYmxlBAlkZWxlZ2F0ZQAECWNhbGxiYWNrBAdSZW1vdmUEBm93bmVyBB9ERk1DaGFyYWN0ZXJJdGVtRmFzaGlvbk1hbmFnZXIEB3NlbGVjdBMCAAAA",
    "AAAAAAQER2V0BBVPblNldE1hdFRhc2tDb21wbGV0ZQQKT25SZWZyZXNoBARBZGQEB2hhbmRsZQYAAAABAAAAARQBGAETAX4BAAAAAAcNAAAJDQAAAAADBgAAAKYAAAClAIAApgAAACcAAAAZQIAAGwCAAAAAAAABAAAAAAUAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAAAAAABcNAAA8EAAAAAA2LgEAAGYNAABlDYAAZg0AACgAQABoQMAAgAAAAFmAAAFUgMAAEwABgG1AAACtAAAAbICAgQAAgAAqAACAaQBBABRAwQATAAGAaYBBAFdAAAATAACAY8ABAFsAAAFoAMIAqEDCAOOAAgBZ",
    "gIABqADCAOhAwgAjwQIAmYCAAegAwgAoQcIAYwEDANmAgAEnAQABQAGAAaNBAwAZgYABF0EAABPAAIAoAcIAaEHCAKNBAwAZgYABaAHCAKhBwgDjgQMAWYGAAagBwgDoQcIAI8IDAJmBgAHoQcAAAAKAANmBAAEUgMADE0ADgFQARAETwAKA",
    "VABEAhNAAoDoQcAAAAKAAtmBAAEUQMQDEwABgOhBwAAAAgAD2YEAAVRAxAMTQACA44EEANsBAAHoAcIAAAKAAGPCBADZgYABKALCAEACgACjAgUAGYKAAWgCwgCAAoAA40IFAFmCgAGoAsIAwAKAACODBQCZgoABVADEAxNAAYBUAEQEE8AA",
    "gFQAxAQTQACAFABEBRNAAIDjggQA2wIAAenCAQFUAMQFE4AAgCjDxQBhAwAAGUMAASjDxQBAA4ACowMGABnDgAEXAwAAEwABgKhDwADAA4AGmYMAAVRARgcTQACAo4MEAJsDAAGow8UAwAOAAiOEBgCZw4ABlwMAABMAAYAoRMAAQASABxmE",
    "AAFUQEYIE0AAgCOEBAAbBAABKMTFAEAEAAOjxAYAGcSAAajExQDABAADIwUHAJnEgAEoxcUAQAUAA6NFBwAZxYABqMXFAMAFAAMjhgcAmcWAARcEAAATQAOAlwQAABPAAoAXBQAAE0ACgJcFAAATwAGAVADECBNAAYBUAMQJE8AAgFQAxAoT",
    "QACAFADECxNAAIAjhgQAGwYAAQAGAARjxgcAoUYAAOGGAAAhxwAAYwcIAKEHAQDhRwEAIYgBAGHIAQChCAIA4UgCACGJAgBhyQIAoQkDAOFJAwAhigMAYcoDAKEKBADhSgQAIYsEAGHLBAChCwUA4UsFACNMCABADIAXo4wIAOYMAAAhjQUA",
    "WYwAAlcMAAATAACAAsxIGEAMgBejDAkA4cwFACENBgBZjAACVwwAABMAAIACzEgYQAyAF6NMCQDmDAAAIU0GAFmMAAJXDAAAEwAAgAKMSRhADIAXo8wJAOGMBgAhzQYAWYwAAlcMAAATAACAAgxKGEAMgBejTAoA5gwAACENBwBZjAACVwwA",
    "ABMAAIACDEoYY4wKAKcMAAHADIAGAA2AGJmMgAHoTMAAAA0AGdmMAAEUwMoZE0ACgO1MAADsjAyWIU0HAOwMjZYpTcsZbAONGCmNSwAszYwYAsxLGBPN/39jDAwApwwAAcAMgAYADYAYmYyAAehMwAAADQAZ2YwAARTAyhkTQAKA7UwAAOyM",
    "jJghjQcA7AyNlilNyxlsA40YKY1LACzNjBgCjEwYE83/f0AMgBejzAwA4cwHACYNAABZjAACVwwAABMAAIACjEwYQAyAF6MMDQDhDAgAJg0AAFmMAAJXDAAAEwAAgAKMTBgsAAyDLACCmlSATRgTAACAZUwAAGUMgAAsQAyCKgCMm2kMQQBX",
    "DAAAE0AAgFhMABgTAACAYwwOAFsMAAEbAIAAOQAAAAQdY3VzdG9tX2Rvbmdkb25nX2FwaV9zZXR0aW5ncwQFdHlwZQQGdGFibGUECXdyYXBwZXJzBAppbnN0YWxsZWQBAQQLaG9va19jb3VudBMBAAAAAAAAAAQHcmF3Z2V0BANfRwQKVUlO",
    "YW1lMklEBAhVSVRhYmxlBAdGYWNhZGUEClVJTWFuYWdlcgQIcmVxdWlyZQQHaW1wb3J0AAQJZnVuY3Rpb24TAAAAAAAAAAAEFlN5c3RlbVNldHRpbmdNYWluVmlldwQOU2V0dGluZ0J0blR3bwQPU2V0dGluZ0J0bkZvdXIEDlNldHRpbmdT",
    "bGlkZXIEBnBjYWxsFEFERk0uQnVzaW5lc3MuTW9kdWxlLlN5c3RlbVNldHRpbmdNb2R1bGUuVUkuU3lzdGVtU2V0dGluZ01haW5WaWV3BAZ0YWJsZQQoREZNLll4RnJhbWV3b3JrLk1hbmFnZXJzLlVJLlV0aWwuVUlVdGlsBApHcmlkUGFu",
    "ZWwEClNjcm9sbEJveAQXV2lkZ2V0Qmx1ZXByaW50TGlicmFyeQQUV2lkZ2V0TGF5b3V0TGlicmFyeQQTQHN0YXJybW9kcyAgICAgICAgFE0vR2FtZS9CbHVlUHJpbnRzL1VJL1VNRy9Db21tb24vTGlicmFyeS9XQlBfVGl0bGVXaXRoTGlu",
    "ZS5XQlBfVGl0bGVXaXRoTGluZV9DEwAAAAAAAAAABBFfSW5pdER5bmFtaWNCdG5zEwEAAAAAAAAABBVTZXRTZWxlY3RlZE1vZGVQYW5lbAQQT25Jbml0RXh0cmFEYXRhEwEAAAAAAAAABAxPblNob3dCZWdpbhMBAAAAAAAAAAQLT25BY3Rp",
    "dmF0ZQQZX0ZldGNoU2V0dGluZ1N5c3RlbUJ5VGFiBAlmdW5jdGlvbgQJb3JpZ2luYWwECHdyYXBwZXIECXdyYXBwZXJzEwEAAAAAAAAABBtfVXBkYXRlU3lzZXRlbVNldHRpbmdQYW5lbAQJb3JpZ2luYWwTAQAAAAAAAAAEDE9uSGlkZUJl",
    "Z2luBAhPbkNsb3NlBAdyb3dfaWQTCQAAAAAAAAAUKmN1c3RvbV9jaGFyYWN0ZXJfY29sb3Jfc2V0dGluZ19ob29rX2NvdW50EwAAAAAAAAAACgAAAAEAAAABEwEZAYABfwGBAYIBEgERIQAAAAAyDQAAQQ0AAAAABRcAAAAmAQAAJQGAACYB",
    "AAAoAEAAaEDAAIAAAABZgAABVIDAABOAAIBtAAAAAACAACoAAIBhAAAAgACAAOcAAAGZQAABgACAAOcAgAGZQAABgACAAOcAAAKZQAABGwCAAAMAAAAEB1N1YlVJcwQFdHlwZQQGdGFibGUFAAAAAQsAAQEIAQkBCgEAAAAAOA0AAD0NAAAB",
    "AAgSAAAA5gEAAOUBgADmAQAAaABAAKcAgABZAAEBE4AAgBQAgAITAACAGwCAAF6AAADfgP5/aEBAAGmAwACnAIAAwAAAAFlAgAEbAIAAAwAAAAQHaXBhaXJzBAZ0YWJsZQQHaW5zZXJ0AgAAAAABAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAGANAABpDQAAAQAFIgAAACYBAAAlAYAAJgEAABQAQAATQACAZgAAAFsAAAFoQEAAgAAAAFmAAAEUgMAAE8AEgGjAQACAAAAA4wABAFmAgAFXQAAAEwADgGjAQACAAAAA40ABAFmAgAFXQAAAE4ABgGjAQACAAAAA44ABAFmAgAFX",
    "QAAAEwAAgEAAAABbAAABGwAAARsAgAAHAAAAAAQFdHlwZQQGdGFibGUEB3Jhd2dldAQKX19jcHBpbnN0BAhfY3BwSW5zBAlfY3BwaW5zdAEAAAAAAQAAAAAAAAAAAAAAAAAAAAAAaw0AAHINAAABAAYXAAAAZgEAAGUBgABmAQAAaABAAKhA",
    "QADjgAAAWYCAAajAQADAAIAAmYAAARQAQQETAAKAqEBBAMAAgAAAAQAAmcCAAZcAAAATgACAVIDBARMAAIDbAAABGwAAARsAgAAHAAAABAdyYXdnZXQEA19HBAxnZXRmcm9td2VhawQFdHlwZQQJZnVuY3Rpb24EBnBjYWxsAAEAAAAAAQAA",
    "AAAAAAAAAAAAAAAAAAAAdA0AAIENAAAEAAwtAAAA5gIAAOUCgADmAgAAKAFAAGhBQACjgQAAGYGAAWjBQACAAQACWYEAARQAwQITwAKAaEFBAIABAALAAQAAAAKAAEACAAGAAoABWcEAA1cBAAATgACAVIBBAxMAAICbAQABaEFBAKcBgADj",
    "wQEAWcGAAVcBAAATwAKAVIBBAxNAAoDAAQAD2YGAAAACAABAAoAAgAIAAezBgIXsgQKF7EGChOwBAoTbAQAB5gEAANsBAAEbAIAADAAAAAQHcmF3Z2V0BANfRwQIRk1hcmdpbgQFdHlwZQQJZnVuY3Rpb24EBnBjYWxsAAQHTWFyZ2luBAVM",
    "ZWZ0BARUb3AEBlJpZ2h0BAdCb3R0b20CAAAAAAEBBgAAAAAAAAAAAAAAAAAAAAAAhg0AAI4NAAABAAgfAAAA5gEAAOUBgADmAQAAFABAABNAAIBmAAAAWwAAAWcAAACAAAAAWYAAAahAwADogEABAAGAAJnAgAGXAAAAE4AAgFQAwAETAACA",
    "2wAAAShBwABogUABgAEAABnBgAHAAIACgAAAApcAAAATAACA2wAAASYBAAAbAQABGwCAAAMAAAAABAZwY2FsbAQPU2xvdEFzR3JpZFNsb3QDAAAAARoAAQEXAAAAAAAAAAAAAAAAAAAAAACQDQAAnA0AAAIACRkAAAAmAgAAJQKAACYCAACo",
    "AEAA6EBAACOBAACZgIAB6MBAAAABAAHZgAABFADBAROAAoDoQEEAAAEAAUABAACjgQEAwAGAANnAgALXAAAAE4AAgFTAQQITAACAGwEAARsAAAEbAIAACAAAAAQHcmF3Z2V0BANfRwQOTmV3THVhTG9jVGV4dAQFdHlwZQQJZnVuY3Rpb24E",
    "BnBjYWxsBBZEb25nRG9uZ05hdGl2ZVNldHRpbmcAAQAAAAABAAAAAAAAAAAAAAAAAAAAAACeDQAAxA0AAAQADDEAAADmAgAA5QKAAOYCAAAUAEAAE0AAgCUBAAAbAQABJwEAAEABgACAAQABGYGAAddAAAATAACA40AAAGUBAACogcAA4QEA",
    "AJlBAAGogcAA4UEAAJmBAAGXAQAAEwAAgGUBgADmAQAAKILAAGGCAAAZQgABFADAAxOAAIAogsAAYcIAABlCAAFUAMADEwACgCiCwABhAgEAGYIAARcCAAATAACAZQGAAGiCwAChQgEAWUIAASiCwABhggEAGUIAAVsBAAEbAIAAAwAAAAAE",
    "DUhlYWRlcjNfMjhwdAQGcGNhbGwCAAAAAR8AAQcAAAAApA0AAKYNAAAAAAMGAAAApgAAAKUAgACmAAAAJwCAACoAAIAbAIAAAQAAAAQXV0JQX1RpdGxlV2l0aExpbmVfTmFtZQIAAAABAAEEAAAAAAAAAAAAAAAAAAAAAACnDQAAqQ0AAAAA",
    "BQkAAAAmAQAAJQGAACYBAAAoAEAAZwAAAKcAgADnAAABGUAAAhsAgAABAAAABAlTZXQgdGV4dAMAAAABAAEEAQMAAAAAAAAAAAAAAAAAAAAAAK0NAACvDQAAAAADBgAAAKYAAAClAIAApgAAACgAwAArAAAAGwCAAAEAAAAEE3d0REZUZXh0",
    "QmxvY2tUaXRsZQIAAAABBwEAAAAAAAAAAAAAAAAAAAAAAACxDQAAsw0AAAAABAkAAADmAAAA5QCAAOYAAAAnAIAAAQBAAKNAAAAZgIABKwAAABsAgAACAAAABBJHZXRXaWRnZXRGcm9tTmFtZQQTd3RERlRleHRCbG9ja1RpdGxlAgAAAAEH",
    "AQAAAAAAAAAAAAAAAAAAAAAAALYNAAC4DQAAAAAECAAAAOYAAADlAIAA5gAAACcAAAABAEAApwCAABlAgAEbAIAAAQAAAAQIU2V0VGV4dAIAAAABBwEEAAAAAAAAAAAAAAAAAAAAAAC7DQAAvQ0AAAAABAgAAADmAAAA5QCAAOYAAAAnAAAA",
    "AQBAAKcAgAAZQIABGwCAAAEAAAAED1NldEZvbnRTdHlsZUlEAgAAAAEHAQMAAAAAAAAAAAAAAAAAAAAAAMANAADCDQAAAAADBwAAAKYAAAClAIAApgAAACcAAAABAEAAGUAAARsAgAABAAAABBZTeW5jaHJvbml6ZVByb3BlcnRpZXMBAAAA",
    "AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMYNAADNDQAAAQAGFAAAAGYBAABlAYAAZgEAABQAQAATAACAGwCAAGhAQACpgEAAwAAAACPBAABZwAACVwAAABNAAIAUAEABEwAAgBsAgADoQEAAIQEAANlAAAEbAIAABAAAAAAEBnBj",
    "YWxsBBJHZXRXaWRnZXRGcm9tTmFtZQQJTGluZV8xMTMBAAAAAAEBAAAAAMoNAADMDQAAAAAECQAAAOYAAADlAIAA5gAAACcAAAABAEAAqEDAAKmAQAEZQIABGwCAAAMAAAAEDlNldFZpc2liaWxpdHkEEUVTbGF0ZVZpc2liaWxpdHkECkNv",
    "bGxhcHNlZAIAAAABAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADPDQAA3A0AAAYADyUAAACmAwAApQOAAKYDAABUAEAAE0AAgBQAwAATQACApgEAAJsBAAGnAQAAwAEAAJmBAAHoQcAAKIJAAUACAAOAAoAA5gIAANnBgALXAQAA",
    "E0AAgBQAQAQTQACAZgIAAFsCAAFnAoABgAIABMACAAEAA4ABQAOAAllCgAIUwEACE4AAgGcCAAKAAgAEWUIAARsCAAEbAIAABAAAAAAEBnBjYWxsBAdDcmVhdGUBAQUAAAABGgABARUBIAEhAAAAAAAAAAAAAAAAAAAAAADeDQAA5g0AAAEA",
    "CxgAAACmAgAApQKAAKYCAABoAEAAV0AAABMAAIBtAAAArQAAACqAAIAqgMCAVMBAABMAAIAqAACCqEDBAMAAgACZAAEBE8AAgOiBwQAAAgADQAIAANlBgAGegAAAH0H+fxsAgAAHAAAABA50aXRsZV93YWl0ZXJzBA50aXRsZV9sb2FkaW5n",
    "AQAABAx0aXRsZV9jbGFzcwQHaXBhaXJzBAZwY2FsbAIAAAABAAABAAAAAAAAAAAAAAAAAAAAAADoDQAADQ4AAAEADEkAAADmAgAA5QKAAOYCAABoAEAAgAAAAFmAAAFUQMAAEwAAgBsAgABogMAAVMDAABPAAIBAAAAAqIDAAFlAAAEbAIAA",
    "aADBAFdAAAATAACAbQAAAGpAAIJoQEEAaYDBAKgAwQDAAAAAWUCAAWjAwQAUAMIAEwAAgBsAgABqAMKDZwAAAacAgAHjQAIAWYCAAacAAAHAAIAAI4ECAJmAgAHoAEAAAAEAAdmAAAFUQMABE8AAgOcAAAImAQAA2UAAARsAgADhAAAAKMFC",
    "AEABAAGAAYAA5gEAACcCgAJAAoABpgIAABmBgAMXQQAAE8ABgGjBQgCAAQAB5gEAACcCgAJAAoABpgIAAFmBAAMAAYACF0EAABOAAIBnAQACpgEAAFlBAAEbAIAADAAAAAQFdHlwZQQJZnVuY3Rpb24EDHRpdGxlX2NsYXNzAAQOdGl0bGVf",
    "d2FpdGVycwQGdGFibGUEB2luc2VydAQOdGl0bGVfbG9hZGluZwEBBBBSZXNvdXJjZU1hbmFnZXIEEkFzeW5jTG9hZFJlc291cmNlBAZwY2FsbAYAAAAAAQEAAAIBAwEjAR0BAAAAAPoNAAAADgAAAQAFDwAAACYBAAAlAYAAJgEAAGYAAACo",
    "AEAAwAAAAJmAAAEUQEABE0AAgKcAgABpgAAApwAAAcAAgACZQAABGwCAAAIAAAAEBXR5cGUEBnRhYmxlAwAAAAAAAAUABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADw4AACAOAAAGAA4cAAAAZgMAAGUDgABmAwAApwEAAMABgACZ",
    "gQAB6AHAAClCQABAAgAAgAIAA8ACAAEAA4AB2cEAA9cBAAATQACAFIBABBPAAIBnAgABgAIAA1mCAAEAAoAEVIBABBOAAIBoAsAAoQIAAFlCAAEbAgABGwCAAAMAAAAEBnBjYWxsBA9BZGRDaGlsZFRvR3JpZAADAAAAARoAAQEeAQAAAAAW",
    "DgAAHQ4AAAAABCQAAADmAAAA5QCAAOYAAAAnAAAAAQBAAKcAgAAZQIABJwAAAAFAQACnAAABGUCAAScAAAABgEAApwCAAZdAAAATAACAo8AAABlAgAEnAAAAAQBBAKhAQQKpgEEBGUCAAScAAAABwEEAqABCAqlAQgEZQIABJwCAAlSAQgAT",
    "wACAJwAAAAHAQgCnAIACGUCAARsAgAAMAAAABAdTZXRSb3cEClNldENvbHVtbgQOU2V0Q29sdW1uU3BhbhMBAAAAAAAAAAQXU2V0SG9yaXpvbnRhbEFsaWdubWVudAQVRUhvcml6b250YWxBbGlnbm1lbnQEDEhBbGlnbl9GaWxsBBVTZXRW",
    "ZXJ0aWNhbEFsaWdubWVudAQTRVZlcnRpY2FsQWxpZ25tZW50BAxWQWxpZ25fRmlsbAAEC1NldFBhZGRpbmcGAAAAAQgBAgEDAQQAAQEFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiDgAAMQ4AAAEABh4AAABmAQAAZQGAAGYBAABn",
    "AAAAgAAAAOMAAABZgIABpwAAAMAAAAAjQQAAmYCAAVSAwAATQAGA6MDAACEBAADZQAAB6MDAACFBAADZQAABVIBAAROAAIDowMAAIYEAANlAAAEsgMCALIBAgCyAQIIsgMCCLIBAgxsAgAAHAAAABBZfZG9uZ2RvbmdfbmF0aXZlX2dyaWQE",
    "GF9kb25nZG9uZ19uYXRpdmVfc2Nyb2xsAAQGcGNhbGwEGV9kb25nZG9uZ19uYXRpdmVfYnV0dG9ucwQZX2Rvbmdkb25nX25hdGl2ZV93aWRnZXRzBB1fZG9uZ2RvbmdfbmF0aXZlX2J1aWxkX3Rva2VuAwAAAAACAAEBBAMAAAAAJg4AACYO",
    "AAAAAAUJAAAAJgEAACUBgAAmAQAAJwAAAAEAQACnAIAA5wAAARlAAAIbAIAAAQAAAAQUUmVtb3ZlU3ViVUlCeVBhcmVudAMAAAAAAgEAAQEAAAAAAAAAAAAAAAAAAAAAACcOAAAnDgAAAAADBwAAAKYAAAClAIAApgAAACcAAAABAEAAGUAA",
    "ARsAgAABAAAABBFSZW1vdmVGcm9tUGFyZW50AQAAAAEBAAAAAAAAAAAAAAAAAAAAAAAqDgAAKg4AAAAAAwcAAACmAAAApQCAAKYAAAAnAAAAAQBAABlAAAEbAIAAAQAAAAQRUmVtb3ZlRnJvbVBhcmVudAEAAAABAgAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAAAAMw4AAEkOAAAKABNIAAAApgQAAKUEgACmBAAApwIAAIECQAUAAwAAZwOAAIADgACZgoAC5wIAAQADAAXZggABFEDABRNAAIAmAwAAGwMAAQGDwAWAAwACwAOAAgAEAANUwMADEwAAgGVEAABlBIAAGUMAAwEDwQWj",
    "QwEAwAMABBlDAAIBA8EFo4MBAMADgAQZQwACJwOAAUADgAWjwwEAGYOAARRAQAYTwACAZwMAAoADgAVZgwABAAOABlRAQAYTwASAZwOAAhQAwgETgACAowMCAJdDAAATAACAo0MCAOODAgAUAMIBE4AAgCNEAgAXRAAAEwAAgCMEAgBjhAIA",
    "WYOAAqjDQgPhAwAAmUMAAZPD/39oA0MDaUPDBqmDQwDAA4AFWUOAAdsCAAEbAIAADwAAAAQJQWRkU3ViVUkABA9Jbml0QnRuRHluYW1pYwEBBBNTZXRCdG5DbGlja0J5SW5kZXgTAQAAAAAAAAATAgAAAAAAAAAEBVNsb3QTAAAAAAAAAAAT",
    "EAAAAAAAAAATDQAAAAAAAAAEBnBjYWxsBAZ0YWJsZQQHaW5zZXJ0BBlfZG9uZ2RvbmdfbmF0aXZlX2J1dHRvbnMHAAAAAQQBCAEbAAIBHgEcAAEBAAAAAD4OAABFDgAAAAAEIQAAAOYAAADlAIAA5gAAACcAAAABAEAApwCAABlAgAEnAAAA",
    "AUBAAKcAAAEZQIABJwAAAAGAQACjwAAAGUCAAScAAAABAEEAqEDBAamAQQEZQIABJwAAAAHAQQCoAMIBqUBCARlAgAEnAAACVIBCABPAAIAnAAAAAcBCAKcAAAIZQIABGwCAAAwAAAAEB1NldFJvdwQKU2V0Q29sdW1uBA5TZXRDb2x1bW5T",
    "cGFuEwEAAAAAAAAABBdTZXRIb3Jpem9udGFsQWxpZ25tZW50BBVFSG9yaXpvbnRhbEFsaWdubWVudAQMSEFsaWduX0ZpbGwEFVNldFZlcnRpY2FsQWxpZ25tZW50BBNFVmVydGljYWxBbGlnbm1lbnQEDFZBbGlnbl9GaWxsAAQLU2V0UGFk",
    "ZGluZwUAAAABDAECAQMABgENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLDgAAWg4AAAQACx8AAACmAgAApQKAAKYCAAAnAQAAQAEAAKMBAAAZgYABFEBAAhPAAIBnAYAAgAEAAFmBAAEAAYACVEBAAhNAA4BnAQABo4EAANhBAAET",
    "AACA48EAACOCAABYQoABEwAAgGPCAABZgYACqAHBAeEBAACZQQABk8H/fxsBAAEbAIAABQAAAAQFU2xvdAATAAAAAAAAAAATDQAAAAAAAAAEBnBjYWxsBAAAAAACAR4BHAABAQAAAABQDgAAVw4AAAAABCEAAADmAAAA5QCAAOYAAAAnAAAA",
    "AQBAAKcAgAAZQIABJwAAAAFAQACjgAAAGUCAAScAAAABwEAAowABABlAgAEnAAAAAUBBAKiAQQGpwEEBGUCAAScAAAABAEIAqEBCAamAQgEZQIABJwCAAVTAQgATwACAJwAAAAEAQwCnAIABGUCAARsAgAANAAAABAdTZXRSb3cEClNldENv",
    "bHVtbhMAAAAAAAAAAAQOU2V0Q29sdW1uU3BhbhMCAAAAAAAAAAQXU2V0SG9yaXpvbnRhbEFsaWdubWVudAQVRUhvcml6b250YWxBbGlnbm1lbnQEDEhBbGlnbl9GaWxsBBVTZXRWZXJ0aWNhbEFsaWdubWVudAQTRVZlcnRpY2FsQWxpZ25t",
    "ZW50BAxWQWxpZ25fRmlsbAAEC1NldFBhZGRpbmcEAAAAAQQBAQADAQUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFwOAABwDgAACQAUVAAAAOYEAADlBIAA5gQAAGcCAABBAsAEwAIAACcDgABAA4AAWYKAAqcCAAHAAoAEmYIAARRA",
    "QAUTQACA5gIAANsCAAHnAoABAAMABWODAADZgoABVEDABROAAIAow0ACYQMAABlDAAEBA0EFo0MBAOODAQAZQwACAQNBBaPDAQDjAwIAGUMAAgEDQQWjQwIA44MCABlDAAIBA0EFo8MCAOMDAwAZQwACAUNDBaNDAQDAA4ACGUMAAgFDQwWj",
    "wwEAwAMAAxlDAAIBQ0MFo0MCAMADgAMZQwACAUNDBaPDAgDAAwAEGUMAAgGDQwWow0MCqQNEB+NDBAAoxEMCKYRECGNEAgCYRAACEwAAgKNEAQCDREEJGQSAAZkDAAAZQwAAJwOAAkADAAWAAwAB48MEACPEBAAZQ4ACKANFAilDRQZpg0UA",
    "gAMABRlDgAGbAgABGwCAABcAAAAECUFkZFN1YlVJAAQJX3d0VGl0bGUEBnBjYWxsBApTZXRCdG5UeHQTAQAAAAAAAAAEBUhlYWQTAgAAAAAAAAAEBkNoZXN0EwMAAAAAAAAABAVMZWdzEwQAAAAAAAAABA5Qb2ludCAmIFNob290BBNTZXRC",
    "dG5DbGlja0J5SW5kZXgEFUluaXRTZXR0aW5nQnRuQnlFdW1lBAVtYXRoBARtYXgTAAAAAAAAAAAEBG1pbhMNAAAAAAAAAAQGdGFibGUEB2luc2VydAQZX2Rvbmdkb25nX25hdGl2ZV9idXR0b25zBgAAAAEEAQkBGwACAAEBKAEAAAAAYg4A",
    "AGIOAAAAAAQIAAAA5gAAAOUAgADmAAAAJwAAAAEAQACnAIAAGUCAARsAgAABAAAABAhTZXRUZXh0AgAAAAELAQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHIOAACPDgAACQAXQQAAAKYFAAClBYAApgUAAGcCAABBAsAEwAIAACcD",
    "gABAA4AAWYKAAqcCAAHAAoAEmYIAARRAQAUTQACA5gIAANsCAAHogsABIQMAANlCAAHowsAB6QLBBQADAAJow8ABaUPBBoADgALow8AB6YPBByjEwQFABAADGYQAARdEAAATAACAAAQAAgIEQgjZAwABWQMAANmCAAAhQwAAQUNCBcADAAIA",
    "BIACQAQAA4AEAAbABAAGJQUAAFhFgAMTAACAY4UCAFlDgARow8IBoYMAAFlDAAFnAwACgAMABcADAAEjBAMAYwQDAFlDgAJoQ8MBaYPDBqnDQwDAAwAFWUOAAZsCAAEbAIAAEAAAAAQJQWRkU3ViVUkABAZwY2FsbAQFbWF0aAQEbWF4BARt",
    "aW4EBmZsb29yBAl0b251bWJlcgMAAAAAAADgPwQSSW5pdFNldHRpbmdTbGlkZXITAQAAAAAAAAAEBnBjYWxsEw0AAAAAAAAABAZ0YWJsZQQHaW5zZXJ0BBlfZG9uZ2RvbmdfbmF0aXZlX2J1dHRvbnMFAAAAAQQBCgEbAAEBKAMAAAAAdg4A",
    "AHYOAAAAAAMGAAAApgAAAKUAgACmAAAAJwCAACoAAIAbAIAAAQAAAAQIQnBUaXRsZQIAAAABCgEDAAAAAAAAAAAAAAAAAAAAAAB4DgAAfg4AAAEACSEAAAAmAgAAJQKAACYCAABoAEAAaUDAAKcAgADoAEAA6YDAAScBAAFoAUAAacHAAqgB",
    "QQDAAQAAmYEAAZdBAAATAACApwGAAYJBQQNZAQAB2QAAAFmAAACnAIABFICAABMAAIAbAIAAawCAAaiAQQDhAAAAmUAAAacAAAPAAIAAmUAAARsAgAAHAAAABAVtYXRoBARtYXgEBG1pbgQGZmxvb3IECXRvbnVtYmVyAwAAAAAAAOA/BAZw",
    "Y2FsbAcAAAAAAwEEAQUBCwEKAQMBCAEAAAAAfA4AAHwOAAAAAAcNAAAApgEAAKUBgACmAQAAKABAAAFAQACnAIAA44AAACjBQAFnAYABGYEAAZIAAQEZQIABGwCAAAQAAAAEDF93dFR4dFZhbHVlBAhTZXRUZXh0BATvvJoECXRvc3RyaW5n",
    "BAAAAAAEAAUAAAEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIDgAAiw4AAAAABw8AAACmAQAApQGAAKYBAAAnAIAAKgAAgChAQAABgEAApwCAAOPAAAAoAUEBZwGAARmBAAGSAAEBGUCAARsAgAAFAAAABAZfbmFtZQQMX3d0VHh0",
    "VmFsdWUECFNldFRleHQEBO+8mgQJdG9zdHJpbmcEAAAAAQoBAwADAQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJEOAACrDwAAAQAbTQEAAKYGAAClBoAApgYAABQAQAATQACAZQAAAFsAAAFnAAAAgAAAAFlAAAFnAIAApwAAAcAA",
    "AAAjQQAAmQCAAVmAAAAUAMAAE0AAgKUAAACbAAABpwCAAZmAgADogEACIQEAANlAAAHogEACIUEAANlAAAHogEACIYEAANlAAAHowMACAAEAAUABgADZQIAB5wAAA9mAgAAogUACYcEAABlBAAEmAQAAaIFAAqEBAQBZQQABVABAAhOAAIBo",
    "gUACoUEBAFlBAAEsgACCLMCAgm0BAAAsQAGDbQEAACxAgYNtAQAALEABhKhBwgPogUICAAIAA9mBAAFUwMIDE4AAgO0BAACAAYAD6oGBhOgBQwItAgACY0IDAKOCAwDjwgMAIwMEACBCAALZAQEBE8AAgCnDAgMUAEAGEwAAgKxBxAXegQAA",
    "X0L+f+GBAQAnAgAFQAIAAIACgAHjggQAI8MEAGMDBQCjQwUA44MFAClEQwNhxAEAoQQCABlCgAUnAgAFQAIAAIACgAHjggQAI8MFAGMDBgCjQwUA44MFACmEQwNhRAIAoYQCABlCgAUnAgAFQAIAAIACgAHjQgYAI8MEAGODBgCjQwUA44MF",
    "ACnERgNhxAIAoQQDABlCgAUnAgAFQAIAAIACgAHjQgYAI8MFAGMDBwCjQwUA44MFAClERwNhRAMAoYQDABlCgAUnAoAFaILHAxmCAAEUwEcEEwAAgGVCAABlAoAAgAIABBTARwUTgAGA5wIABigDyAMXQwAAEwAAgCNDCADZggABgAKABecC",
    "AAYog8gD2YIAAScDAAVAAwAAgAOAAePDCAAjxAQAYwQJAKNEBQDjhAUAAAWABGHFAwChBQQAGUOABScDAAVAAwAAgAOAAePDCAAjxAUAY0QJAKOECQDjxAkAVABKBRMAAIAlRQAAJQWAAGFFBAChhQQAGUOABScDAAVAAwAAgAOAAeNDCgAj",
    "xAQAY4QKAKOECQDjxAkAVMDKBRMAAIAlRQAAJQWAAGHFBAChBQUAGUOABScDAAVAAwAAgAOAAeNDCgAjxAUAYwQLAKNEBQDjhAUAKEXLA1SASwoTAACAJUUAACUFgABhRQUAoYUFABlDgAUow8sDF0MAABMAAIAjAwwA6gGDlyjDywMUQEwG",
    "EwAAgOqBzJcoA00CaMPMAxmDAAEXQwAAEwAAgCNDDQDqAYOZKANNAmiDzQMZgwABF0MAABMAAIAjww0A6gEDmygDTQJoA84DGYMAARdDAAATAACAI0MOAOoBA5woA00CaIPOAxmDAAEXQwAAEwAAgCPDBQDqAQOdIcMFAGEDBgChQwYA48MO",
    "ACjEywMUAE8IE0AAgOODBAATAAKAKMTLAxRATwgTQACA40MGABPAAIAoxMsDFIBMCBMAAIDjgw8AJwSAB0AEAACABIAB48QPACMFEABABYAHoYUGAOHFBgAhBgcAYUYHABlEAAUnBAAIQAQAAIAEgAHjRBAAI4UQAGPFDgCjxRAA6MXMAyPG",
    "DgBhhgcAGUQABScEAAhABAAAgASAAeMEEQAjRREAY8UOAKOFEQDohc0DI8YOAGHGBwAZRAAFJwQACEAEAACABIAB48QRACMFEgBjxQ4Ao0USAOgFzgMjxg4AYQYIABlEAAUnBAAIQAQAAIAEgAHjhBIAI8USAGPFDgCjxRAA6IXOAyPGDgBh",
    "RggAGUQABScEgAhhhAgAGUQAASgEUwJhxAgAGUQAASgEUwJhBAkAGUQAASgEUwJhRAkAGUQAASUEgAAbBAABGwCAAE0AAAAABAxfd3RSb290TWFpbgQGcGNhbGwEF0FkZFdpZGdldFRvUGFyZW50X0Z1bGwEGF9kb25nZG9uZ19uYXRpdmVf",
    "c2Nyb2xsBBZfZG9uZ2RvbmdfbmF0aXZlX2dyaWQEGV9kb25nZG9uZ19uYXRpdmVfYnV0dG9ucwQZX2Rvbmdkb25nX25hdGl2ZV93aWRnZXRzBB1fZG9uZ2RvbmdfbmF0aXZlX2J1aWxkX3Rva2VuBB1jdXN0b21fZG9uZ2RvbmdfdG9nZ2xl",
    "X3N0YXRlBAV0eXBlBAZ0YWJsZQQHaXBhaXJzBApub19yZWNvaWwECWNvbnZlcmdlBARhaW0EC2FudGlfc2hha2UBABMCAAAAAAAAABMAAAAAAAAAAAQKTm8gUmVjb2lsBAdFbmFibGUECERpc2FibGUTAQAAAAAAAAAEFkJ1bGxldCBTcHJl",
    "YWQgQ29udHJvbBMDAAAAAAAAAAQNSGlwLUZpcmUgQWltBARhaW0ECEFEUyBBaW0EC2FudGlfc2hha2UEFGN1c3RvbV9haV9jb2xvcl9rZXkEBW5vbmUEGWN1c3RvbV9haV9jb2xvcl9sYXN0X2tleQQEcmVkBBZjdXN0b21fcmVhbF9jb2xv",
    "cl9rZXkTBQAAAAAAAAAEDkJvdCBIaWdobGlnaHQECkJvdCBDb2xvcgQEUmVkBAZHcmVlbgQEcmVkEwYAAAAAAAAABA1QbGF5ZXIgQ29sb3IEBHJlZAQNUGxheWVyIFgtUmF5BB5jdXN0b21fY2hhcmFjdGVyX3hyYXlfZW5hYmxlZAEBBBdj",
    "dXN0b21fYWltX3RhcmdldF9wYXJ0BAVoZWFkBAVtaXNzBAVmcmVlBBFjdXN0b21fYWltX3NwZWVkBAl0b251bWJlchMyAAAAAAAAAAQRY3VzdG9tX2FpbV9yYW5nZRNaAAAAAAAAAAQUY3VzdG9tX2FpbV9kaXN0YW5jZROWAAAAAAAAAAQV",
    "Y3VzdG9tX2FpbV9sb2NrX3RpbWUTAQAAAAAAAAAEBmNoZXN0BARsZWcTBAAAAAAAAAATCAAAAAAAAAAEDFRhcmdldCBCb25lEwkAAAAAAAAABApBaW0gU3BlZWQTZAAAAAAAAAATCgAAAAAAAAAECEFpbSBGT1YTaAEAAAAAAAATCwAAAAAA",
    "AAAEDUFpbSBEaXN0YW5jZRP0AQAAAAAAABMMAAAAAAAAAAQPQWltIExvY2sgRGVsYXkEBnBjYWxsFQAAAAEmARoAAgETAAEBDwERAAAAAwErAScABAAFAAYABwEpASoBJAEiASUBHCYAAAAAmQ4AAJsOAAAAAAQJAAAA5gAAAOUAgADmAAAA",
    "JwAAAAEAQACoQMAAqYBAARlAgAEbAIAAAwAAAAQVU2V0Q29uc3VtZU1vdXNlV2hlZWwEE0VDb25zdW1lTW91c2VXaGVlbAQWV2hlblNjcm9sbGluZ1Bvc3NpYmxlAgAAAAECAAQAAAAAAAAAAAAAAAAAAAAAAJwOAACeDgAAAAAECQAAAOYA",
    "AADlAIAA5gAAACcAAAABAEAAqEDAAKmAQAEZQIABGwCAAAMAAAAEF1NldFNjcm9sbEJhclZpc2liaWxpdHkEEUVTbGF0ZVZpc2liaWxpdHkECkNvbGxhcHNlZAIAAAABAgAEAAAAAAAAAAAAAAAAAAAAAACfDgAAoQ4AAAAABAgAAADmAAAA",
    "5QCAAOYAAAAnAAAAAQBAAKUAgAAZQIABGwCAAAEAAAAEGVNldEFuaW1hdGVXaGVlbFNjcm9sbGluZwEAAAABAgAAAAAAAAAAAAAAAAAAAAAApQ4AAKgOAAAAAAUOAAAAJgEAACUBgAAmAQAAJwAAAAEAQACjQAAA44AAABlAAAInAAAAAQBA",
    "AKPAAADjgAAAGUAAAhsAgAAEAAAABA5TZXRDb2x1bW5GaWxsEwAAAAAAAAAAAwAAAAAAAPA/EwEAAAAAAAAAAQAAAAEDAAAAAAAAAAAAAAAAAAAAAACqDgAArA4AAAAABAkAAADmAAAA5QCAAOYAAAAnAIAAAQBAAKcAAAEZgIABKwAAABsA",
    "gAABAAAABAlBZGRDaGlsZAMAAAABBAECAQMAAAAAAAAAAAAAAAAAAAAAAK4OAACxDgAAAAAEDgAAAOYAAADlAIAA5gAAACcAAAABAEAAqEDAAKmAQAEZQIABJwAAAAHAQACoAMEAqUBBARlAgAEbAIAABgAAAAQXU2V0SG9yaXpvbnRhbEFs",
    "aWdubWVudAQVRUhvcml6b250YWxBbGlnbm1lbnQEDEhBbGlnbl9GaWxsBBVTZXRWZXJ0aWNhbEFsaWdubWVudAQTRVZlcnRpY2FsQWxpZ25tZW50BAtWQWxpZ25fVG9wAgAAAAEEAAQAAAAAAAAAAAAAAAAAAAAAAMIOAADUDgAAAgAGJwAA",
    "AGYBAABlAYAAZgEAABQAwAATAAGAFEBAABOAAIAqAMCAKsBAgRPAAYAUAMAAEwABgBSAQAATgACAKgBAgSrAwIATAACAKsBAAKgAwQDoQEEBmYAAARSAQQETgAGAqEBBAcAAAABUAMAAEwAAgCVBAAAlAYAAmUCAAVRAQAATQACAFIBAABPA",
    "AICnAIAB48ABACEBAACZQIABGwCAAAgAAAABAQQEYWltBAthbnRpX3NoYWtlAQAEBXR5cGUEHHNldF9kb25nZG9uZ19mZWF0dXJlX2NvbmZpZwQJZnVuY3Rpb24DuB6F61G4nj8HAAAAAQYABAAHAAgBAAEDAAkBAAAAANAOAADSDgAAAAAD",
    "CwAAAKYAAAClAIAApgAAACgAQABnAIAAFEAAABOAAIAnAAABZwAAABlAAAEbAIAAAQAAAAQWX2Rvbmdkb25nX25hdGl2ZV9ncmlkAwAAAAAEAAUABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1w4AANcOAAAAAAQIAAAA5gAAAOUA",
    "gADmAAAAJwAAAGMAAAClAIAAGUCAARsAgAABAAAABApub19yZWNvaWwBAAAAAQcAAAAAAAAAAAAAAAAAAAAAANgOAADYDgAAAAAECAAAAOYAAADlAIAA5gAAACcAAABjAAAApQAAABlAgAEbAIAAAQAAAAQKbm9fcmVjb2lsAQAAAAEHAAAA",
    "AAAAAAAAAAAAAAAAAADaDgAA2g4AAAAABAgAAADmAAAA5QCAAOYAAAAnAAAAYwAAAKUAgAAZQIABGwCAAAEAAAAECWNvbnZlcmdlAQAAAAEHAAAAAAAAAAAAAAAAAAAAAADbDgAA2w4AAAAABAgAAADmAAAA5QCAAOYAAAAnAAAAYwAAAKUA",
    "AAAZQIABGwCAAAEAAAAECWNvbnZlcmdlAQAAAAEHAAAAAAAAAAAAAAAAAAAAAADdDgAA3Q4AAAAABAgAAADmAAAA5QCAAOYAAAAnAAAAYwAAAKUAgAAZQIABGwCAAAEAAAAEBGFpbQEAAAABBwAAAAAAAAAAAAAAAAAAAAAA3g4AAN4OAAAA",
    "AAQIAAAA5gAAAOUAgADmAAAAJwAAAGMAAAClAAAAGUCAARsAgAABAAAABARhaW0BAAAAAQcAAAAAAAAAAAAAAAAAAAAAAOAOAADgDgAAAAAECAAAAOYAAADlAIAA5gAAACcAAABjAAAApQCAABlAgAEbAIAAAQAAAAQLYW50aV9zaGFrZQEA",
    "AAABBwAAAAAAAAAAAAAAAAAAAAAA4Q4AAOEOAAAAAAQIAAAA5gAAAOUAgADmAAAAJwAAAGMAAAClAAAAGUCAARsAgAABAAAABAthbnRpX3NoYWtlAQAAAAEHAAAAAAAAAAAAAAAAAAAAAADrDgAA7g4AAAAABBAAAADmAAAA5QCAAOYAAAAn",
    "AAAAaADAAFdAAAATwACAZwAAAVdAAAATAACAY0AAABmAAAFnAIABgAAAAFlAAAEbAIAAAgAAAAQZY3VzdG9tX2FpX2NvbG9yX2xhc3Rfa2V5BARyZWQEAAAAAAwABwEKAA0AAAAAAAAAAAAAAAAAAAAAAO8OAADvDgAAAAADBwAAAKYAAACl",
    "AIAApgAAACcAAABjAAAAGUAAARsAgAABAAAABAVub25lAQAAAAANAAAAAAAAAAAAAAAAAAAAAADxDgAA9A4AAAAAAw0AAACmAAAApQCAAKYAAAAqQECAJwCAAGiAQAAZgAABVMBAABOAAIAnAAABY0AAABlAAAEbAIAABAAAAAQZY3VzdG9t",
    "X2FpX2NvbG9yX2xhc3Rfa2V5BARyZWQEFGN1c3RvbV9haV9jb2xvcl9rZXkEBW5vbmUDAAAAAAcACwANAAAAAAAAAAAAAAAAAAAAAAD1DgAA+A4AAAAAAw0AAACmAAAApQCAAKYAAAAqQECAJwCAAGiAQAAZgAABVMBAABOAAIAnAAABY0AA",
    "ABlAAAEbAIAABAAAAAQZY3VzdG9tX2FpX2NvbG9yX2xhc3Rfa2V5BAZncmVlbgQUY3VzdG9tX2FpX2NvbG9yX2tleQQFbm9uZQMAAAAABwALAA0AAAAAAAAAAAAAAAAAAAAAAPoOAAD6DgAAAAADBwAAAKYAAAClAIAApgAAACcAAABjAAAA",
    "GUAAARsAgAABAAAABARyZWQBAAAAAA4AAAAAAAAAAAAAAAAAAAAAAPsOAAD7DgAAAAADBwAAAKYAAAClAIAApgAAACcAAABjAAAAGUAAARsAgAABAAAABAZncmVlbgEAAAAADgAAAAAAAAAAAAAAAAAAAAAA/g4AAAAPAAAAAAMMAAAApgAA",
    "AKUAgACmAAAAKABAAGhAwAAZgAABFIBAABOAAIAoQMAAZQCAABlAAAEbAIAAAwAAAAQFdHlwZQQTc2V0X2NoYXJhY3Rlcl94cmF5BAlmdW5jdGlvbgIAAAAABAAHAAAAAAAAAAAAAAAAAAAAAAABDwAAAw8AAAAAAwwAAACmAAAApQCAAKYA",
    "AAAoAEAAaEDAABmAAAEUgEAAE4AAgChAwABlAAAAGUAAARsAgAADAAAABAV0eXBlBBNzZXRfY2hhcmFjdGVyX3hyYXkECWZ1bmN0aW9uAgAAAAAEAAcAAAAAAAAAAAAAAAAAAAAAAAwPAAATDwAAAAAEGQAAAOYAAADlAIAA5gAAACgAQABo",
    "QMAAGYAAAVSAQAATAACAGwCAACjAQAEUAEEAEwABgChAwABjwAAApQCAABlAgAETgAGAKEBBARQAQQATwACAKEDAAGNAAQClAIAAGUCAARsAgAAGAAAABAV0eXBlBBxzZXRfZG9uZ2RvbmdfZmVhdHVyZV9jb25maWcECWZ1bmN0aW9uBARh",
    "aW0BAQQLYW50aV9zaGFrZQMAAAAABAAHAQYAAAAAAAAAAAAAAAAAAAAAABUPAAAbDwAAAAADDgAAAKYAAAClAIAApgAAACgAQABoQMAAGYAAARSAQAATgACAKEDAABlAgAATQACAJwAAARlAgAAbAIAAAwAAAAQFdHlwZQQWc2V0X2Rvbmdk",
    "b25nX2FpbV9wYXJ0BAlmdW5jdGlvbgMAAAAABAAHAQwAAAAAAAAAAAAAAAAAAAAAAB0PAAAlDwAAAAAFEQAAACYBAAAlAYAAJgEAAChAwABoAEAAGYAAARdAAAATAACAI4AAAALAQAAqAACAKABAAGcAAAGjAAEA4QAAAFlAgAEbAIAABQAA",
    "AAQkY3VzdG9tX2Rvbmdkb25nX2FpbV9zbGlkZXJfcmV2aXNpb24ECXRvbnVtYmVyEwAAAAAAAAAAEwEAAAAAAAAAAwrXo3A9Csc/BQAAAAAHAAQACAEMAQ0BAAAAACEPAAAkDwAAAAADDQAAAKYAAAClAIAApgAAACcAAABoAMAAVEAAABMA",
    "AIAbAIAAJwAAARlAgAAnAIABGUCAABsAgAABAAAABCRjdXN0b21fZG9uZ2RvbmdfYWltX3NsaWRlcl9yZXZpc2lvbgQAAAABAAAAAAMABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANg8AADkPAAAAAAMHAAAApgAAAKUAgACmAAAA",
    "KkBAgCcAgAAZQIAAGwCAAAIAAAAEF2N1c3RvbV9haW1fdGFyZ2V0X3BhcnQEBWhlYWQCAAAAAAcBDQAAAAAAAAAAAAAAAAAAAAAAOg8AAD0PAAAAAAMHAAAApgAAAKUAgACmAAAAKkBAgCcAgAAZQIAAGwCAAAIAAAAEF2N1c3RvbV9haW1f",
    "dGFyZ2V0X3BhcnQEBmNoZXN0AgAAAAAHAQ0AAAAAAAAAAAAAAAAAAAAAAD4PAABBDwAAAAADBwAAAKYAAAClAIAApgAAACpAQIAnAIAAGUCAABsAgAACAAAABBdjdXN0b21fYWltX3RhcmdldF9wYXJ0BARsZWcCAAAAAAcBDQAAAAAAAAAA",
    "AAAAAAAAAAAAQg8AAEUPAAAAAAMHAAAApgAAAKUAgACmAAAAKkBAgCcAgAAZQIAAGwCAAAIAAAAEF2N1c3RvbV9haW1fdGFyZ2V0X3BhcnQEBWZyZWUCAAAAAAcBDQAAAAAAAAAAAAAAAAAAAAAAUA8AAFMPAAABAAMHAAAApgAAAKUAgACm",
    "AAAAKgAAgGcAgABZQIAAGwCAAAEAAAAEEWN1c3RvbV9haW1fc3BlZWQCAAAAAAcBDgAAAAAAAAAAAAAAAAAAAAAAXg8AAGEPAAABAAMHAAAApgAAAKUAgACmAAAAKgAAgGcAgABZQIAAGwCAAAEAAAAEEWN1c3RvbV9haW1fcmFuZ2UCAAAA",
    "AAcBDgAAAAAAAAAAAAAAAAAAAAAAbA8AAG8PAAABAAMHAAAApgAAAKUAgACmAAAAKgAAgGcAgABZQIAAGwCAAAEAAAAEFGN1c3RvbV9haW1fZGlzdGFuY2UCAAAAAAcBDgAAAAAAAAAAAAAAAAAAAAAAeg8AAH0PAAABAAMHAAAApgAAAKUA",
    "gACmAAAAKgAAgGcAgABZQIAAGwCAAAEAAAAEFWN1c3RvbV9haW1fbG9ja190aW1lAgAAAAAHAQ4AAAAAAAAAAAAAAAAAAAAAAIAPAAClDwAAAQARggAAACYEAAAlBIAAJgQAAFQAQAATwAGAaEBAAKcAgAAUgIAAE8AAgGiAQACnAAABVICA",
    "ABMAAIAbAIAAZwCAAacAAADAAAAAI8EAAGMBAQClAYAA40EBAFmAgAOnAIAB5wAAAAABAABjgQEAo8EBAOUBAAAjAgIAmYCAA+cAgAEnAQAAQAEAAKNBAgDjgQIAJQIAAGMCAgDZgIADJwGAAWcBAACAAQAA48ECACMCAwBlAgAAowICABmB",
    "gANUAMAAE0AEgGhBQwJpgcMCqMFDAMABgABZQYABZwGAAqcBgADAAYAAIwIEAGMCBACjQgQA5wIAAyODBABjwwQAowMEAOMDBQDZAoACWUEAAFQAQAETQASAaEFDAmmBwwKowUMAwAEAAVlBgAFnAYACpwGAAMABAAEjQgUAYwIEAKNCBADn",
    "AgADI4MEAGMDBACjAwQA44MFANkCgAJZQQAAVADAARNABIBoQUMCaYHDAqjBQwDAAYABWUGAAWcBgAKnAYAAwAGAASPCBQBjAgQAo0IEAOcCAAMjgwQAYwMFAKMDBADjgwUA2QKAAllBAABUAEACE0AEgGhBQwJpgcMCqMFDAMABAAJZQYAB",
    "ZwGAAqcBgADAAQACIwIGAGMCBACjQgQA5wIAAyODBABjAwUAowMEAOODBQDZAoACWUEAAGhBRgKhAQAAWUEAARsAgAAaAAAAAAQWX2Rvbmdkb25nX25hdGl2ZV9ncmlkBB1fZG9uZ2RvbmdfbmF0aXZlX2J1aWxkX3Rva2VuBBNAc3RhcnJt",
    "b2RzICAgICAgICAEClBhZ2VUaXRsZQQNSGVhZGVyNF8zMnB0BAdDb21iYXQEEEZ1bmN0aW9uU2VjdGlvbgQNSGVhZGVyM18yOHB0BAhWaXN1YWxzBA1Db2xvclNlY3Rpb24EDUFpbSBTZXR0aW5ncwQOQWRqdXN0U2VjdGlvbgQGdGFibGUE",
    "B2luc2VydAQZX2Rvbmdkb25nX25hdGl2ZV93aWRnZXRzEwAAAAAAAAAAEwIAAAAAAAAAExgAAAAAAAAAEwoAAAAAAAAAExwAAAAAAAAAEwEAAAAAAAAAEw4AAAAAAAAAEwQAAAAAAAAAEwcAAAAAAAAABAZwY2FsbAcAAAABAAEDAQUAEgAE",
    "ABMAFAEAAAAApA8AAKQPAAAAAAMHAAAApgAAAKUAgACmAAAAJwAAAAEAQAAZQAABGwCAAAEAAAAEHkludmFsaWRhdGVMYXlvdXRBbmRWb2xhdGlsaXR5AQAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACnDwAApw8AAAAAAwcA",
    "AACmAAAApQCAAKYAAAAoAEAAAUBAABlAAAEbAIAAAgAAAAQOX3d0UmVzZXRQYW5lbAQIVmlzaWJsZQEAAAABAAAAAAAAAAAAAAAAAAAAAAAAqA8AAKgPAAAAAAMHAAAApgAAAKUAgACmAAAAKABAAAFAQAAZQAABGwCAAAIAAAAEEl93dFJl",
    "c291cmNlRml4QnRuBApDb2xsYXBzZWQBAAAAAQAAAAAAAAAAAAAAAAAAAAAAAKkPAACpDwAAAAADBwAAAKYAAAClAIAApgAAACcAAAABAEAAGUAAARsAgAABAAAABA5fU2hvd0Nsb3VkQnRuAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAACtDwAAug8AAAIADDEAAADmAgAA5QKAAOYCAACoAEAAwAAAAJmAAAEUQEABEwABgKgAQADAAIAAmYAAAVRAQAETQACApgAAAJsAAAGmAAAA0QAAACOBAABjwQAA3UAGgOmBgQApggEAZwKAABRAAgQTAAWAKAJAAEACgAMZggAB",
    "FEBABBPAA4ApAsEDFEBBBBMAA4CXQAAAEwAAgIAAgAMoQkAAKYJBBEACAACAAgADGUKAAShCQAApgkEEQAKAAIACAAMZQoAB3AD5f5sAAAEbAIAABwAAAAQFdHlwZQQGdGFibGUTAQAAAAAAAAAT//////////8EGV9fZG9uZ2RvbmdfbmF0",
    "aXZlX2RpcmVjdAEBBAdyZW1vdmUCAAAAAAEBGAAAAAAAAAAAAAAAAAAAAAAAvA8AAMkPAAACAAs7AAAApgIAAKUCgACmAgAApwAAAMAAAAAjAQAAmYCAAecAAAAAAQAAY0EAANmAgAEogcAAQAEAARmBAAEUwEACEwABgCiBwABAAYABGYEA",
    "AVTAQAITQACAJQEAABsBAAEnAQABQAEAAYABgAEZgYABF0EAABMAAIAtAQAAZwGAASxBAYIsgcGCFIDBABOAAIBjwQEAV0EAABNAAIBRAQABQsHBAqjBwACpAUIDwAEAAQACgAJnAgACmUEAAqjBwACpAUIDwAGAAQACgAJAAgACmUEAAmpB",
    "gYSogcIA4QEAAJlBAAGlAYAAmwEAARsAgAALAAAABA1fdWlOYXZJRExpc3QECl90YWJUYWJsZQQFdHlwZQQGdGFibGUECGtleVRleHQEGV9fZG9uZ2RvbmdfbmF0aXZlX2RpcmVjdAEBEwEAAAAAAAAABAdpbnNlcnQECnRhYl9pbmRleAQG",
    "cGNhbGwHAAAAAAIAAQEsARkBGAEAAQQBAAAAAMcPAADHDwAAAAAFCQAAACYBAAAlAYAAJgEAACcAAAABAEAApwCAAOcAAAEZQAACGwCAAAEAAAAED1JlZ1N3aXRjaFN1YlVJAwAAAAAGAQABAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAAAyw8AANIPAAACAAkwAAAAJgIAACUCgAAmAgAApwAAAMAAAAAjAQAAmYCAAecAAAAAAQAAY0EAANmAgAEogcAAQAGAABmBAAEXQQAAEwAAgCPBAAACAUECaEHBAIABgAFZgQABFIDBAhOAAIBpAYEBV0EAABMAAIBmAQAAqEHBAMABAAGZ",
    "gQABFIBBAxPAAoCpAQEB5wEAARTAAQMTwAGAqEHBAMABgAKZgQABFIBBAxOAAICpwcECVABCAxMAAIClQQAApQGAAJsBAAEbAIAACQAAAAQNX3VpTmF2SURMaXN0BApfdGFiVGFibGUECXRvbnVtYmVyE///////////EwEAAAAAAAAABAV0",
    "eXBlBAZ0YWJsZQQZX19kb25nZG9uZ19uYXRpdmVfZGlyZWN0AQEDAAAAAAIAAQEYAAAAAAAAAAAAAAAAAAAAAADUDwAA6A8AAAMACi0AAABmAgAAZQKAAGYCAADnAAAAJwGAAEABAADZgIABKAFAAUABgAEZgQABVEBAAhNAAIAlAQAAGwEA",
    "ASiBwAEpAQACaAFAAYABAAJZgQABFMDAAhMAAYBpAUECFECBARNAAIBlAYAAWwEAAW1BAABswYCCoQEAAGyBAYKpAcECaoABAKiBwAGsQQEApwEAAOcBgAAAAgAAmYGAAekBwQJUwAEDEwAAgKVBAAClAYAAmwEAARsAgAAGAAAABAV0eXBl",
    "BAlmdW5jdGlvbgQJd3JhcHBlcnMEBnRhYmxlBAh3cmFwcGVyBAlvcmlnaW5hbAYAAAAAAgENAAEBAAAIAAkBAAAAANoPAADkDwAAAAEJLgAAACYCAAAlAoAAJgIAACcAAABiAAAAGYAAAGkAQACoQMAA5wAAAZmAAAEUgEABEwABgKjAwADn",
    "AAABAAGAAEABAACZQAACqMDAAOEAAACZwAABl0AAABPAAIAoAcEAQAGAAaNBAQAZQYABKEHAAGcBgAIZgQABFIBAAhMAAYAowcAAZwGAAoABgADAAQAAGUEAAicBAAJAAYABo4EBAOnBwQHXQQAAEwAAgONBAQAaAQACGwEAABsAgAAIAAAA",
    "EwEAAAAAAAAABAV0eXBlBAlmdW5jdGlvbgQGcGNhbGwEBmVycm9yEwAAAAAAAAAAEwEAAAAAAAAABAJuBgAAAAAEAAIBAQEFAAUBAgEAAAAA3g8AAOAPAAAAAAcRAAAApgEAAKUBgACmAQAAJwAAAGgAwACnAAAB5wCAASNBAABogcABV0EA",
    "ABMAAIBjwQAAmQAAAlkAAAAaAAAAGwAAABsAgAAEAAAABAlvcmlnaW5hbBMBAAAAAAAAAAQCbhMAAAAAAAAAAAQAAAAAAAADAAQBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7A8AAO4PAAABAAUIAAAAJgEA",
    "ACUBgAAmAQAAZwAAAIAAAADlAAAAWUCAARsAgAAAAAAAAQAAAAEtAAAAAAAAAAAAAAAAAAAAAADwDwAA8g8AAAEABQgAAAAmAQAAJQGAACYBAABnAAAAgAAAAOUAAABZQIABGwCAAAAAAAABAAAAAS0AAAAAAAAAAAAAAAAAAAAAAPIPAAD0",
    "DwAAAQAFCAAAACYBAAAlAYAAJgEAAGcAAACAAAAA5QCAAFlAgAEbAIAAAAAAAAEAAAABLQAAAAAAAAAAAAAAAAAAAAAA9g8AAPgPAAABAAMFAAAApgAAAKUAgACmAAAALEBAgBsAgAACAAAABAlfdGFiVHlwZRMBAAAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAAAAAPoPAAD9DwAAAQAFCQAAACYBAAAlAYAAJgEAAGcAAACAAAAA5QCAAFlAgAEsQECAGwCAAAIAAAAECV90YWJUeXBlEwEAAAAAAAAAAQAAAAEtAAAAAAAAAAAAAAAAAAAAAAD9DwAAABAAAAEABQkAAAAmAQAAJQGAACYB",
    "AABnAAAAgAAAAOUAgABZQIABLEBAgBsAgAACAAAABAlfdGFiVHlwZRMBAAAAAAAAAAEAAAABLQAAAAAAAAAAAAAAAAAAAAAAAhAAAAQQAAABAAUIAAAAJgEAACUBgAAmAQAAZwAAAIAAAADlAIAAWUCAARsAgAAAAAAAAQAAAAEtAAAAAAAA",
    "AAAAAAAAAAAAAAALEAAAFBAAAAIBByIAAACmAQAApQGAAKYBAACnAAAAwAAAAAABgACZgIABlwAAABOAA4CoQMAAwACAAJmAAAGXQAAAEwAAgKOAAACCwEABLIAAgKgAwQDhAAAAmUAAAacAgAHAAAAAmUAAARsAgACnAAACwAAAAJlAAAGo",
    "QMECwAAAAAABgABiAQAAmgAAAJsAAAAbAIAABgAAAAQJX3RhYlR5cGUECXRvbnVtYmVyEwAAAAAAAAAAEwEAAAAAAAAABAZwY2FsbAQJb3JpZ2luYWwGAAAAAS4AAQEEASsBJgEzAQAAAAAOEAAADhAAAAAABQkAAAAmAQAAJQGAACYBAAAn",
    "AAAAAQBAAKcAgADoQMAAGUAAAhsAgAACAAAABBRSZW1vdmVTdWJVSUJ5UGFyZW50BAxfd3RSb290TWFpbgIAAAAAAgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgEAAAKBAAAAEBBh8AAABmAQAAZQGAAGYBAABnAAAAgAAAAOgA",
    "wAApQUAA2YAAAddAAAATAACA44AAAMOAwAFZgIABVwAAABOAAYBowMAAoQAAAFlAAAFnAIABgAAAAFlAAAEbAIAAZwAAAoAAAABZQAABaADBAoAAAADiAAAAWgAAAFsAAAAbAIAABQAAAAQJdG9udW1iZXIECV90YWJUeXBlEwEAAAAAAAAA",
    "BAZwY2FsbAQJb3JpZ2luYWwGAAAAAS4AAQEEASsBJgEzAQAAAAAiEAAAIhAAAAAABQkAAAAmAQAAJQGAACYBAAAnAAAAAQBAAKcAgADoQMAAGUAAAhsAgAACAAAABBRSZW1vdmVTdWJVSUJ5UGFyZW50BAxfd3RSb290TWFpbgIAAAAAAgEA",
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvEAAAMRAAAAEABAcAAADmAAAA5QCAAOYAAABnAAAAgAAAAFlAAAEbAIAAAAAAAAEAAAABJgAAAAAAAAAAAAAAAAAAAAAAMxAAADUQAAABAAQHAAAA5gAAAOUAgADmAAAAZwAAAIAAAABZ",
    "QAABGwCAAAAAAAABAAAAASYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYQAABMEAAAAQAFFAAAACYBAAAlAYAAJgEAABYAAIETAAGAKkBBgirAQYMqQEKEKkBBhSPAAAAqAACAaEDAAKcAAAHAAAAAWUCAAWcAgAGnAAAC4QAAAFlA",
    "gAEbAIAACwAAAAQfY3VzdG9tX2NoYXJhY3Rlcl9jb2xvcl9hdHRlbXB0BAZwY2FsbBMKAAAAAAAAABMAAAAAAAAAAAQlY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9yX3NuYXBzaG90AAQjY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9y",
    "X2N1cnNvchMBAAAAAAAAAAQtY3VzdG9tX2NoYXJhY3Rlcl9zY2FuX2FjdG9yX3NuYXBzaG90X2F0dGVtcHQT//////////8EL2N1c3RvbV9jaGFyYWN0ZXJfc2Nhbl9hY3Rvcl9zbmFwc2hvdF9jaGFyYWN0ZXIHAAAAAQAAAAF8ARkBCwGF",
    "AX4BAAAAAEkQAABLEAAAAAADDgAAAKYAAAClAIAApgAAACcAAABnAIAAFkAAgBOAAIBjQAAAV0AAABNAAIBnAIAAQoDAABlAAAEbAIAAAwAAABNYAgAAAAAAABMAAAAAAAAAABMBAAAAAAAAAAIAAAAABQEAAAAAAAAAAAAAAAAAAAAAAAAA",
    "AAAAAAAAAAAAAABOEAAAXxAAAAAACC0AAADmAQAA5QGAAOYBAAAoAEAAY0AAAKcAgADogEAAKMFAAGMBAQDZgIABI0EBAJkAgAEZgAAAFIBBABNAAIBlAAAAWwAAAWiAQACowEAA48ABAFmAgAFUgMEAEwABgKcAgADAAAAAIwECAEABgACZ",
    "QAACoQAAAOhAQgAowUAAY8EBAIABAAHZQAAC5wCAAAABAABjgQIAgAEAAdmAAAJUwMIBEwAAgCVBAAAlAYAAGwEAARsAgAAMAAAABAdzZWxlY3QTAgAAAAAAAAAEB3Jhd2dldAQDX0cEEkx1YVRpY2tDb250cm9sbGVyBARHZXQABBZfX0FV",
    "VEhPUl9YUkFZX1VJX1RJQ0sED1VucmVnaXN0ZXJUaWNrBAdyYXdzZXQEDVJlZ2lzdGVyVGljawEBBQAAAAAAARQBAAELAXwBAAAAAFMQAABbEAAAAQAGIAAAAGYBAABlAYAAZgEAAGgAQABXQAAAEwAAgGNAAACogMAAwAAAAJmAAAGXQAAA",
    "EwAAgKPAAABCgIAAKkAAgGgAQACnAAABFYCAABMAAIAbAIAAKkBAgGgAQQBXQAAAEwAAgGNAAABCQMEAKkAAgqiAwQDnAIABAAGAAJlAgAEbAIAABwAAAAQjY3VzdG9tX2NoYXJhY3Rlcl94cmF5X3RpY2tfZWxhcHNlZBMAAAAAAAAAAAQJ",
    "dG9udW1iZXID/Knx0k1ikD8EH2N1c3RvbV9jaGFyYWN0ZXJfY29sb3JfYXR0ZW1wdBMBAAAAAAAAAAQGcGNhbGwEAAAAAAIAAAADAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGQQAABoEAAAAAADCwAAAKYAAAClAIAApgAAACgA",
    "QAApQEAAVIBAABOAAIAowMAAZwAAARlAAAEbAIAABAAAAAQdY3VzdG9tX2Rvbmdkb25nX2FwaV9zZXR0aW5ncwQKaW5zdGFsbGVkAQEEBnBjYWxsAwAAAAEAAAABhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
}
S.PayloadBase64 = table.concat(S.PayloadBase64Chunks)

end)(S)
-- END payload_embed.lua

-- BEGIN aim_runtime.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local M = {}
S.AimRuntime = M
M.PROTOTYPES = { native_aim_state = "0.29.71", fire_assisted_debug = "0.29.72" }

local function safe_get(obj, key)
    if obj == nil then return nil end
    local ok, v = pcall(function() return obj[key] end)
    if ok then return v end
end

local function invoke(fn, self, ...)
    if type(fn) ~= "function" then return false, nil end
    local ok, a = pcall(fn, self, ...)
    if ok then return true, a end
    return pcall(fn, ...)
end

local function method(obj, name, ...)
    local fn = safe_get(obj, name)
    return invoke(fn, obj, ...)
end

function M.set_native_aim_assist(state, enabled)
    local saved = state.custom_dongdong_native_aim_state
    if type(saved) ~= "table" then saved = {}; state.custom_dongdong_native_aim_state = saved end
    local import_fn = rawget(_G, "import")
    local get_world = rawget(_G, "GetWorld")
    if type(import_fn) ~= "function" or type(get_world) ~= "function" then return false end
    local ok_class, cls = pcall(import_fn, "ClientBaseSetting")
    local ok_world, world = pcall(get_world)
    if not ok_class or not ok_world or cls == nil or world == nil then return false end
    local getter = safe_get(cls, "Get")
    local ok_get, obj = invoke(getter, cls, world)
    if not ok_get or obj == nil then return false end
    if saved.saved ~= true then
        saved.saved = true
        saved.value = safe_get(obj, "bIsAimAssistOpen") == true
    end
    local desired = enabled == true and true or (saved.value == true)
    local ok_set = pcall(function() obj.bIsAimAssistOpen = desired end)
    local saver = safe_get(obj, "SaveDataConfig")
    if type(saver) == "function" then pcall(saver, obj) end
    if enabled ~= true then saved.saved = false end
    return ok_set
end

local function execute_console(command)
    local lib = rawget(_G, "UKismetSystemLibrary")
    local get_instance = rawget(_G, "GetGameInstance")
    if lib == nil then
        local import_fn = rawget(_G, "import")
        if type(import_fn) == "function" then
            local ok, v = pcall(import_fn, "UKismetSystemLibrary")
            if ok then lib = v end
        end
    end
    if lib == nil or type(get_instance) ~= "function" then return false end
    local ok_gi, gi = pcall(get_instance)
    if not ok_gi or gi == nil then return false end
    local fn = safe_get(lib, "ExecuteConsoleCommand")
    if type(fn) ~= "function" then return false end
    local ok = pcall(fn, gi, command, nil)
    if not ok then ok = pcall(fn, lib, gi, command, nil) end
    return ok
end

function M.set_fire_assisted_aim_debug(delay, enabled)
    assert(type(delay) == "function", "delay function required")
    local command = enabled == true and "weapon.FireAssistedAimingDebugEnable 1" or "weapon.FireAssistedAimingDebugEnable 0"
    local function apply() return execute_console(command) end
    local immediate = apply()
    delay(0.35, apply)
    delay(1.2, apply)
    return immediate
end

return M

end)(S)
-- END aim_runtime.lua

-- BEGIN visual_runtime.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local M = {}
S.VisualRuntime = M
M.PROTOTYPES = { new_weak_mesh_table="0.29.0", restore_mesh_snapshot="0.29.92", restore_mesh_category="0.29.95", reset_scan_state="0.29.96" }

local function safe_get(obj,key)
    if obj==nil then return nil end
    local ok,v=pcall(function() return obj[key] end); if ok then return v end
end
local function call_method(obj,name,...)
    local fn=safe_get(obj,name); if type(fn)~="function" then return false,nil end
    local ok,a=pcall(fn,obj,...); if ok then return true,a end
    return pcall(fn,...)
end

function M.new_weak_mesh_table() return setmetatable({}, {__mode="k"}) end

function M.restore_mesh_snapshot(mesh, snapshot)
    if mesh == nil or type(snapshot) ~= "table" then return end
    if type(snapshot.materials) == "table" then
        for index, material in pairs(snapshot.materials) do
            call_method(mesh, "SetMaterial", index, material == false and false or material)
        end
    end
    call_method(mesh, "SetOverlayMaterial", nil)
    call_method(mesh, "SetRenderCustomDepth", false)
    call_method(mesh, "SetCustomDepthStencilValue", 0)
end

function M.restore_mesh_category(state, category)
    local meshes = state.custom_character_xray_meshes or {}
    for mesh, snapshot in pairs(meshes) do
        if type(snapshot) == "table" and snapshot.category == category then
            M.restore_mesh_snapshot(mesh, snapshot)
            meshes[mesh] = nil
        end
    end
end

function M.reset_scan_state(state)
    state.custom_character_scan_actor_snapshot = nil
    state.custom_character_scan_actor_cursor = 1
    state.custom_character_scan_actor_snapshot_attempt = -1
    state.custom_character_scan_actor_snapshot_character = nil
end

return M

end)(S)
-- END visual_runtime.lua

-- BEGIN visual_scan.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local M = {}
S.VisualScan = M

-- Reconstructed from payload prototypes P0.29.78..98. Names are semantic unless
-- they are literal engine/global names present in bytecode.
M.PROTOTYPES = {
    array_each="0.29.78", add_unique="0.29.79", collect_array="0.29.80",
    is_mesh_component="0.29.81", add_unique_mesh="0.29.82", collect_mesh_value="0.29.83",
    collect_character_meshes="0.29.84", is_ai_actor="0.29.85", actor_class_cache="0.29.86",
    collect_character_actors="0.29.87", make_linear_color="0.29.88", make_name="0.29.89",
    set_vector_parameter="0.29.90", load_xray_material="0.29.91", restore_mesh_snapshot="0.29.92",
    apply_xray_mesh="0.29.93", apply_normal_color="0.29.94", restore_mesh_category="0.29.95",
    reset_scan_state="0.29.96", rescan_character_colors="0.29.97", scan_character_batch="0.29.98",
    install_fashion_refresh_hook="0.29.104", fallback_scan_loop="0.29.106", install_tick="0.29.107",
}

M.COLORS = { red={1,0,0,1}, green={0,1,0,1} }
M.XRAY_MATERIAL_PATHS = {
    red="/Game/MaterialLib/Materials/Character/ArmsEffect/MI_XrayOutLine_03_LQ_Red.MI_XrayOutLine_03_LQ_Red",
    green="/Game/MaterialLib/Materials/Character/ArmsEffect/MI_Simple_XrayOutLine_Scout_Green.MI_Simple_XrayOutLine_Scout_Green",
}
M.COLOR_PARAMETERS = {
    "BaseColor","SkinColor","2UDyeColor","DyeColor","Color","TintColor","BaseColorTint","BaseColorAdd",
    "RootColor","TipColor","HighlightColor","MainColor","PrimaryColor","BodyColor","CharacterColor","ColorTint",
    "EmissiveColor","RimColor","FresnelColor","OutlineColor",
}
M.SNAPSHOT_REFRESH_ATTEMPTS = 4
M.MESH_REFRESH_ATTEMPTS = 2
M.XRAY_RETRY_ATTEMPTS = 2
M.NORMAL_RETRY_ATTEMPTS = 4
M.SCAN_BATCH = 8

local COMPONENT_FIELDS = {
    "CharacterFashionComponent","DFMCharacterAppearanceTPP","DFMCharacterAppearanceFPP","CharacterAppearanceTPP",
    "CharacterAppearanceFPP","AppearanceTPP","AppearanceFPP","CharacterEquipComponent","SOLCharacterEquipComponent",
    "CharacterAvatarComponent",
}
local COMPONENT_GETTERS = {
    "GetCharacterFashionComponent","GetCharacterAppearanceTPP","GetCharacterAppearanceFPP","GetAppearanceTPP",
    "GetAppearanceFPP","GetCharacterEquipComponent",
}
local MESH_FIELDS = {
    "Mesh","SkeletalMesh","CharacterMesh","Mesh3P","TPPMesh","ThirdPersonMesh","MainMesh","CharacterSkeletalMesh",
    "MeshComponent","SkeletalMeshComponent","CharacterMeshComponent","StaticMeshComponent","BodyMesh","TargetMesh",
    "DummyMesh","DFMSkeletalMeshComponent","HeadMesh","FaceMesh","HairMesh","HelmetMesh","UpperBodyMesh",
    "LowerBodyMesh","TorsoMesh","LegMesh","HandsMesh","FootMesh","OutfitMesh","FashionMesh","AvatarMesh",
    "SkinMesh","CapeMesh","BackpackMesh","AccessoryMesh","EquipMesh","PreviewCharacterSKM",
}
local MESH_ARRAY_FIELDS = {
    "Meshes","MeshComponents","SkeletalMeshComponents","StaticMeshComponents","AllMeshComponents",
    "CharacterMeshComponents","BodyMeshComponents","AvatarMeshComponents","FashionMeshComponents","SkinMeshComponents",
    "PartMeshComponents","EquipMeshComponents","LoadedMeshComponents","DynamicMeshComponents","MeshComponentMap","MeshMap",
    "PartMeshes","CharacterMeshes","BodyMeshes","FashionMeshes","AvatarMeshes",
}
local MESH_GETTERS = {
    "GetMesh","GetMesh3P","GetThirdPersonMesh","GetCharacterMesh","GetSkeletalMesh","GetCharacterSkeletalMesh",
    "GetMeshComponent","GetSkeletalMeshComponent","GetCharacterMeshComponent","GetStaticMeshComponent","GetBodyMesh",
    "GetTargetMesh","GetHeadMesh","GetFaceMesh","GetHairMesh","GetUpperBodyMesh","GetLowerBodyMesh","GetOutfitMesh",
    "GetFashionMesh","GetAvatarMesh","GetSkinMesh","GetAllMeshComponents","GetMeshComponents",
    "GetCharacterMeshComponents","GetSkeletalMeshComponents","GetFashionMeshComponents","GetAvatarMeshComponents",
}
local MESH_CLASSES = {
    "DFMSkeletalMeshComponent","SkeletalMeshComponent","USkeletalMeshComponent","SkinnedMeshComponent","USkinnedMeshComponent",
    "PoseableMeshComponent","UPoseableMeshComponent","StaticMeshComponent","UStaticMeshComponent","GPCharacterMeshComponent",
    "DFMCharacterMeshComponent","CharacterMeshComponent","MeshComponent","UMeshComponent",
}
local CHILD_FIELDS = {"ChildActor","AttachedActors","Children","ChildActors"}
local ACTOR_CLASSES = {"DFMCharacter","DFMPlayerCharacter","GPCharacter","SOLCharacter","Character","Pawn"}
local AI_NAME_MARKERS = {
    "rangetarget","range_target","targetcharacter","trainingtarget","practice","dummy","dfmaicharacter",
    "dfmcharacter_ai","_ai_","aicharacter","characterai","bot","npc","soldier","minion",
}
local PLAYER_NAME_MARKERS = {"bp_dfmcharacter_c","nc_bp_dfmcharacter_c","dfmplayercharacter","playercharacter"}
local AI_FIELDS = {"bIsAI","IsAI","bAI","bIsBot","IsBot","bIsNPC","IsNPC"}
local AI_METHODS = {"IsAI","IsBot","IsAICharacter","IsNPC"}
local actor_class_cache
local name_cache = {}

local function safe_get(obj,key)
    if obj==nil then return nil end
    local ok,v=pcall(function() return obj[key] end)
    if ok then return v end
end
local function method(obj,name,...)
    local fn=safe_get(obj,name)
    if type(fn)~="function" then return false,nil,nil end
    local ok,a,b=pcall(fn,obj,...)
    if ok then return true,a,b end
    ok,a,b=pcall(fn,...)
    if ok then return true,a,b end
    return false,nil,nil
end
local function is_valid(obj)
    if obj==nil then return false end
    local fn=rawget(_G,"isvalid")
    if type(fn)~="function" then return true end
    local ok,v=pcall(fn,obj)
    return ok and v==true
end
local function object_name(obj)
    if obj==nil then return "" end
    for _,n in ipairs({"GetFullName","GetName"}) do
        local ok,v=method(obj,n)
        if ok and v~=nil then return tostring(v) end
    end
    return tostring(obj)
end
local function import_class(name)
    local direct=rawget(_G,name)
    if direct~=nil then return direct end
    local fn=rawget(_G,"import")
    if type(fn)=="function" then local ok,v=pcall(fn,name); if ok then return v end end
end

function M.array_each(value, callback, limit)
    if value==nil or type(callback)~="function" then return false end
    local any=false
    if type(value)=="table" then
        local count=0
        for _,v in pairs(value) do
            count=count+1; if limit and count>limit then break end
            if v~=nil then any=true; callback(v,count) end
        end
        return any
    end
    local ok,n=method(value,"Num")
    if not ok or type(n)~="number" then
        local h=rawget(_G,"ULuaArrayHelper")
        local fn=safe_get(h,"Num")
        if type(fn)=="function" then
            local a,b=pcall(fn,value); if a then n=b else a,b=pcall(fn,h,value); if a then n=b end end
        end
    end
    if type(n)~="number" or n<=0 then return false end
    local stop=limit and math.min(n,tonumber(limit) or n) or n
    for i=0,stop-1 do
        local gok,v=method(value,"Get",i)
        if gok and v~=nil then any=true; callback(v,i+1) end
    end
    return any
end

function M.add_unique(list,seen,value)
    if value==nil then return end
    local t=type(value); if t~="userdata" and t~="table" then return end
    if seen[value] then return end
    seen[value]=true; list[#list+1]=value
end

function M.is_mesh_component(value)
    if not is_valid(value) then return false end
    local ok=method(value,"GetNumMaterials")
    if not ok then return false end
    local setm=safe_get(value,"SetMaterial"); if type(setm)~="function" then return false end
    return type(safe_get(value,"SetOverlayMaterial"))=="function"
end

function M.collect_mesh_value(list,seen,value)
    if value==nil then return end
    if M.is_mesh_component(value) then M.add_unique(list,seen,value); return end
    M.array_each(value,function(v) if M.is_mesh_component(v) then M.add_unique(list,seen,v) end end,256)
    if type(value)=="table" then
        local count=0
        pcall(function() for _,v in pairs(value) do count=count+1; if count>256 then break end; if M.is_mesh_component(v) then M.add_unique(list,seen,v) end end end)
    end
end

local function enqueue(queue,seen,obj)
    if obj==nil then return end
    local t=type(obj); if t~="table" and t~="userdata" then return end
    if seen[obj] then return end
    seen[obj]=true; queue[#queue+1]=obj
end
local function enqueue_value(queue,seen,value)
    if value==nil then return end
    if M.array_each(value,function(v) enqueue(queue,seen,v) end,64) then return end
    if type(value)=="table" then
        local count=0; pcall(function() for _,v in pairs(value) do count=count+1; if count>64 then break end; enqueue(queue,seen,v) end end)
    else enqueue(queue,seen,value) end
end

function M.collect_character_meshes(actor)
    local meshes,mesh_seen,queue,queue_seen={},{},{},{}
    enqueue(queue,queue_seen,actor)
    for _,field in ipairs(COMPONENT_FIELDS) do enqueue(queue,queue_seen,safe_get(actor,field)) end
    for _,getter in ipairs(COMPONENT_GETTERS) do local ok,v=method(actor,getter); if ok then enqueue(queue,queue_seen,v) end end
    local cursor=1
    while cursor<=#queue and cursor<=32 do
        local obj=queue[cursor]; cursor=cursor+1
        M.add_unique(meshes,mesh_seen,obj)
        for _,field in ipairs(MESH_FIELDS) do M.add_unique(meshes,mesh_seen,safe_get(obj,field)) end
        for _,field in ipairs(MESH_ARRAY_FIELDS) do M.collect_mesh_value(meshes,mesh_seen,safe_get(obj,field)) end
        for _,getter in ipairs(MESH_GETTERS) do local ok,v=method(obj,getter); if ok then M.collect_mesh_value(meshes,mesh_seen,v) end end
        for _,class_name in ipairs(MESH_CLASSES) do
            local cls=import_class(class_name) or class_name
            local ok,v=method(obj,"GetComponentByClass",cls); if ok then M.add_unique(meshes,mesh_seen,v) end
            local ok2,arr=method(obj,"GetComponentsByClass",cls); if ok2 then M.collect_mesh_value(meshes,mesh_seen,arr) end
        end
        local attached={}; local ok,a=method(obj,"GetAttachedActors",attached,true,true); if ok then enqueue_value(queue,queue_seen,a or attached) end
        local children={}; local ok2,c=method(obj,"GetAllChildActors",children,true); if ok2 then enqueue_value(queue,queue_seen,c or children) end
        for _,field in ipairs(CHILD_FIELDS) do enqueue_value(queue,queue_seen,safe_get(obj,field)) end
    end
    local filtered={}; for _,m in ipairs(meshes) do if M.is_mesh_component(m) then filtered[#filtered+1]=m end end
    return filtered
end

function M.is_ai_actor(actor)
    local n=string.lower(object_name(actor))
    for _,m in ipairs(AI_NAME_MARKERS) do if string.find(n,m,1,true) then return true end end
    for _,m in ipairs(PLAYER_NAME_MARKERS) do if string.find(n,m,1,true) then return false end end
    for _,f in ipairs(AI_FIELDS) do if safe_get(actor,f)==true then return true end end
    for _,fn in ipairs(AI_METHODS) do local ok,v=method(actor,fn); if ok and v==true then return true end end
    return false
end

function M.get_actor_classes()
    if actor_class_cache then return actor_class_cache end
    actor_class_cache={}
    for _,name in ipairs(ACTOR_CLASSES) do
        local cls=import_class(name); local vals={}
        local seen={}
        local function add(v) if v~=nil and not seen[v] then seen[v]=true; vals[#vals+1]=v end end
        add(cls)
        if cls~=nil then for _,fn in ipairs({"StaticClass","GetClass"}) do local ok,v=method(cls,fn); if ok then add(v) end end end
        actor_class_cache[#actor_class_cache+1]={name=name,values=vals}
    end
    return actor_class_cache
end

function M.collect_character_actors(local_character, game_flow)
    local out,seen={},{}
    local world
    local gw=rawget(_G,"GetWorld"); if type(gw)=="function" then local ok,v=pcall(gw); if ok then world=v end end
    if world==nil then local ok,v=method(game_flow,"GetWorld"); if ok then world=v end end
    if world==nil then local ok,v=method(local_character,"GetWorld"); if ok then world=v end end
    local gps=import_class("UGameplayStatics")
    if world==nil or gps==nil then return out end
    local function add(actor,class_name)
        if actor==nil or actor==local_character or seen[actor] then return end
        if class_name=="Pawn" then
            local low=string.lower(object_name(actor))
            if not (string.find(low,"character",1,true) or string.find(low,"rangetarget",1,true) or string.find(low,"operator",1,true) or string.find(low,"hero",1,true)) then
                local mesh=safe_get(actor,"Mesh"); if not M.is_mesh_component(mesh) then local ok,v=method(actor,"GetMesh"); if not(ok and M.is_mesh_component(v)) then return end end
            end
        end
        seen[actor]=true; out[#out+1]={object=actor}
    end
    for _,entry in ipairs(M.get_actor_classes()) do
        for _,cls in ipairs(entry.values) do
            local arr={}
            local ok,result=method(gps,"GetAllActorsOfClass",world,cls,arr)
            if ok then M.array_each(result or arr,function(actor) add(actor,entry.name) end) end
        end
    end
    return out
end

function M.make_linear_color(key)
    local v=M.COLORS[key] or M.COLORS.red
    for _,name in ipairs({"FLinearColor","LinearColor","Vector4"}) do
        local fn=rawget(_G,name)
        if type(fn)=="function" then local ok,c=pcall(fn,v[1],v[2],v[3],v[4]); if ok and c~=nil then return c end end
    end
    return {R=v[1],G=v[2],B=v[3],A=v[4]}
end
function M.make_name(value)
    if name_cache[value]~=nil then return name_cache[value] end
    for _,name in ipairs({"FName","Name","MakeLiteralName","StringToName","Conv_StringToName"}) do
        local fn=rawget(_G,name)
        if type(fn)=="function" then local ok,v=pcall(fn,value); if ok and v~=nil then name_cache[value]=v; return v end end
    end
    name_cache[value]=value; return value
end
function M.set_vector_parameter(material,param,color)
    local ok=method(material,"SetVectorParameterValue",param,color); if ok then return true end
    ok=method(material,"SetVectorParameterValue",M.make_name(param),color); return ok
end
function M.load_xray_material(state,key)
    key=key=="green" and "green" or "red"
    state.custom_character_xray_materials=type(state.custom_character_xray_materials)=="table" and state.custom_character_xray_materials or {}
    local cached=state.custom_character_xray_materials[key]; if cached~=nil and is_valid(cached) then return cached end
    local path=M.XRAY_MATERIAL_PATHS[key]
    local slua=rawget(_G,"slua"); local fn=safe_get(slua,"dontCallLoadObject")
    if type(fn)=="function" then
        local ok,v=pcall(fn,path); if not ok then ok,v=pcall(fn,slua,path) end
        if ok and v~=nil then state.custom_character_xray_materials[key]=v; return v end
    end
    for _,name in ipairs({"LoadObject","StaticLoadObject","FindObject","LoadAsset"}) do
        local f=rawget(_G,name); if type(f)=="function" then local ok,v=pcall(f,path); if ok and v~=nil then state.custom_character_xray_materials[key]=v; return v end end
    end
    local imp=rawget(_G,"import"); if type(imp)=="function" then local ok,v=pcall(imp,path); if ok and v~=nil then state.custom_character_xray_materials[key]=v; return v end end
end

function M.restore_mesh_snapshot(mesh,snapshot)
    if mesh==nil or type(snapshot)~="table" then return end
    if type(snapshot.materials)=="table" then for i,m in pairs(snapshot.materials) do method(mesh,"SetMaterial",i,m) end end
    method(mesh,"SetOverlayMaterial",nil); method(mesh,"SetRenderCustomDepth",false); method(mesh,"SetCustomDepthStencilValue",0)
end

function M.apply_xray_mesh(state,mesh,attempt,color_key,category)
    if not is_valid(mesh) or state.custom_character_xray_enabled~=true then return end
    color_key=color_key=="green" and "green" or "red"
    state.custom_character_xray_meshes=state.custom_character_xray_meshes or setmetatable({}, {__mode="k"})
    local snap=state.custom_character_xray_meshes[mesh]
    if type(snap)~="table" then snap={materials={},saved={},last_attempt=-M.XRAY_RETRY_ATTEMPTS}; state.custom_character_xray_meshes[mesh]=snap end
    local mat=M.load_xray_material(state,color_key); if mat==nil then return end
    local a=tonumber(attempt) or 0; local last=tonumber(snap.last_attempt) or 0
    local retry=(a-last)>=M.XRAY_RETRY_ATTEMPTS
    local ok,n=method(mesh,"GetNumMaterials"); n=ok and tonumber(n) or 0; if n<=0 then n=1 end
    local unchanged=snap.color==color_key and snap.material_count==n
    if unchanged and not retry then
        method(mesh,"SetOverlayMaterial",mat); method(mesh,"SetRenderCustomDepth",true); method(mesh,"SetCustomDepthStencilValue",20); snap.category=category; return
    end
    method(mesh,"SetOverlayMaterial",mat); method(mesh,"SetRenderCustomDepth",true); method(mesh,"SetCustomDepthStencilValue",20)
    snap.material_count=n
    for i=0,n-1 do
        if snap.saved[i]~=true then local gok,old=method(mesh,"GetMaterial",i); if gok then snap.saved[i]=true; snap.materials[i]=old end end
        local gok,current=method(mesh,"GetMaterial",i); if gok and current~=mat then method(mesh,"SetMaterial",i,mat) end
    end
    snap.color=color_key; snap.category=category; snap.last_attempt=a
end

function M.apply_normal_color(state,mesh,attempt,color_key)
    if not is_valid(mesh) or state.custom_character_xray_enabled==true then return end
    color_key=color_key=="green" and "green" or "red"
    state.custom_character_normal_seen=state.custom_character_normal_seen or setmetatable({}, {__mode="k"})
    local rec=state.custom_character_normal_seen[mesh] or {}; state.custom_character_normal_seen[mesh]=rec
    local a=tonumber(attempt) or 0; local ok,n=method(mesh,"GetNumMaterials"); n=ok and tonumber(n) or 0
    local last=tonumber(rec.last_attempt); if last==nil then last=-M.NORMAL_RETRY_ATTEMPTS end
    if rec.key==color_key and rec.material_count==n and (a-last)<M.NORMAL_RETRY_ATTEMPTS then return end
    rec.key=color_key; rec.last_attempt=a; rec.material_count=n
    for i=0,n-1 do
        local made=method(mesh,"CreateAndSetMaterialInstanceDynamic",i)
        if not made then method(mesh,"CreateDynamicMaterialInstance",i) end
    end
    local c=M.make_linear_color(color_key)
    if type(safe_get(mesh,"SetVectorParameterValueOnMaterials"))=="function" then
        for _,p in ipairs(M.COLOR_PARAMETERS) do method(mesh,"SetVectorParameterValueOnMaterials",M.make_name(p),c) end
    end
    for i=0,n-1 do local gok,mat=method(mesh,"GetMaterial",i); if gok and mat~=nil then for _,p in ipairs(M.COLOR_PARAMETERS) do M.set_vector_parameter(mat,p,c) end end end
    method(mesh,"SetOverlayMaterial",nil); method(mesh,"SetRenderCustomDepth",false); method(mesh,"SetCustomDepthStencilValue",0)
end

function M.restore_mesh_category(state,category)
    local meshes=state.custom_character_xray_meshes or {}
    for mesh,snap in pairs(meshes) do if type(snap)=="table" and snap.category==category then M.restore_mesh_snapshot(mesh,snap); meshes[mesh]=nil end end
end
function M.reset_scan_state(state)
    state.custom_character_scan_actor_snapshot=nil; state.custom_character_scan_actor_cursor=1
    state.custom_character_scan_actor_snapshot_attempt=-1; state.custom_character_scan_actor_snapshot_character=nil
end

function M.scan_character_batch(state,attempt)
    attempt=tonumber(attempt) or 0
    local facade=rawget(_G,"Facade"); local gfm=safe_get(facade,"GameFlowManager")
    local ok,character=method(gfm,"GetCharacter"); if not ok or character==nil then return end
    local list=state.custom_character_scan_actor_snapshot; local cursor=tonumber(state.custom_character_scan_actor_cursor) or 1
    local snap_attempt=tonumber(state.custom_character_scan_actor_snapshot_attempt) or -1
    local snap_character=state.custom_character_scan_actor_snapshot_character
    local count=type(list)=="table" and #list or 0
    if type(list)~="table" or snap_character~=character or count<cursor or (attempt-snap_attempt)>=M.SNAPSHOT_REFRESH_ATTEMPTS then
        list=M.collect_character_actors(character,gfm); cursor=1; snap_attempt=attempt
        state.custom_character_scan_actor_snapshot=list; state.custom_character_scan_actor_snapshot_attempt=attempt
        state.custom_character_scan_actor_snapshot_character=character
    end
    local stop=math.min(#list,cursor+M.SCAN_BATCH-1)
    for i=cursor,stop do
        local entry=list[i]; local actor=type(entry)=="table" and entry.object or nil
        if is_valid(actor) then
            if entry.is_local_proxy==nil then entry.is_local_proxy=string.find(string.lower(object_name(actor)),"selfproxy",1,true)~=nil end
            if not entry.is_local_proxy then
                if entry.is_ai==nil then entry.is_ai=M.is_ai_actor(actor) end
                if not (entry.is_ai and state.custom_ai_color_enabled~=true) then
                    local category=entry.is_ai and "ai" or "real"
                    local key=entry.is_ai and state.custom_ai_color_key or state.custom_real_color_key
                    key=key=="green" and "green" or "red"
                    local mr=tonumber(entry.mesh_refresh_attempt) or -1
                    if type(entry.meshes)~="table" or (attempt-mr)>=M.MESH_REFRESH_ATTEMPTS then entry.meshes=M.collect_character_meshes(actor); entry.mesh_refresh_attempt=attempt end
                    for _,mesh in ipairs(entry.meshes or {}) do
                        if state.custom_character_xray_enabled==true then M.apply_xray_mesh(state,mesh,attempt,key,category)
                        else M.apply_normal_color(state,mesh,attempt,key) end
                    end
                end
            end
        end
    end
    state.custom_character_scan_actor_cursor=stop+1
end

function M.rescan_character_colors(state,delay)
    state.custom_character_color_rescan_revision=(tonumber(state.custom_character_color_rescan_revision) or 0)+1
    local revision=state.custom_character_color_rescan_revision
    state.custom_character_normal_seen=setmetatable({}, {__mode="k"}); M.reset_scan_state(state)
    for _,seconds in ipairs({0.0,0.08,0.24,0.6,1.2}) do
        delay(seconds,function()
            if revision~=state.custom_character_color_rescan_revision then return end
            state.custom_character_scan_actor_snapshot=nil; state.custom_character_scan_actor_cursor=1
            pcall(M.scan_character_batch,state,state.custom_character_color_attempt or 0)
        end)
    end
end


function M.install_fashion_refresh_hook(state, delay)
    local old=state.custom_character_fashion_refresh_hook
    if type(old)=="table" and old.delegate~=nil and old.callback~=nil then
        method(old.delegate,"Remove",old.callback,old.owner)
        method(old.delegate,"Remove",old.callback)
    end
    local cls=import_class("DFMCharacterItemFashionManager")
    local instance
    if cls~=nil then local ok,v=method(cls,"Get"); if ok then instance=v end end
    if instance==nil then return false end
    local delegate=safe_get(instance,"OnSetMatTaskComplete")
    if delegate==nil then return false end
    local owner={}
    owner.OnRefresh=function() M.rescan_character_colors(state,delay) end
    local ok,handle=method(delegate,"Add",owner.OnRefresh,owner)
    if not ok then ok,handle=method(delegate,"Add",owner.OnRefresh) end
    if not ok then return false end
    state.custom_character_fashion_refresh_hook={delegate=delegate,callback=owner.OnRefresh,owner=owner,handle=handle}
    return true
end

function M.fallback_scan_loop(state, delay, attempt)
    attempt=tonumber(attempt) or 0
    if attempt>=10 then
        M.reset_scan_state(state)
        attempt=0
    end
    state.custom_character_color_attempt=attempt
    pcall(M.scan_character_batch,state,attempt)
    delay(0.25,function()
        local next_attempt = attempt>=600 and 0 or attempt+1
        M.fallback_scan_loop(state,delay,next_attempt)
    end)
end

function M.install_tick(state)
    local controller_class=rawget(_G,"LuaTickController")
    local ok,controller=method(controller_class,"Get")
    if not ok or controller==nil then return false end
    local old=rawget(_G,"__AUTHOR_XRAY_UI_TICK")
    if old~=nil then method(controller,"UnregisterTick",old) end
    local callback=function(delta)
        local elapsed=state.custom_character_xray_tick_elapsed or 0
        elapsed=elapsed+(tonumber(delta) or 0.016)
        state.custom_character_xray_tick_elapsed=elapsed
        if elapsed<0.25 then return end
        state.custom_character_xray_tick_elapsed=0
        local attempt=(state.custom_character_color_attempt or 0)+1
        state.custom_character_color_attempt=attempt
        pcall(M.scan_character_batch,state,attempt)
    end
    rawset(_G,"__AUTHOR_XRAY_UI_TICK",callback)
    local registered=method(controller,"RegisterTick",callback)
    return registered==true
end

function M.get_catalog() return {prototypes=M.PROTOTYPES} end
return M

end)(S)
-- END visual_scan.lua

-- BEGIN mutation_runtime.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

-- Phase D3 reconstruction of the data-table mutation/snapshot layer used by
-- P0.29.17 / P0.29.60 / P0.29.67 / P0.29.68 and the no_recoil/converge
-- branches beneath them. Names below are semantic reconstruction names unless
-- an exact global/field string is noted.
local M = {}
S.MutationRuntime = M

M.PROTOTYPES = {
    normalize_identifier = "0.29.10",
    get_table_manager = "0.29.11",
    call_with_optional_self = "0.29.12",
    get_data_table = "0.29.13",
    ensure_feature_snapshot = "0.29.14",
    snapshot_set = "0.29.15",
    clear_feature_snapshot = "0.29.16",
    restore_feature_snapshot = "0.29.17",
    table_extend = "0.29.18",
    get_extended_field = "0.29.19",
    iterate_table = "0.29.20",
    zero_scalar_field = "0.29.21",
    zero_recursive = "0.29.22",
    patch_random_range = "0.29.23",
    patch_random_collection = "0.29.24",
    patch_recoil_group = "0.29.25",
    apply_no_recoil_row = "0.29.26",
    converge_recursive = "0.29.29",
    canonical_bone_name = "0.29.44",
    make_name = "0.29.46",
    array_len = "0.29.48",
    array_get = "0.29.49",
    ensure_bone_name_pool = "0.29.50",
    ensure_bone_array_snapshots = "0.29.51",
    binding_key = "0.29.52",
    add_binding = "0.29.53",
    snapshot_bone_array = "0.29.54",
    resolve_bone_value = "0.29.55",
    array_set_verified = "0.29.56",
    array_set_raw = "0.29.57",
    restore_binding = "0.29.58",
    restore_record_bindings = "0.29.59",
    restore_bone_array_snapshots = "0.29.60",
    apply_table = "0.29.67",
    apply_feature = "0.29.68",
}

M.FEATURE_TABLES = {
    no_recoil = {
        "WeaponBase/WeaponRecoilTable",
        "weaponBase/weaponrecoiltable",
        "WeaponRecoilTable",
        "/Game/DataTables/WeaponBase/WeaponRecoilTable",
    },
    converge = {
        "WeaponBase/WeaponSpreadTable",
        "weaponBase/weaponspreadtable",
        "WeaponSpreadTable",
        "/Game/DataTables/WeaponBase/WeaponSpreadTable",
        "WeaponBase/WeaponMainAttributeTable",
        "weaponBase/weaponmainattributetable",
        "WeaponMainAttributeTable",
    },
    aim = {
        "WeaponBase/WeaponAimAssistorTable",
        "weaponBase/weaponaimassistortable",
        "WeaponAimAssistorTable",
        "/Game/DataTables/WeaponBase/WeaponAimAssistorTable",
        "WeaponBase/WeaponAimAssistorTableForGamepad",
        "weaponBase/weaponaimassistortableforgamepad",
        "WeaponAimAssistorTableForGamepad",
        "/Game/DataTables/WeaponBase/WeaponAimAssistorTableForGamepad",
        "WeaponBase/WeaponAssistedAimingTable",
        "weaponBase/weaponassistedaimingtable",
        "WeaponAssistedAimingTable",
        "/Game/DataTables/WeaponBase/WeaponAssistedAimingTable",
        "WeaponBase/WeaponAssistedAimingGroupTable",
        "weaponBase/weaponassistedaiminggrouptable",
        "WeaponAssistedAimingGroupTable",
        "/Game/DataTables/WeaponBase/WeaponAssistedAimingGroupTable",
        "WeaponBase/WeaponBulletTable",
        "weaponBase/weaponbullettable",
        "WeaponBulletTable",
        "/Game/DataTables/WeaponBase/WeaponBulletTable",
    },
    anti_shake = {
        "WeaponBase/WeaponRecoilTable",
        "weaponBase/weaponrecoiltable",
        "WeaponRecoilTable",
        "/Game/DataTables/WeaponBase/WeaponRecoilTable",
    },
}


M.CONVERGE_FIELDS = {
    "bLimitSpreadRecoverSpeed", "DistributionInSpreadFunc", "DistributionInSpreadType",
    "ExtraSpread", "FireSpreadExtraRecoverCurve", "FireSpreadFactor", "FireSpreadItems",
    "FireSpreadRecoverSpeed", "LuaDisplaySpreadFactor", "LuaDisplaySpreadUIFactor",
    "Spread", "SpreadId", "SpreadMax", "SpreadMaxFinal", "SpreadRecoverSpeed",
    "EnableSpringGunKick", "RecoilShakePitch", "RecoilShakePitchWithCurve",
    "RecoilShakeYaw", "RecoilShakeYawWithCurve", "SideAimingRecoilShakeFactor",
    "SpringGunKick", "WeaponDataSpringGunKick", "WeaponRecoilShake",
    "WeaponRecoilShakeElementConfig", "WeaponRecoilShakeManualCurveConfigs",
    "WeaponRecoilShakeWithCurve", "bTakeEffect", "ZoomingInConfig", "ActiveTrackingConfig",
    "CrosshairDampingConfig", "CrosshairFollowingConfig", "ShootingConfig", "AngleThreshold",
    "ConeAngleBase", "ConeAnglePower", "ConeHeightBase", "ConeHeightPower",
    "ConeFilterActorsMaxNum", "CdTime", "DeltaTime", "EffectiveFOVRange", "InRangeA",
    "InRangeB", "IntervalTime", "LockonTime", "Outer2InnerRangeForRayChecker", "OutRangeA",
    "OutRangeB", "PitchFactor", "PitchFactorAds", "PitchFactorHip", "PitchFactorLockonAds",
    "PitchFactorLockonHip", "PitchRateAds", "PitchRateHip", "PlayerInputAwayTargetAngle",
    "PlayerInputAwayTargetValue", "PlayerInputRecordTime", "RangeScale", "YawFactor",
    "YawFactorAds", "YawFactorHip", "YawFactorLockonAds", "YawFactorLockonHip",
    "YawRateAds", "YawRateHip", "ConeFilterBones", "ConeFilterBonesOfAI", "EnableDistanceMin",
    "EnableDistanceMax", "AssistedBoxMinRadius", "AssistedBoxMaxRadius",
    "AssistedBoxVerticalScale", "PauseTimeAfterFire", "HorizontalRecoilSpeed",
    "VerticalRecoilSpeed", "RecoilSpeedTouchParam", "RecoilReduceActivationTime",
    "EnableDistanceMinForRotateSticky", "EnableDistanceMaxForRotateSticky",
    "AssistedBoxMinRadiusForRotateSticky", "AssistedBoxMaxRadiusForRotateSticky",
    "AssistedBoxVerticalScaleForRotateSticky", "StickyParam", "MagneticCDSeconds",
    "MagneticEnableFocusSeconds", "EnableDistanceMinForMagneticSticky",
    "EnableDistanceMaxForMagneticSticky", "AssistedBoxMinRadiusForMagneticSticky",
    "AssistedBoxMaxRadiusForMagneticSticky", "AssistedBoxVerticalScaleForMagneticSticky",
    "HorizontalRecoilSpeedForZoomIn", "VerticalRecoilSpeedForZoomIn", "RecoilSpeedDistanceCurve",
    "Radius", "bPreventMissEnable", "PreventMissAddBulletRadiusDelta", "PreventMissNumber",
    "PreventMissTime", "AimingSingleId", "AimingAutoId", "AimingBurstId", "AimingSingleIdPVE",
    "AimingAutoIdPVE", "AimingBurstIdPVE", "Head", "Neck", "Spine2", "Hips", "LeftLeg",
    "RightLeg", "X", "Y",
}

local function safe_get(obj, key)
    if obj == nil then return nil end
    local ok, value = pcall(function() return obj[key] end)
    if ok then return value end
    return nil
end
M.safe_get = safe_get

local function call_optional_self(fn, self, ...)
    if type(fn) ~= "function" then return false, nil end
    local ok, a, b = pcall(fn, self, ...)
    if ok then return true, a, b end
    ok, a, b = pcall(fn, ...)
    if ok then return true, a, b end
    return false, nil
end
M.call_optional_self = call_optional_self

function M.normalize_identifier(value)
    return string.lower(tostring(value or "")):gsub("[^%w]", "")
end

function M.get_table_manager()
    local facade = rawget(_G, "Facade")
    local manager = safe_get(facade, "TableManager")
    if manager ~= nil then return manager end
    return rawget(_G, "TableManager")
end

function M.get_data_table(name)
    local manager = M.get_table_manager()
    local fn = safe_get(manager, "GetTable")
    local ok, value = call_optional_self(fn, manager, name)
    if ok then return value end
    return nil
end

function M.table_extend(value)
    if type(value) ~= "userdata" then return value end
    local fn = safe_get(value, "TableExtend")
    if type(fn) ~= "function" then return value end
    local ok, extended = pcall(fn, value)
    if not ok then ok, extended = pcall(fn) end
    if ok and type(extended) == "table" then return extended end
    return value
end

function M.get_extended_field(owner, key)
    if owner == nil then return nil end
    local value = safe_get(owner, key)
    if type(value) == "userdata" then
        local extended = M.table_extend(value)
        if type(extended) == "table" then
            if type(owner) == "table" then pcall(function() owner[key] = extended end) end
            value = extended
        end
    elseif type(owner) == "table" then
        local again = safe_get(owner, key)
        if type(again) == "table" then value = again end
    end
    return value
end

function M.iterate_table(value, callback)
    value = M.table_extend(value)
    if type(value) ~= "table" or type(callback) ~= "function" then return false end
    return pcall(function()
        for key, item in pairs(value) do callback(value, key, item) end
    end)
end

function M.ensure_feature_snapshot(state, feature)
    local snapshots = state.custom_dongdong_feature_snapshots
    if type(snapshots) ~= "table" then
        snapshots = {}
        state.custom_dongdong_feature_snapshots = snapshots
    end
    local snapshot = snapshots[feature]
    if type(snapshot) ~= "table" then
        snapshot = { records = {}, seen = {} }
        snapshots[feature] = snapshot
    end
    return snapshot
end

function M.snapshot_set(state, feature, object, key, value)
    if object == nil or key == nil then return false end
    local previous = safe_get(object, key)
    if previous == value then return true end
    local snapshot = M.ensure_feature_snapshot(state, feature)
    local identity = tostring(object) .. "\0" .. tostring(key)
    if snapshot.seen[identity] ~= true then
        snapshot.seen[identity] = true
        snapshot.records[#snapshot.records + 1] = { object = object, key = key, value = previous }
    end
    return pcall(function() object[key] = value end)
end

function M.clear_feature_snapshot(state, feature)
    local snapshots = state.custom_dongdong_feature_snapshots
    if type(snapshots) == "table" then snapshots[feature] = nil end
end

function M.restore_feature_snapshot(state, feature)
    local snapshots = state.custom_dongdong_feature_snapshots
    if type(snapshots) ~= "table" then return false end
    local snapshot = snapshots[feature]
    if type(snapshot) ~= "table" or type(snapshot.records) ~= "table" then
        snapshots[feature] = nil
        return false
    end
    local restored = false
    for index = #snapshot.records, 1, -1 do
        local record = snapshot.records[index]
        if type(record) == "table" and record.object ~= nil and record.key ~= nil then
            if pcall(function() record.object[record.key] = record.value end) then restored = true end
        end
    end
    snapshots[feature] = nil
    return restored
end

function M.zero_scalar_field(state, feature, owner, key)
    local value = M.get_extended_field(owner, key)
    if type(value) == "number" then
        M.snapshot_set(state, feature, owner, key, 0.0)
        return true
    elseif type(value) == "boolean" then
        M.snapshot_set(state, feature, owner, key, false)
        return true
    end
    return false
end

function M.zero_recursive(state, feature, value, depth, seen)
    value = M.table_extend(value)
    depth = tonumber(depth) or 0
    if value == nil or depth > 9 then return end
    local t = type(value)
    if t ~= "table" and t ~= "userdata" then return end
    seen = seen or {}
    if seen[value] then return end
    seen[value] = true
    if t ~= "table" then return end
    M.iterate_table(value, function(owner, key, child)
        if type(child) == "number" then
            M.snapshot_set(state, feature, owner, key, 0.0)
        elseif type(child) == "boolean" then
            M.snapshot_set(state, feature, owner, key, false)
        else
            local extended = M.table_extend(child)
            if type(extended) == "table" and extended ~= child then
                pcall(function() owner[key] = extended end)
            end
            M.zero_recursive(state, feature, extended, depth + 1, seen)
        end
    end)
end

function M.patch_random_range(state, feature, value)
    value = M.table_extend(value)
    if value == nil then return end
    M.zero_scalar_field(state, feature, value, "MinValue")
    M.zero_scalar_field(state, feature, value, "MaxValue")
    local random_values = M.get_extended_field(value, "RandomValues")
    M.iterate_table(random_values, function(_, _, child)
        child = M.table_extend(child)
        if child ~= nil then
            M.zero_scalar_field(state, feature, child, "MinValue")
            M.zero_scalar_field(state, feature, child, "MaxValue")
        end
    end)
end

function M.patch_random_collection(state, feature, value)
    value = M.table_extend(value)
    M.iterate_table(value, function(owner, key, item)
        if type(item) == "number" then
            M.snapshot_set(state, feature, owner, key, 0.0)
            return
        end
        item = M.table_extend(item)
        M.patch_random_range(state, feature, item)
        M.zero_scalar_field(state, feature, item, "Horizontal")
        M.zero_scalar_field(state, feature, item, "Vertical")
        M.zero_scalar_field(state, feature, item, "Percent")
        M.zero_scalar_field(state, feature, item, "Probability")
        M.zero_scalar_field(state, feature, item, "AmplitudeMin")
        M.zero_scalar_field(state, feature, item, "AmplitudeMax")
    end)
end

function M.patch_recoil_group(state, feature, value)
    value = M.table_extend(value)
    if value == nil then return end
    M.patch_random_range(state, feature, M.get_extended_field(value, "HorizontalRandomRecoil"))
    M.patch_random_collection(state, feature, M.get_extended_field(value, "HorizontalRandomRecoils"))
    M.zero_scalar_field(state, feature, value, "HorizontalScale")
    M.patch_random_range(state, feature, M.get_extended_field(value, "VerticalRandomRecoil"))
    M.patch_random_collection(state, feature, M.get_extended_field(value, "VerticalRandomRecoils"))
    M.zero_scalar_field(state, feature, value, "VerticalScale")
    M.patch_random_collection(state, feature, M.get_extended_field(value, "HorizontalRecoils"))
    M.patch_random_collection(state, feature, M.get_extended_field(value, "VerticalRecoils"))
end

function M.apply_no_recoil_row(state, row)
    row = M.table_extend(row)
    if row == nil then return end
    for _, key in ipairs({
        "SingleOrBurstShootRecoil", "SingleOrBurstShootRecoils",
        "ContinueShootRecoil", "ContinueShootRecoils",
        "ContinueShootRecoilLoop", "ContinueShootRecoilLoops",
    }) do
        M.patch_recoil_group(state, "no_recoil", M.get_extended_field(row, key))
    end
    for _, key in ipairs({ "SideAimingRecoilFactor", "SideAimingRecoilFactors" }) do
        local value = M.table_extend(M.get_extended_field(row, key))
        if value ~= nil then
            M.zero_scalar_field(state, "no_recoil", value, "Horizontal")
            M.zero_scalar_field(state, "no_recoil", value, "Vertical")
        end
    end
    M.patch_random_collection(state, "no_recoil", M.get_extended_field(row, "HorizontalRecoils"))
    M.patch_random_collection(state, "no_recoil", M.get_extended_field(row, "VerticalRecoils"))
end

function M.converge_recursive(state, owner, key, value, depth, seen, force)
    depth = tonumber(depth) or 0
    if depth > 10 then return end
    local normalized = M.normalize_identifier(key)
    local spread_like = string.find(normalized, "spread", 1, true) ~= nil
        or string.find(normalized, "dispersion", 1, true) ~= nil
        or string.find(normalized, "bloom", 1, true) ~= nil
    -- P0.29.29 PCs 38..43: force=true makes every numeric/boolean descendant
    -- eligible for zeroing; otherwise a spread/dispersion/bloom field starts
    -- forced recursion for its descendants.
    local should_zero = force == true or spread_like

    if should_zero then
        if type(value) == "number" then
            M.snapshot_set(state, "converge", owner, key, 0.0)
            return
        elseif type(value) == "boolean" then
            M.snapshot_set(state, "converge", owner, key, false)
            return
        end
    end

    value = M.table_extend(value)
    local t = type(value)
    if t ~= "table" and t ~= "userdata" then return end
    seen = seen or {}
    if seen[value] then return end
    seen[value] = true

    if t == "table" then
        M.iterate_table(value, function(child_owner, child_key, child_value)
            M.converge_recursive(state, child_owner, child_key, child_value, depth + 1, seen, should_zero)
        end)
        return
    end

    for _, field in ipairs(M.CONVERGE_FIELDS) do
        local child = safe_get(value, field)
        if child ~= nil then
            M.converge_recursive(state, value, field, child, depth + 1, seen, should_zero)
        end
    end
end

local KNOWN_BONES = { rightleg=true, leftleg=true, spine2=true, head=true, neck=true, hips=true }

function M.canonical_bone_name(value)
    local normalized = M.normalize_identifier(value)
    if KNOWN_BONES[normalized] then return normalized end
    local t = type(value)
    if t == "table" or t == "userdata" then
        for _, key in ipairs({ "Value", "value", "Name", "name", "BoneName", "boneName" }) do
            local candidate = safe_get(value, key)
            candidate = M.normalize_identifier(candidate)
            if KNOWN_BONES[candidate] then return candidate end
        end
        for _, key in ipairs({ "ToString", "GetName", "ToName" }) do
            local fn = safe_get(value, key)
            local ok, result = call_optional_self(fn, value)
            if ok then
                local candidate = M.normalize_identifier(result)
                if KNOWN_BONES[candidate] then return candidate end
            end
        end
    end
    for _, bone in ipairs({ "rightleg", "leftleg", "spine2", "head", "neck", "hips" }) do
        if string.find(normalized, bone, 1, true) ~= nil then return bone end
    end
    return nil
end

function M.make_name(exemplar, name)
    if type(exemplar) == "string" then return name end
    for _, global_name in ipairs({ "FName", "Name", "MakeLiteralName", "StringToName", "Conv_StringToName" }) do
        local fn = rawget(_G, global_name)
        if type(fn) == "function" then
            local ok, result = pcall(fn, name)
            if ok and result ~= nil then return result end
        end
    end
    return name
end

function M.array_len(array)
    if type(array) == "table" then return #array end
    if type(array) ~= "userdata" then return 0 end
    local fn = safe_get(array, "Num")
    local ok, value = call_optional_self(fn, array)
    if ok then return math.max(0, math.floor(tonumber(value) or 0)) end
    local helper = rawget(_G, "ULuaArrayHelper")
    fn = safe_get(helper, "Num")
    ok, value = call_optional_self(fn, helper, array)
    if ok then return math.max(0, math.floor(tonumber(value) or 0)) end
    return 0
end

function M.array_get(array, index0)
    if type(array) == "table" then return array[index0 + 1] end
    if type(array) ~= "userdata" then return nil end
    local index1 = index0 + 1
    local fn = safe_get(array, "Get")
    local ok, value = call_optional_self(fn, array, index1)
    if ok and value ~= nil then return value end
    local helper = rawget(_G, "ULuaArrayHelper")
    fn = safe_get(helper, "Get")
    ok, value = call_optional_self(fn, helper, array, index1)
    if ok then return value end
    return nil
end

function M.array_set_raw(array, index0, value)
    local index1 = index0 + 1
    if type(array) == "table" then return pcall(function() array[index1] = value end) end
    if type(array) ~= "userdata" then return false end
    local fn = safe_get(array, "Set")
    local ok = false
    if type(fn) == "function" then
        ok = select(1, call_optional_self(fn, array, index1, value))
        if ok then return true end
    end
    local helper = rawget(_G, "ULuaArrayHelper")
    fn = safe_get(helper, "Set")
    if type(fn) == "function" then
        ok = select(1, call_optional_self(fn, helper, array, index1, value))
        if ok then return true end
    end
    return pcall(function() array[index1] = value end)
end

function M.ensure_bone_name_pool(state)
    local pool = state.custom_dongdong_bone_name_pool
    if type(pool) ~= "table" then pool = {}; state.custom_dongdong_bone_name_pool = pool end
    return pool
end

function M.ensure_bone_array_snapshots(state)
    local snapshots = state.custom_dongdong_bone_array_snapshots
    if type(snapshots) ~= "table" then
        snapshots = { records = {}, seen = {} }
        state.custom_dongdong_bone_array_snapshots = snapshots
    end
    if type(snapshots.records) ~= "table" then snapshots.records = {} end
    if type(snapshots.seen) ~= "table" then snapshots.seen = {} end
    return snapshots
end

function M.binding_key(binding)
    if type(binding) ~= "table" then return "" end
    return table.concat({ tostring(binding.owner), tostring(binding.key), tostring(binding.parent_array),
        tostring(binding.parent_index), tostring(binding.parent_owner), tostring(binding.parent_key) }, "\0")
end

function M.add_binding(record, binding)
    if type(record) ~= "table" or type(binding) ~= "table" then return end
    if binding.owner == nil or binding.key == nil then return end
    if type(record.bindings) ~= "table" then record.bindings = {} end
    if type(record.binding_seen) ~= "table" then record.binding_seen = {} end
    local key = M.binding_key(binding)
    if record.binding_seen[key] then return end
    record.binding_seen[key] = true
    record.bindings[#record.bindings + 1] = binding
end

function M.snapshot_bone_array(state, array, binding)
    local t = type(array)
    if t ~= "table" and t ~= "userdata" then return nil end
    local snapshots = M.ensure_bone_array_snapshots(state)
    local record = snapshots.seen[array]
    if type(record) == "table" then
        M.add_binding(record, binding)
        return record
    end
    local count = M.array_len(array)
    if count <= 0 then return nil end
    record = { array=array, count=count, values={}, bindings={}, binding_seen={} }
    local pool = M.ensure_bone_name_pool(state)
    for index0 = 0, count - 1 do
        local value = M.array_get(array, index0)
        record.values[index0 + 1] = value
        local canonical = M.canonical_bone_name(value)
        if canonical ~= nil and pool[canonical] == nil then pool[canonical] = value end
    end
    M.add_binding(record, binding)
    snapshots.seen[array] = record
    snapshots.records[#snapshots.records + 1] = record
    return record
end

function M.resolve_bone_value(state, exemplar, desired)
    local pool = M.ensure_bone_name_pool(state)
    local key = M.canonical_bone_name(desired)
    local existing = pool[key]
    if existing ~= nil then return existing end
    return M.make_name(exemplar, desired)
end

function M.array_set_verified(state, array, index0, exemplar, desired)
    local replacement = M.resolve_bone_value(state, exemplar, desired)
    if not M.array_set_raw(array, index0, replacement) then return false end
    local current = M.array_get(array, index0)
    return M.canonical_bone_name(current) == M.canonical_bone_name(desired)
end

function M.restore_binding(binding, array)
    if type(binding) ~= "table" or binding.owner == nil or binding.key == nil then return false end
    local ok = pcall(function() binding.owner[binding.key] = array end)
    if binding.parent_array ~= nil and binding.parent_index ~= nil and binding.parent_value ~= nil then
        if M.array_set_raw(binding.parent_array, binding.parent_index, binding.parent_value) then ok = true end
    end
    if binding.parent_owner ~= nil and binding.parent_key ~= nil then
        if pcall(function() binding.parent_owner[binding.parent_key] = binding.parent_array end) then ok = true end
    end
    return ok
end

function M.restore_record_bindings(record)
    if type(record) ~= "table" or type(record.bindings) ~= "table" then return false end
    local restored = false
    for _, binding in ipairs(record.bindings) do
        if M.restore_binding(binding, record.array) then restored = true end
    end
    return restored
end

function M.restore_bone_array_snapshots(state)
    local snapshots = state.custom_dongdong_bone_array_snapshots
    if type(snapshots) ~= "table" or type(snapshots.records) ~= "table" then return false end
    local restored = false
    for _, record in ipairs(snapshots.records) do
        if type(record) == "table" and record.array ~= nil and type(record.values) == "table" then
            local record_restored = false
            local count = tonumber(record.count) or 0
            for index0 = 0, count - 1 do
                local original = record.values[index0 + 1]
                local canonical = M.canonical_bone_name(original)
                if canonical ~= nil and M.array_set_verified(state, record.array, index0, original, canonical) then
                    record_restored = true
                end
            end
            if record_restored and M.restore_record_bindings(record) then restored = true end
        end
    end
    local count = tonumber(state.custom_dongdong_aim_bone_restore_count) or 0
    state.custom_dongdong_aim_bone_restore_count = count + (restored and 1 or 0)
    return restored
end

local function apply_row_source(state, feature, root, key, row, table_name, handlers)
    row = M.table_extend(row)
    if type(row) ~= "table" then return false end
    local current = safe_get(root, key)
    if row ~= current then pcall(function() root[key] = row end) end
    if feature == "no_recoil" then
        M.apply_no_recoil_row(state, row)
    elseif feature == "converge" then
        M.converge_recursive(state, root, key, row, 0, {}, false)
    elseif feature == "anti_shake" then
        if not handlers or type(handlers.anti_shake) ~= "function" then return false end
        handlers.anti_shake(row)
    elseif feature == "aim" then
        if not handlers or type(handlers.aim) ~= "function" then return false end
        handlers.aim(root, key, row, table_name)
    else
        return false
    end
    return true
end

function M.apply_table(state, feature, table_value, table_name, handlers)
    local root = M.table_extend(table_value)
    if type(root) ~= "table" then return false end
    local success = false
    M.iterate_table(root, function(owner, key, row)
        if apply_row_source(state, feature, owner, key, row, table_name, handlers) then success = true end
    end)
    return success
end

function M.apply_feature(state, feature, handlers)
    local names = M.FEATURE_TABLES[feature]
    if type(names) ~= "table" then return false end
    local success, seen = false, {}
    for _, name in ipairs(names) do
        local table_value = M.get_data_table(name)
        if table_value ~= nil and not seen[table_value] then
            seen[table_value] = true
            if M.apply_table(state, feature, table_value, name, handlers) then success = true end
        end
    end
    return success
end

function M.get_catalog()
    return { prototypes=M.PROTOTYPES, feature_tables=M.FEATURE_TABLES, converge_field_count=#M.CONVERGE_FIELDS }
end

return M

end)(S)
-- END mutation_runtime.lua

-- BEGIN aim_mutation.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local M = {}
S.AimMutation = M

-- Descriptive names reconstructed from P0.29.30..39 and P0.29.65, not debug symbols.
-- This module is deliberately not installed in the runtime bridge yet.
M.PROTOTYPES = { clamp = "0.29.30", speed = "0.29.31", fov = "0.29.32",
    fov_scale = "0.29.33", distance = "0.29.34", lock_time = "0.29.35",
    mode = "0.29.36", speed_scale = "0.29.37", inverse_speed = "0.29.38",
    lock_delay = "0.29.39", qualify_profile_key = "0.29.40",
    profile_lookup = "0.29.41", scale_clamp = "0.29.42",
    composite = "0.29.43", replacement = "0.29.65",
    walk_and_patch = "0.29.66", apply_aim_table = "0.29.67" }

function M.clamp(value, minimum, maximum, fallback)
    return math.min(maximum, math.max(minimum, tonumber(value) or fallback))
end

function M.scale_clamp(value, multiplier, minimum, maximum)
    local result = (tonumber(value) or 0) * multiplier
    if minimum ~= nil and result < minimum then result = minimum end
    if maximum ~= nil and result > maximum then result = maximum end
    return result
end

function M.settings(state)
    local speed = M.clamp(state.custom_aim_speed, 1, 100, 50)
    local fov = M.clamp(state.custom_aim_range, 1, 360, 90)
    local distance = M.clamp(state.custom_aim_distance, 1, 500, 150)
    local lock = M.clamp(state.custom_aim_lock_time, 1, 100, 1)
    local mode
    local toggles = state.custom_dongdong_toggle_state
    if type(toggles) == "table" then
        if toggles.aim == true then mode = "fire"
        elseif toggles.anti_shake == true then mode = "ads" end
    end
    return { speed = speed, fov = fov, distance = distance, lock = lock,
        fov_scale = fov <= 90 and fov / 90 or 1 + (fov - 90) / 270 * 5,
        mode = mode, speed_scale = speed / 50,
        inverse_speed = M.clamp(0.05 * (50 / speed), 0.001, 1, 0),
        lock_delay = M.clamp((0.001 + (100 - speed) / 99 * 0.999) * lock * 0.01, 0.001, 0.35, 0) }
end

local function has(s, part) return s:find(part, 1, true) ~= nil end
local function member(key, names)
    for i = 1, #names do if key == names[i] then return true end end
    return false
end

-- deps: normalize_identifier=P0.29.10, read_field=P0.29.2.
-- The R52 profile matrix and P0.29.40/41 are below.
-- The remaining dependencies must retain their original contracts when an
-- active row walker is wired to this function.
function M.replacement(state, deps, row, table_name, field, original, path)
    assert(type(state) == "table" and type(deps) == "table", "state/dependencies required")
    local normalize = assert(deps.normalize_identifier)
    local name, key = normalize(table_name), normalize(field)
    local cfg = M.settings(state)
    if cfg.mode == nil then return nil, false end
    local speed, fov, dist = cfg.speed, cfg.fov, cfg.distance
    local speed_scale, fov_scale = cfg.speed_scale, cfg.fov_scale
    local dist_scale, dist_100, dist_300 = dist / 150, dist * 100, dist * 300
    local composite = M.clamp(dist * 1.2 + fov * 1.4 * math.sqrt(fov_scale), 30, 2000, 30)
    local gamepad = has(name, "weaponaimassistortableforgamepad")
    local normal = has(name, "weaponaimassistortable") and not gamepad
    -- P0.29.65:38..50 excludes the Gamepad substring from the normal flag.
    -- The ADS branch at 150..153 requires that normal flag; Gamepad is not
    -- interchangeable with the ordinary aim-assistor table.
    local assist = normal
    local assisted = has(name, "weaponassistedaimingtable") or has(name, "weaponassistedaiminggrouptable")
    local group = has(name, "weaponassistedaiminggrouptable")
    local bullet = has(name, "weaponbullettable")
    local shooting = has(name, "shootingconfig")
    local following = has(name, "crosshairfollowingconfig")
    local damping = has(name, "crosshairdampingconfig")
    local tracking = has(name, "activetrackingconfig")
    local zoom = has(name, "zoominginconfig")

    if cfg.mode == "ads" then
        if not assist then return nil, false end
        if key == "btakeeffect" then return true, true end
        if key == "x" and has(name, "effectivefovrange") then return fov, true end
        if member(key, {"coneanglebase", "outer2innerrangeforraychecker"}) then return fov, true end
        if key == "rangescale" then return fov / 90, true end
        if key == "coneheightbase" then return dist_100, true end
        if key == "lockontime" then return cfg.lock_delay, true end
        if member(key, {"pitchrateads", "yawrateads"}) then return speed, true end
        if member(key, {"pitchratehip", "yawratehip"}) then return nil, false end
        if key == "inrangeb" then
            if type(original) ~= "number" then return nil, false end
            local base
            if original >= 9000 then base = 33333
            elseif original >= 5500 then base = 22222
            elseif original >= 2800 then base = 9999
            elseif original >= 2200 then base = shooting and 7000 or 7777
            else base = 3 end
            return base * dist_scale, true
        end
        if member(key, {"outrangea", "outrangeb"}) then return 3, true end
        if key == "playerinputawaytargetangle" then return 1555, true end
        if member(key, {"playerinputawaytargetvalue", "playerinputrecordtime"}) then return 0, true end
        if key == "conefilteractorsmaxnum" then
            return M.clamp(math.floor(8 * fov_scale + 0.5), 16, 64, 16), true
        end
        return nil, false
    end

    if bullet then
        if key == "radius" and type(original) == "number" and original <= 3 then return 5, true end
        return nil, false
    end
    if group then
        local links = { singleidpve = "SingleId", autoidpve = "AutoId", burstidpve = "BurstId",
            aimingsingleidpve = "AimingSingleId", aimingautoidpve = "AimingAutoId",
            aimingburstidpve = "AimingBurstId" }
        local target = links[key]
        if target then
            local value = tonumber(assert(deps.read_field)(row, target))
            if value and value > 0 then return value, true end
        end
        return nil, false
    end
    if assisted then
        if member(key, {"enabledistancemin", "enabledistanceminforrotatesticky", "enabledistanceminformagneticsticky"}) then return 0, true end
        if member(key, {"enabledistancemax", "enabledistancemaxforrotatesticky", "enabledistancemaxformagneticsticky"}) then return dist_300, true end
        if member(key, {"assistedboxminradius", "assistedboxminradiusforrotatesticky", "assistedboxminradiusformagneticsticky"}) then return composite * 0.65, true end
        if member(key, {"assistedboxmaxradius", "assistedboxmaxradiusforrotatesticky", "assistedboxmaxradiusformagneticsticky"}) then return composite, true end
        if member(key, {"assistedboxverticalscale", "assistedboxverticalscaleforrotatesticky", "assistedboxverticalscaleformagneticsticky"}) then
            return math.min(2, 1.35 + math.max(0, fov_scale - 1) * 0.13), true
        end
        if member(key, {"horizontalrecoilspeed", "verticalrecoilspeed", "horizontalrecoilspeedforzoomin", "verticalrecoilspeedforzoomin"}) then return speed, true end
        if member(key, {"pausetimeafterfire", "recoilreduceactivationtime", "magneticcdseconds", "magneticenablefocusseconds"}) then return 0, true end
        if key == "recoilspeedtouchparam" then return speed_scale * 1.5, true end
        if key == "stickyparam" then return speed_scale * 3, true end
        if key == "bpreventmissenable" then return true, true end
        if key == "preventmissaddbulletradiusdelta" then return math.min(1500, math.max(composite * 1.25, dist_100 * 0.02)), true end
        if key == "preventmissnumber" then return 12, true end
        if key == "preventmisstime" then return 0.25, true end
        return nil, false
    end
    if assist then return nil, false end
    if key == "btakeeffect" then
        if tracking or zoom then return false, true end
        if shooting or following or damping then return true, true end
        return nil, false
    end

    local value, qualified = M.profile_lookup(normalize, path, table_name, key)
    if value ~= nil then
        local scale_clamp = M.scale_clamp
        if qualified == "lockontime" then return scale_clamp(value, cfg.lock, 0.001, 1), true end
        local factor = shooting and has(qualified, "factor") or following and has(qualified, "factor")
        local interval = shooting and member(key, {"deltatime", "cdtime"}) or following and key == "intervaltime"
        if factor then
            local v = speed_scale
            if has(qualified, "pitchfactor") then
                if shooting then v = v * 1.3
                elseif following then v = v * (has(qualified, "factorlockon") and 1.7 or 1.4) end
            elseif following and has(qualified, "factorlockon") then v = v * 1.15 end
            return scale_clamp(value, v, 0, 3), true
        end
        if interval then
            local v = scale_clamp(value, 1 / speed_scale, 0.001, 0.25)
            if shooting and key == "deltatime" then v = math.max(v, 0.015)
            elseif shooting and key == "cdtime" then v = math.max(v, 0.008)
            elseif following and key == "intervaltime" then v = math.max(v, 0.012) end
            return v, true
        end
        if qualified == "coneanglepower" then
            local n = tonumber(value) or 1
            return M.clamp(fov_scale >= 1 and n / math.sqrt(fov_scale) or n / math.max(fov_scale, 0.05), 0.5, 8, 1), true
        end
        if qualified == "coneanglebase" or has(qualified, "effectivefovrange") or has(qualified, "outer2innerrangeforraychecker") then
            return scale_clamp(value, fov_scale, 0.001, 99999), true
        end
        if member(qualified, {"coneheightbase", "coneheightpower"}) then return scale_clamp(value, dist_scale, 0.001, 999999), true end
        if has(qualified, "rangescale") then
            local v = scale_clamp(value, dist_scale, 0.001, 999999)
            if key == "inrangeb" then v = math.max(v, dist_300) end
            if member(key, {"outrangea", "outrangeb"}) then
                v = math.max(v, (shooting or following) and 6 or 3)
            end
            return v, true
        end
    end
    if key == "playerinputawaytargetangle" then return 1555, true end
    if member(key, {"playerinputawaytargetvalue", "playerinputrecordtime"}) then return 0, true end
    if key == "conefilteractorsmaxnum" then return M.clamp(math.floor(8 * fov_scale + 0.5), 16, 64, 16), true end
    return nil, false
end

-- Exact R52 profile literals from verified payload P0.29 instructions 388..934.
M.PROFILE_VALUES = {
    [1] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 3333.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangex"] = 11.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairfollowingconfigintervaltime"] = 0.5,
        ["crosshairfollowingconfigpitchfactorads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorhip"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonads"] = 2.0,
        ["crosshairfollowingconfigpitchfactorlockonhip"] = 2.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairfollowingconfigrangescaleoutrangea"] = 3.0,
        ["crosshairfollowingconfigyawfactorads"] = 1.0,
        ["crosshairfollowingconfigyawfactorhip"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonads"] = 2.0,
        ["crosshairfollowingconfigyawfactorlockonhip"] = 2.0,
        ["lockontime"] = 0.0010000000474974513,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigdeltatime"] = 0.10000000149011612,
        ["shootingconfigeffectivefovrangex"] = 10.0,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigpitchfactorads"] = 1.0,
        ["shootingconfigpitchfactorhip"] = 1.0,
        ["shootingconfigrangescaleinrangeb"] = 33333.0,
        ["shootingconfigrangescaleoutrangea"] = 3.0,
        ["shootingconfigrangescaleoutrangeb"] = 1.0,
        ["shootingconfigyawfactorads"] = 1.0,
        ["shootingconfigyawfactorhip"] = 1.0,
    },
    [1001] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 45900.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckerinrangeb"] = 3.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckeroutrangeb"] = 3.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairfollowingconfigintervaltime"] = 2.0,
        ["crosshairfollowingconfigpitchfactorads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorhip"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonhip"] = 1.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 11111.0,
        ["crosshairfollowingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigyawfactorads"] = 1.0,
        ["crosshairfollowingconfigyawfactorhip"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonhip"] = 1.0,
        ["lockontime"] = 0.0010000000474974513,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigdeltatime"] = 0.05000000074505806,
        ["shootingconfigeffectivefovrangex"] = 11.0,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigpitchfactorads"] = 1.0,
        ["shootingconfigpitchfactorhip"] = 1.0,
        ["shootingconfigrangescaleinrangeb"] = 22222.0,
        ["shootingconfigrangescaleoutrangeb"] = 3.0,
        ["shootingconfigyawfactorads"] = 1.0,
        ["shootingconfigyawfactorhip"] = 1.0,
    },
    [1002] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 44444.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckerinrangeb"] = 3.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckeroutrangeb"] = 3.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairfollowingconfigintervaltime"] = 2.0,
        ["crosshairfollowingconfigpitchfactorads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorhip"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonhip"] = 1.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 9999.0,
        ["crosshairfollowingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigyawfactorads"] = 1.0,
        ["crosshairfollowingconfigyawfactorhip"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonhip"] = 1.0,
        ["lockontime"] = 0.0010000000474974513,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigdeltatime"] = 0.05000000074505806,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigpitchfactorads"] = 1.0,
        ["shootingconfigpitchfactorhip"] = 1.0,
        ["shootingconfigrangescaleoutrangeb"] = 1.0,
        ["shootingconfigyawfactorads"] = 1.0,
        ["shootingconfigyawfactorhip"] = 1.0,
    },
    [1003] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 44444.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckerinrangeb"] = 3.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckeroutrangeb"] = 3.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1444.0,
        ["crosshairfollowingconfigintervaltime"] = 2.0,
        ["crosshairfollowingconfigpitchfactorads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorhip"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonhip"] = 1.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 9999.0,
        ["crosshairfollowingconfigrangescaleoutrangeb"] = 6.0,
        ["crosshairfollowingconfigyawfactorads"] = 1.0,
        ["crosshairfollowingconfigyawfactorhip"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonhip"] = 1.0,
        ["lockontime"] = 0.0010000000474974513,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigdeltatime"] = 0.05000000074505806,
        ["shootingconfigeffectivefovrangex"] = 11.0,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigpitchfactorads"] = 1.0,
        ["shootingconfigpitchfactorhip"] = 1.0,
        ["shootingconfigrangescaleinrangeb"] = 33333.0,
        ["shootingconfigrangescaleoutrangeb"] = 3.0,
        ["shootingconfigyawfactorads"] = 1.0,
        ["shootingconfigyawfactorhip"] = 1.0,
    },
    [11001] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 44444.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckerinrangeb"] = 3.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckeroutrangeb"] = 3.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 33333.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairfollowingconfigintervaltime"] = 2.0,
        ["crosshairfollowingconfigpitchfactorads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorhip"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigpitchfactorlockonhip"] = 1.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 11111.0,
        ["crosshairfollowingconfigrangescaleoutrangeb"] = 6.0,
        ["crosshairfollowingconfigyawfactorads"] = 1.0,
        ["crosshairfollowingconfigyawfactorhip"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonads"] = 1.0,
        ["crosshairfollowingconfigyawfactorlockonhip"] = 1.0,
        ["lockontime"] = 0.009999999776482582,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigdeltatime"] = 0.05000000074505806,
        ["shootingconfigeffectivefovrangex"] = 11.0,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigpitchfactorads"] = 1.0,
        ["shootingconfigpitchfactorhip"] = 1.0,
        ["shootingconfigrangescaleinrangeb"] = 22222.0,
        ["shootingconfigrangescaleoutrangeb"] = 3.0,
        ["shootingconfigyawfactorads"] = 1.0,
        ["shootingconfigyawfactorhip"] = 1.0,
    },
    [1004] = {
        ["coneanglebase"] = 15.0,
        ["coneanglepower"] = 3.0,
        ["coneheightbase"] = 44444.0,
        ["coneheightpower"] = 3.0,
        ["crosshairdampingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckerinrangeb"] = 3.0,
        ["crosshairdampingconfigouter2innerrangeforraycheckeroutrangeb"] = 3.0,
        ["crosshairdampingconfigrangescaleinrangeb"] = 7777.0,
        ["crosshairdampingconfigrangescaleoutrangeb"] = 3.0,
        ["crosshairfollowingconfigeffectivefovrangey"] = 1555.0,
        ["crosshairfollowingconfigrangescaleinrangeb"] = 7777.0,
        ["crosshairfollowingconfigrangescaleoutrangeb"] = 3.0,
        ["lockontime"] = 0.0010000000474974513,
        ["shootingconfigcdtime"] = 0.0010000000474974513,
        ["shootingconfigeffectivefovrangex"] = 11.0,
        ["shootingconfigeffectivefovrangey"] = 1555.0,
        ["shootingconfigrangescaleinrangeb"] = 7000.0,
        ["shootingconfigrangescaleoutrangeb"] = 3.0,
    },
}

function M.qualify_profile_key(normalize, table_name, field)
    local name, key = normalize(table_name), normalize(field)
    for _, part in ipairs({"shootingconfig", "crosshairfollowingconfig", "crosshairdampingconfig", "zoominginconfig", "activetrackingconfig"}) do
        local start = name:find(part, 1, true)
        if start then
            local qualified = name:sub(start)
            if key ~= "" and qualified:sub(-#key) ~= key then qualified = qualified .. key end
            return qualified
        end
    end
    return key
end

function M.profile_lookup(normalize, row_id, table_name, field)
    local profile = M.PROFILE_VALUES[tonumber(row_id)]
    if type(profile) ~= "table" then return nil, nil end
    local qualified = M.qualify_profile_key(normalize, table_name, field)
    return profile[qualified], qualified
end

-- P0.29.66 / .66.0: the caller of P0.29.65. This source walker stays
-- inactive until the remaining chain is compared and the bridge is changed.
function M.walk_and_patch(state, deps, owner, field, value, table_name, depth, seen, row_id)
    local mutation = assert(S.MutationRuntime, "MutationRuntime required")
    depth = depth or 0
    if depth > 13 then return end
    local normalize = assert(deps.normalize_identifier)
    local key = normalize(field)
    if key == "conefilterbones" or key == "conefilterbonesofai" then return end
    local replacement, should_patch = M.replacement(state, deps, owner, table_name, field, value, row_id)
    if should_patch then
        mutation.snapshot_set(state, "aim", owner, field, replacement)
        return
    end
    value = mutation.table_extend(value)
    local kind = type(value)
    if kind ~= "table" and kind ~= "userdata" then return end
    seen = seen or {}
    if seen[value] then return end
    seen[value] = true
    local path = table_name .. "." .. tostring(field)
    if kind == "table" then
        mutation.iterate_table(value, function(child_owner, child_field, child_value)
            M.walk_and_patch(state, deps, child_owner, child_field, child_value, path,
                depth + 1, seen, row_id)
        end)
        return
    end
    for _, child_field in ipairs(mutation.CONVERGE_FIELDS) do
        local child_value = mutation.safe_get(value, child_field)
        if child_value ~= nil then
            M.walk_and_patch(state, deps, value, child_field, child_value,
                table_name .. "." .. child_field, depth + 1, seen, row_id)
        end
    end
end

-- Aim branch of P0.29.67 / .67.0. `patch_bones` is P0.29.63, which has
-- not yet been fully reconstructed. Requiring it prevents partial execution.
function M.apply_aim_table(state, deps, table_value, table_name)
    local mutation = assert(S.MutationRuntime, "MutationRuntime required")
    local patch_bones = assert(deps.patch_bones, "P0.29.63 bone updater required")
    local root = mutation.table_extend(table_value)
    if type(root) ~= "table" then return false end
    local changed = false
    mutation.iterate_table(root, function(owner, key, row)
        row = mutation.table_extend(row)
        if type(row) ~= "table" then return end
        if row ~= mutation.safe_get(owner, key) then
            pcall(function() owner[key] = row end)
        end
        local raw_id = mutation.safe_get(row, "AimAssistorId")
        local row_id = tonumber(raw_id)
        if row_id == nil then
            row_id = tonumber(mutation.safe_get(raw_id, "value") or mutation.safe_get(raw_id, "Value"))
        end
        if row_id == nil then
            row_id = ({ Default=1, NewRow=1001, NewRow_0=1002,
                        NewRow_1=1003, NewRow_2=11001, NewRow_3=1004 })[tostring(key)]
        end
        patch_bones(row)
        M.walk_and_patch(state, deps, owner, key, row,
            table_name .. "." .. tostring(key), 0, {}, row_id)
        changed = true
    end)
    return changed
end

return M

end)(S)
-- END aim_mutation.lua

-- BEGIN aim_bones.lua
;(function(...)
local S = ...
assert(type(S) == "table" and type(S.MutationRuntime) == "table")
local Mutation = S.MutationRuntime
local M = {}
S.AimBones = M
-- Names are reconstructed descriptions; IDs and the four maps come from R67.
M.PROTOTYPES = { remap = "0.29.45", patch_array = "0.29.61",
    patch_ai_groups = "0.29.62", patch_row = "0.29.63",
    refresh_bone_table = "0.29.64" }
local MAPS = {
    head = {head="Head",neck="Head",spine2="Head",hips="Head",leftleg="Head",rightleg="Head"},
    chest = {head="Spine2",neck="Spine2",spine2="Spine2",hips="Spine2",leftleg="Spine2",rightleg="Spine2"},
    leg = {head="RightLeg",neck="LeftLeg",spine2="RightLeg",hips="LeftLeg",leftleg="LeftLeg",rightleg="RightLeg"},
    free = {head="Head",neck="Neck",spine2="Spine2",hips="Hips",leftleg="LeftLeg",rightleg="RightLeg"},
}

function M.remap(state, value)
    local mode = tostring(state.custom_aim_target_part or "head")
    if mode == "miss" then mode = "free" end
    local mapping = MAPS[mode] or MAPS.head
    local bone = Mutation.canonical_bone_name(value)
    if bone == nil then return nil end
    return mapping[bone]
end

function M.patch_array(state, array, binding)
    local record = Mutation.snapshot_bone_array(state, array, binding)
    if type(record) ~= "table" then return false end
    local patched, count = false, 0
    for index0 = 0, record.count - 1 do
        local original = record.values[index0 + 1]
        local desired = M.remap(state, original)
        if desired ~= nil and Mutation.array_set_verified(state, array, index0, original, desired) then
            patched, count = true, count + 1
        end
    end
    if patched then
        Mutation.restore_record_bindings(record)
        state.custom_dongdong_aim_bone_verified_count =
            (tonumber(state.custom_dongdong_aim_bone_verified_count) or 0) + count
    end
    return patched
end

local function is_array(v) return type(v) == "table" or type(v) == "userdata" end

function M.patch_ai_groups(state, array, binding)
    if not is_array(array) then return false end
    local count = Mutation.array_len(array)
    if count <= 0 then return false end
    local patched, patched_groups = false, 0
    for index0 = 0, count - 1 do
        local item = Mutation.array_get(array, index0)
        if is_array(item) then
            local dat = Mutation.get_extended_field(item, "_Dat")
            local bones = Mutation.get_extended_field(item, "ConeFilterBones")
            local group_changed = false
            for _, entry in ipairs({{item, bones}, {dat, Mutation.get_extended_field(dat, "ConeFilterBones")}}) do
                local owner, subarray = entry[1], entry[2]
                if is_array(subarray) then
                    local subbinding = {owner=owner, key="ConeFilterBones",
                        parent_array=array, parent_index=index0, parent_value=item,
                        parent_owner=binding and binding.owner,
                        parent_key=binding and binding.key}
                    if M.patch_array(state, subarray, subbinding) then group_changed = true end
                end
            end
            if group_changed then
                Mutation.array_set_raw(array, index0, item)
                if binding and binding.owner ~= nil and binding.key ~= nil then
                    pcall(function() binding.owner[binding.key] = array end)
                end
                patched, patched_groups = true, patched_groups + 1
            end
        end
    end
    if patched_groups > 0 then
        state.custom_dongdong_aim_ai_bone_group_count =
            (tonumber(state.custom_dongdong_aim_ai_bone_group_count) or 0) + patched_groups
    end
    return patched
end

function M.patch_row(state, row)
    if not is_array(row) then return false end
    local patched = false
    local function candidate(owner, field, fn)
        local array = Mutation.get_extended_field(owner, field)
        if is_array(array) and fn(state, array, {owner=owner, key=field}) then patched = true end
    end
    local dat = Mutation.get_extended_field(row, "_Dat")
    if dat ~= nil then
        candidate(dat, "ConeFilterBones", M.patch_array)
        candidate(dat, "ConeFilterBonesOfAI", M.patch_ai_groups)
    end
    candidate(row, "ConeFilterBones", M.patch_array)
    candidate(row, "ConeFilterBonesOfAI", M.patch_ai_groups)
    if patched then
        state.custom_dongdong_aim_bone_patch_count =
            (tonumber(state.custom_dongdong_aim_bone_patch_count) or 0) + 1
    end
    return patched
end

function M.refresh_bone_table(state)
    local toggles = state.custom_dongdong_toggle_state or {}
    if toggles.aim ~= true and toggles.anti_shake ~= true then return false end
    Mutation.restore_bone_array_snapshots(state)
    local table_value = Mutation.table_extend(Mutation.get_data_table("WeaponAimAssistorTable"))
    if type(table_value) ~= "table" then return false end
    local patched = false
    Mutation.iterate_table(table_value, function(_, _, row)
        if M.patch_row(state, Mutation.table_extend(row)) then patched = true end
    end)
    return patched
end

return M

end)(S)
-- END aim_bones.lua

-- BEGIN feature_control.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

-- Phase D2 source reconstruction of payload prototypes P0.29.73 and P0.29.77.
-- Engine/data-table mutation helpers are explicit dependencies because their original
-- implementations live in sibling stripped prototypes and are reconstructed separately.
local M = {}
S.FeatureControl = M

M.BUILD_REVISION = "v62-character-color-refresh-skin-mesh"
M.PROTOTYPES = {
    set_dongdong_feature_config = "0.29.73",
    set_dongdong_aim_part = "0.29.77",
}

local function ensure_state(state)
    local toggles = state.custom_dongdong_toggle_state
    if type(toggles) ~= "table" then
        toggles = {}
        state.custom_dongdong_toggle_state = toggles
    end
    return toggles
end

local function need(deps, name)
    local fn = deps and deps[name]
    assert(type(fn) == "function", "missing reconstructed dependency: " .. name)
    return fn
end

function M.set_dongdong_feature_config(state, deps, feature, enabled)
    assert(type(state) == "table", "state table required")
    local toggles = ensure_state(state)

    if feature == "aim" or feature == "anti_shake" then
        if enabled == true then
            toggles[feature] = true
            if feature == "aim" then
                toggles.anti_shake = false
            else
                toggles.aim = false
            end
        else
            toggles[feature] = false
        end

        need(deps, "restore_bone_array_snapshots")()
        need(deps, "restore_feature_snapshot")("anti_shake")
        need(deps, "restore_feature_snapshot")("aim")

        local active = toggles.aim == true or toggles.anti_shake == true
        if active then need(deps, "apply_feature")("aim") end
        need(deps, "set_native_aim_assist")(active)
        need(deps, "set_fire_assisted_aim_debug")(toggles.aim == true)
        return true
    end

    toggles[feature] = enabled == true
    if feature ~= "no_recoil" and feature ~= "converge" then
        return false
    end

    need(deps, "restore_feature_snapshot")(feature)
    if enabled == true then need(deps, "apply_feature")(feature) end
    return true
end

function M.set_dongdong_aim_part(state, deps)
    assert(type(state) == "table", "state table required")
    local delay = need(deps, "delay")
    local set_feature = deps.set_feature_config or function(feature, enabled)
        return M.set_dongdong_feature_config(state, deps, feature, enabled)
    end

    local revision = (tonumber(state.custom_dongdong_aim_part_revision) or 0) + 1
    state.custom_dongdong_aim_part_revision = revision

    delay(0.12, function()
        if revision ~= state.custom_dongdong_aim_part_revision then return end
        local toggles = type(state.custom_dongdong_toggle_state) == "table" and state.custom_dongdong_toggle_state or {}
        local mode
        if toggles.aim == true then mode = "aim"
        elseif toggles.anti_shake == true then mode = "anti_shake" end
        if mode == nil then return end

        set_feature(mode, false)
        state.custom_dongdong_bone_array_snapshots = nil
        state.custom_dongdong_bone_name_pool = nil
        state.custom_dongdong_bone_cache_revision = M.BUILD_REVISION

        delay(0.04, function()
            set_feature(mode, true)
            delay(0.1, function()
                if revision ~= state.custom_dongdong_aim_part_revision then return end
                local initialized = need(deps, "init_current_weapon")()
                if not initialized then need(deps, "refresh_aiming_runtime")() end

                delay(0.38, function()
                    local current = type(state.custom_dongdong_toggle_state) == "table" and state.custom_dongdong_toggle_state or {}
                    if mode == "aim" and current.aim == true then
                        set_feature("aim", true)
                    elseif mode == "anti_shake" and current.anti_shake == true then
                        set_feature("anti_shake", true)
                    end
                end)
            end)
        end)
    end)
    return true
end

function M.get_catalog()
    return { prototypes = M.PROTOTYPES, build_revision = M.BUILD_REVISION }
end

end)(S)
-- END feature_control.lua

-- BEGIN character_visuals.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

-- Phase D2 source reconstruction of public visual-entry prototypes P0.29.99..103.
-- Lower-level mesh scanning/material mutation remains an explicit dependency for the next group.
local M = {}
S.CharacterVisuals = M
M.PROTOTYPES = {
    normalize_color = "0.29.99",
    normalize_ai_color = "0.29.100",
    set_ai_color = "0.29.101",
    set_real_player_color = "0.29.102",
    set_character_xray = "0.29.103",
}

M.COLOR_NAMES = { red = "红色", green = "绿色", none = "不着色" }

function M.normalize_color(value)
    if value == "green" then return "green" end
    return "red"
end

function M.normalize_ai_color(value)
    if value == "none" or value == "off" or value == "disabled" then return "none" end
    return M.normalize_color(value)
end

local function need(deps, name)
    local fn = deps and deps[name]
    assert(type(fn) == "function", "missing reconstructed dependency: " .. name)
    return fn
end

function M.set_ai_color(state, deps, value)
    local key = M.normalize_ai_color(value)
    if key == "none" then need(deps, "restore_mesh_category")("ai") end
    state.custom_ai_color_enabled = key ~= "none"
    state.custom_ai_color_key = key
    state.custom_ai_color_name = M.COLOR_NAMES[key]
    need(deps, "rescan_character_colors")()
end

function M.set_real_player_color(state, deps, value)
    local key = M.normalize_color(value)
    state.custom_real_color_key = key
    state.custom_real_color_name = M.COLOR_NAMES[key]
    need(deps, "rescan_character_colors")()
end

function M.set_character_xray(state, deps, enabled)
    state.custom_character_xray_enabled = enabled == true
    if state.custom_character_xray_enabled then
        local meshes = state.custom_character_xray_meshes or {}
        for mesh, snapshot in pairs(meshes) do
            need(deps, "restore_mesh_snapshot")(mesh, snapshot)
        end
        state.custom_character_xray_meshes = need(deps, "new_weak_mesh_table")()
    end
    need(deps, "rescan_character_colors")()
end

function M.get_catalog() return { prototypes = M.PROTOTYPES } end

end)(S)
-- END character_visuals.lua

-- BEGIN native_settings_ui.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

-- Phase-D reconstruction of payload prototype P0.29.105.
-- Original debug/local names were stripped. Public/global names and engine API names below
-- come from constants/call-sites in the verified baseline payload; helper names are reconstructed.

local M = {}
S.NativeSettingsUI = M

M.PROTOTYPE = "0.29.105"
M.PAGE_TITLE = "@DrkZeref" -- intentional user-requested divergence from the embedded payload.
M.TITLE_CLASS_PATH = "/Game/BluePrints/UI/UMG/Common/Library/WBP_TitleWithLine.WBP_TitleWithLine_C"
M.REQUIRED_HOOK_COUNT = 9
M.HOOK_METHODS = {
    "_InitDynamicBtns",
    "SetSelectedModePanel",
    "OnInitExtraData",
    "OnShowBegin",
    "OnActivate",
    "_FetchSettingSystemByTab",
    "_UpdateSysetemSettingPanel",
    "OnHideBegin",
    "OnClose",
}

M.UI_MODEL = {
    { section = "Combat", row = 1 },
    { kind = "toggle", row = 2, column = 0, title = "No Recoil", on = "Enable", off = "Disable", feature = "no_recoil" },
    { kind = "toggle", row = 2, column = 1, title = "Bullet Spread Control", on = "Enable", off = "Disable", feature = "converge" },
    { kind = "toggle", row = 3, column = 0, title = "Hip-Fire Aim", on = "Enable", off = "Disable", feature = "aim" },
    { kind = "toggle", row = 3, column = 1, title = "ADS Aim", on = "Enable", off = "Disable", feature = "anti_shake" },
    { section = "Visuals", row = 4 },
    { kind = "toggle", row = 5, column = 0, title = "Bot Highlight", on = "Enable", off = "Disable" },
    { kind = "choice2", row = 5, column = 1, title = "Bot Color", first = "Red", second = "Green" },
    { kind = "choice2", row = 6, column = 0, title = "Player Color", first = "Red", second = "Green" },
    { kind = "toggle", row = 6, column = 1, title = "Player X-Ray", on = "Enable", off = "Disable" },
    { section = "Aim Settings", row = 7 },
    { kind = "choice4", row = 8, column = 0, span = 2, title = "Target Bone", choices = { "Head", "Chest", "Legs", "Point & Shoot" } },
    { kind = "slider", row = 9, column = 0, span = 2, title = "Aim Speed", min = 1, max = 100, default = 50, global_key = "custom_aim_speed" },
    { kind = "slider", row = 10, column = 0, span = 2, title = "Aim FOV", min = 1, max = 360, default = 90, global_key = "custom_aim_range" },
    { kind = "slider", row = 11, column = 0, span = 2, title = "Aim Distance", min = 1, max = 500, default = 150, global_key = "custom_aim_distance" },
    { kind = "slider", row = 12, column = 0, span = 2, title = "Aim Lock Delay", min = 1, max = 100, default = 1, global_key = "custom_aim_lock_time" },
}

local function safe_get(obj, key)
    if obj == nil then return nil end
    local ok, value = pcall(function() return obj[key] end)
    if ok then return value end
    return nil
end

local function unwrap(obj)
    if obj == nil then return nil end
    if type(obj) == "table" then
        return rawget(obj, "__cppinst") or rawget(obj, "_cppIns") or rawget(obj, "_cppinst") or obj
    end
    return obj
end

local function from_weak(value)
    local fn = rawget(_G, "getfromweak")
    if type(fn) == "function" then
        local ok, result = pcall(fn, value)
        if ok and result ~= nil then return result end
    end
    return value
end

local function pack(...)
    return { n = select("#", ...), ... }
end

local unpack_values = table.unpack or unpack

local function delayed(seconds, fn)
    local timer = rawget(_G, "Timer")
    local delay = safe_get(timer, "DelayCall")
    if type(delay) ~= "function" then
        fn()
        return
    end
    local ok = pcall(delay, seconds, fn)
    if not ok then pcall(delay, timer, seconds, fn) end
end

local function import_symbol(name)
    local existing = rawget(_G, name)
    if existing ~= nil then return existing end
    local import = rawget(_G, "import")
    if type(import) ~= "function" then return nil end
    local ok, value = pcall(import, name)
    if ok then return value end
    return nil
end

local function require_table(name)
    local req = rawget(_G, "require") or require
    if type(req) ~= "function" then return nil end
    local ok, value = pcall(req, name)
    if ok and type(value) == "table" then return value end
    return nil
end

local function facade_manager(name)
    local facade = rawget(_G, "Facade")
    local value = safe_get(facade, name)
    if value ~= nil then return value end
    return rawget(_G, name)
end

local function localize(text, key)
    local fn = rawget(_G, "NewLuaLocText")
    if type(fn) == "function" then
        local ok, value = pcall(fn, text, "DongDongNativeSetting", key)
        if ok and value ~= nil then return value end
    end
    return text
end

local function make_margin(import_fn, left, top, right, bottom)
    local ctor = rawget(_G, "FMargin")
    if type(ctor) == "function" then
        local ok, margin = pcall(ctor, left, top, right, bottom)
        if ok and margin ~= nil then return margin end
    end
    if type(import_fn) == "function" then
        local ok_class, margin_class = pcall(import_fn, "Margin")
        if ok_class and margin_class ~= nil then
            local ok_obj, margin = pcall(margin_class)
            if ok_obj and margin ~= nil then
                margin.Left, margin.Top, margin.Right, margin.Bottom = left, top, right, bottom
                return margin
            end
        end
    end
    return nil
end

local function slot_as_grid(ui_util, widget)
    if widget == nil then return nil end
    local unwrapped = unwrap(widget)
    local fn = safe_get(ui_util, "SlotAsGridSlot")
    if type(fn) == "function" then
        local ok, slot = pcall(fn, unwrapped)
        if ok and slot ~= nil then return slot end
        ok, slot = pcall(fn, widget)
        if ok then return slot end
    end
    return safe_get(widget, "Slot")
end

local function configure_grid_slot(slot, row, column, span, padding)
    if slot == nil then return end
    pcall(function() slot:SetRow(row) end)
    pcall(function() slot:SetColumn(column) end)
    pcall(function() slot:SetColumnSpan(span or 1) end)
    local eh = rawget(_G, "EHorizontalAlignment")
    local ev = rawget(_G, "EVerticalAlignment")
    if eh then pcall(function() slot:SetHorizontalAlignment(eh.HAlign_Fill) end) end
    if ev then pcall(function() slot:SetVerticalAlignment(ev.VAlign_Fill) end) end
    if padding ~= nil then pcall(function() slot:SetPadding(padding) end) end
end

local function add_grid_child(grid, widget, row, column, span, padding, ui_util)
    local raw_widget = unwrap(widget)
    local ok, slot = pcall(function() return grid:AddChildToGrid(raw_widget, row, column) end)
    if not ok or slot == nil then slot = slot_as_grid(ui_util, raw_widget) end
    configure_grid_slot(slot, row, column, span, padding)
    return slot
end

local function normalize_color(value)
    value = string.lower(tostring(value or "")):gsub("[^%w]", "")
    if value == "none" or value == "off" or value == "disabled" then return "none" end
    if value == "green" then return "green" end
    return "red"
end

local function call_global(name, ...)
    local fn = rawget(_G, name)
    if type(fn) ~= "function" then return false, nil end
    local ok, result = pcall(fn, ...)
    return ok, result
end

local function ensure_toggle_state()
    local state = rawget(_G, "custom_dongdong_toggle_state")
    if type(state) ~= "table" then
        state = {}
        rawset(_G, "custom_dongdong_toggle_state", state)
    end
    for _, key in ipairs({ "no_recoil", "converge", "aim", "anti_shake" }) do
        if state[key] == nil then state[key] = false end
    end
    return state
end

local function set_feature_local(name, enabled, view, current_grid)
    local toggles = ensure_toggle_state()
    enabled = enabled == true
    if enabled and name == "aim" then
        toggles.aim, toggles.anti_shake = true, false
    elseif enabled and name == "anti_shake" then
        toggles.anti_shake, toggles.aim = true, false
    else
        toggles[name] = enabled
    end
    call_global("set_dongdong_feature_config", name, enabled)
    if name == "aim" or name == "anti_shake" then
        delayed(0.03, function()
            if safe_get(view, "_dongdong_native_grid") == current_grid then M.build_page(view) end
        end)
    end
end

local function reapply_aim_after_slider_change()
    local revision = (tonumber(rawget(_G, "custom_dongdong_aim_slider_revision")) or 0) + 1
    rawset(_G, "custom_dongdong_aim_slider_revision", revision)
    delayed(0.18, function()
        if rawget(_G, "custom_dongdong_aim_slider_revision") ~= revision then return end
        local toggles = ensure_toggle_state()
        if toggles.aim == true then
            call_global("set_dongdong_feature_config", "aim", true)
        elseif toggles.anti_shake == true then
            call_global("set_dongdong_feature_config", "anti_shake", true)
        end
        call_global("set_dongdong_aim_part")
    end)
end

local function set_aim_part(value)
    rawset(_G, "custom_aim_target_part", value)
    if not call_global("set_dongdong_aim_part") then
        -- The payload normally exports this function. No invented engine API fallback.
    end
end

local function set_slider(global_key, value)
    rawset(_G, global_key, value)
    reapply_aim_after_slider_change()
end

local function add_sub_ui(deps, view, grid, ui_id)
    local ok, weak = pcall(function() return deps.ui_manager:AddSubUI(view, ui_id, grid) end)
    if not ok then return nil end
    return unwrap(from_weak(weak))
end

local function add_two_button(deps, view, grid, row, column, title, a, b, first_selected, cb_a, cb_b)
    local widget = add_sub_ui(deps, view, grid, deps.setting_btn_two_id)
    if widget == nil then return nil end
    pcall(function() widget:InitBtnDynamic(title, a, b, first_selected == true) end)
    pcall(function() widget:SetBtnClickByIndex(1, cb_a) end)
    pcall(function() widget:SetBtnClickByIndex(2, cb_b) end)
    local slot = safe_get(widget, "Slot") or slot_as_grid(deps.ui_util, widget)
    local left = column == 0 and 0 or 16
    local right = column == 0 and 16 or 0
    configure_grid_slot(slot, row, column, 1, make_margin(deps.import_fn, left, 13, right, 13))
    table.insert(view._dongdong_native_buttons, widget)
    return widget
end

local function make_full_width(deps, widget, row, top, bottom)
    local slot = safe_get(widget, "Slot") or slot_as_grid(deps.ui_util, widget)
    configure_grid_slot(slot, row, 0, 2, make_margin(deps.import_fn, 0, top or 13, 0, bottom or 13))
    return slot
end

local function add_four_button(deps, view, grid, row, title, selected, callbacks)
    local widget = add_sub_ui(deps, view, grid, deps.setting_btn_four_id)
    if widget == nil then return nil end
    local title_widget = safe_get(widget, "_wtTitle")
    if title_widget ~= nil then pcall(function() title_widget:SetText(title) end) end
    for i, text in ipairs({ "Head", "Chest", "Legs", "Point & Shoot" }) do
        pcall(function() widget:SetBtnTxt(i, text) end)
        pcall(function() widget:SetBtnClickByIndex(i, callbacks[i]) end)
    end
    local enum_index = math.max(0, math.min(3, (selected or 1) - 1))
    pcall(function() widget:InitSettingBtnByEume(enum_index) end)
    make_full_width(deps, widget, row, 13, 13)
    table.insert(view._dongdong_native_buttons, widget)
    return widget
end

local function add_slider(deps, view, grid, row, title, min_value, max_value, current, step, on_change)
    local widget = add_sub_ui(deps, view, grid, deps.setting_slider_id)
    if widget == nil then return nil end
    pcall(function() widget.BpTitle = title end)
    local last = math.max(min_value, math.min(max_value, math.floor((tonumber(current) or min_value) + 0.5)))
    local function changed(value)
        local next_value = math.max(min_value, math.min(max_value, math.floor((tonumber(value) or last) + 0.5)))
        if next_value == last then return end
        last = next_value
        pcall(function() widget._wtTxtValue:SetText(title .. "：" .. tostring(last)) end)
        on_change(last)
    end
    pcall(function() widget:InitSettingSlider(min_value, max_value, current, changed, changed, false, step or 1) end)
    pcall(function()
        widget._name = title
        widget._wtTxtValue:SetText(title .. "：" .. tostring(last))
    end)
    make_full_width(deps, widget, row, 13, 13)
    table.insert(view._dongdong_native_buttons, widget)
    return widget
end

local function configure_title_widget(widget, text, loc_key, font_style)
    if widget == nil then return false end
    local localized = localize(text, loc_key)
    pcall(function() widget.WBP_TitleWithLine_Name = localized end)
    pcall(function() widget["Set text"](widget, localized) end)
    local text_block = safe_get(widget, "wtDFTextBlockTitle")
    if text_block == nil then
        pcall(function() text_block = widget:GetWidgetFromName("wtDFTextBlockTitle") end)
    end
    if text_block ~= nil then
        pcall(function() text_block:SetText(localized) end)
        pcall(function() text_block:SetFontStyleID(font_style or "Header3_28pt") end)
    end
    pcall(function() widget:SynchronizeProperties() end)
    return true
end

local function hide_title_line(widget)
    if widget == nil then return end
    local line
    pcall(function() line = widget:GetWidgetFromName("Line_113") end)
    local vis = rawget(_G, "ESlateVisibility")
    if line ~= nil and vis ~= nil then pcall(function() line:SetVisibility(vis.Collapsed) end) end
end

local function finish_title_load(state, class)
    local waiters = state.title_waiters or {}
    state.title_waiters = {}
    state.title_loading = false
    if class ~= nil then state.title_class = class end
    for _, waiter in ipairs(waiters) do pcall(waiter, class) end
end

local function request_title_class(deps, state, callback)
    if type(callback) ~= "function" then return end
    if state.title_class ~= nil then callback(state.title_class); return end
    state.title_waiters = state.title_waiters or {}
    table.insert(state.title_waiters, callback)
    if state.title_loading == true then return end
    state.title_loading = true

    local resource_manager = facade_manager("ResourceManager")
    local async = safe_get(resource_manager, "AsyncLoadResource")
    if type(async) ~= "function" then finish_title_load(state, nil); return end
    local function loaded(result)
        local class
        if type(result) == "table" then class = result[M.TITLE_CLASS_PATH] end
        finish_title_load(state, class)
    end
    local ok = pcall(async, resource_manager, nil, M.TITLE_CLASS_PATH, loaded, nil)
    if not ok then ok = pcall(async, nil, M.TITLE_CLASS_PATH, loaded, nil) end
    if not ok then finish_title_load(state, nil) end
end

local function create_title_widget(deps, context, class, text, key, hide_line, font_style)
    if context == nil or class == nil then return nil end
    local creator = safe_get(deps.widget_blueprint_library, "Create")
    if type(creator) ~= "function" then return nil end
    local ok, widget = pcall(creator, unwrap(context), class, nil)
    if not ok or widget == nil then return nil end
    configure_title_widget(widget, text, key, font_style)
    if hide_line == true then hide_title_line(widget) end
    return widget
end

local function add_headers_async(deps, state, view, grid, build_token)
    request_title_class(deps, state, function(class)
        if class == nil then return end
        if safe_get(view, "_dongdong_native_grid") ~= grid then return end
        if safe_get(view, "_dongdong_native_build_token") ~= build_token then return end
        local specs = {
            { row = 0, text = M.PAGE_TITLE, key = "PageTitle", hide = true, font = "Header4_32pt", padding = {24,10,0,28} },
            { row = 1, text = "Combat", key = "FunctionSection", hide = false, font = "Header3_28pt", padding = {24,0,0,14} },
            { row = 4, text = "Visuals", key = "ColorSection", hide = false, font = "Header3_28pt", padding = {24,28,0,14} },
            { row = 7, text = "Aim Settings", key = "AdjustSection", hide = false, font = "Header3_28pt", padding = {24,28,0,14} },
        }
        for _, spec in ipairs(specs) do
            local widget = create_title_widget(deps, view, class, spec.text, spec.key, spec.hide, spec.font)
            if widget ~= nil then
                table.insert(view._dongdong_native_widgets, widget)
                local p = spec.padding
                add_grid_child(grid, widget, spec.row, 0, 2, make_margin(deps.import_fn, p[1], p[2], p[3], p[4]), deps.ui_util)
            end
        end
        pcall(function() grid:InvalidateLayoutAndVolatility() end)
    end)
end

local function resolve_dependencies()
    local ids = rawget(_G, "UIName2ID")
    local ui_table = rawget(_G, "UITable")
    local ui_manager = facade_manager("UIManager")
    local req = rawget(_G, "require") or require
    local import_fn = rawget(_G, "import")
    if type(ids) ~= "table" or ui_table == nil or ui_manager == nil or type(req) ~= "function" or type(import_fn) ~= "function" then return nil end

    local view_id = rawget(ids, "SystemSettingMainView")
    local btn2_id = rawget(ids, "SettingBtnTwo")
    local btn4_id = rawget(ids, "SettingBtnFour")
    local slider_id = rawget(ids, "SettingSlider")
    if view_id == nil or btn2_id == nil or btn4_id == nil or slider_id == nil then return nil end

    local view_class = require_table("DFM.Business.Module.SystemSettingModule.UI.SystemSettingMainView")
    local ui_util = require_table("DFM.YxFramework.Managers.UI.Util.UIUtil")
    local grid_panel = import_symbol("GridPanel")
    local scroll_box = import_symbol("ScrollBox")
    local wbl = import_symbol("WidgetBlueprintLibrary")
    local wll = import_symbol("WidgetLayoutLibrary")
    if type(view_class) ~= "table" or type(ui_util) ~= "table" or grid_panel == nil or scroll_box == nil or wbl == nil or wll == nil then return nil end

    ui_table.SubUIs = type(ui_table.SubUIs) == "table" and ui_table.SubUIs or {}
    local function add_unique(value)
        for _, existing in ipairs(ui_table.SubUIs) do if existing == value then return end end
        table.insert(ui_table.SubUIs, value)
    end
    add_unique(btn2_id); add_unique(btn4_id); add_unique(slider_id)

    return {
        ids = ids,
        ui_table = ui_table,
        ui_manager = ui_manager,
        view_class = view_class,
        view_id = view_id,
        row_id = btn2_id, -- exact P0.29.105 behavior: custom nav row id reuses SettingBtnTwo.
        setting_btn_two_id = btn2_id,
        setting_btn_four_id = btn4_id,
        setting_slider_id = slider_id,
        ui_util = ui_util,
        grid_panel = grid_panel,
        scroll_box = scroll_box,
        widget_blueprint_library = wbl,
        widget_layout_library = wll,
        import_fn = import_fn,
    }
end

local function remove_sub_ui_by_parent(deps, view, child)
    if child == nil then return end
    pcall(function() deps.ui_manager:RemoveSubUIByParent(view, child) end)
end

function M.cleanup(view, deps)
    if view == nil then return end
    deps = deps or M._deps or resolve_dependencies()
    local grid = safe_get(view, "_dongdong_native_grid")
    local scroll = safe_get(view, "_dongdong_native_scroll")
    if grid ~= nil then
        if deps ~= nil then remove_sub_ui_by_parent(deps, view, grid) end
        pcall(function() grid:RemoveFromParent() end)
    end
    if scroll ~= nil then pcall(function() scroll:RemoveFromParent() end) end
    view._dongdong_native_scroll = nil
    view._dongdong_native_grid = nil
    view._dongdong_native_buttons = nil
    view._dongdong_native_widgets = nil
    view._dongdong_native_build_token = nil
end

function M.build_page(view)
    if view == nil then return false end
    local deps = M._deps or resolve_dependencies()
    if deps == nil then return false end
    M._deps = deps
    M.cleanup(view, deps)

    local root = unwrap(from_weak(safe_get(view, "_wtRootMain")))
    if root == nil then return false end

    local ok_scroll, scroll = pcall(deps.scroll_box)
    local ok_grid, grid = pcall(deps.grid_panel)
    if not ok_scroll or scroll == nil or not ok_grid or grid == nil then return false end

    pcall(function()
        local e = rawget(_G, "EConsumeMouseWheel")
        if e then scroll:SetConsumeMouseWheel(e.WhenScrollingPossible) end
    end)
    pcall(function()
        local e = rawget(_G, "ESlateVisibility")
        if e then scroll:SetScrollBarVisibility(e.Collapsed) end
    end)
    pcall(function() scroll:SetAnimateWheelScrolling(true) end)
    pcall(function() deps.ui_util.AddWidgetToParent_Full(scroll, root) end)
    pcall(function() grid:SetColumnFill(0, 1.0); grid:SetColumnFill(1, 1.0) end)

    local scroll_slot
    pcall(function() scroll_slot = scroll:AddChild(grid) end)
    if scroll_slot ~= nil then
        local eh = rawget(_G, "EHorizontalAlignment")
        local ev = rawget(_G, "EVerticalAlignment")
        if eh then pcall(function() scroll_slot:SetHorizontalAlignment(eh.HAlign_Fill) end) end
        if ev then pcall(function() scroll_slot:SetVerticalAlignment(ev.VAlign_Top) end) end
    end

    view._dongdong_native_scroll = scroll
    view._dongdong_native_grid = grid
    view._dongdong_native_buttons = {}
    view._dongdong_native_widgets = {}
    local build_token = {}
    view._dongdong_native_build_token = build_token

    local toggles = ensure_toggle_state()
    add_two_button(deps, view, grid, 2, 0, "No Recoil", "Enable", "Disable", toggles.no_recoil,
        function() set_feature_local("no_recoil", true, view, grid) end,
        function() set_feature_local("no_recoil", false, view, grid) end)
    add_two_button(deps, view, grid, 2, 1, "Bullet Spread Control", "Enable", "Disable", toggles.converge,
        function() set_feature_local("converge", true, view, grid) end,
        function() set_feature_local("converge", false, view, grid) end)
    add_two_button(deps, view, grid, 3, 0, "Hip-Fire Aim", "Enable", "Disable", toggles.aim,
        function() set_feature_local("aim", true, view, grid) end,
        function() set_feature_local("aim", false, view, grid) end)
    add_two_button(deps, view, grid, 3, 1, "ADS Aim", "Enable", "Disable", toggles.anti_shake,
        function() set_feature_local("anti_shake", true, view, grid) end,
        function() set_feature_local("anti_shake", false, view, grid) end)

    local ai_key = normalize_color(rawget(_G, "custom_ai_color_key"))
    local ai_enabled = ai_key ~= "none"
    local ai_display_key = ai_key
    if ai_display_key == "none" then ai_display_key = normalize_color(rawget(_G, "custom_ai_color_last_key") or "red") end
    local player_key = normalize_color(rawget(_G, "custom_real_color_key") or "green")

    add_two_button(deps, view, grid, 5, 0, "Bot Highlight", "Enable", "Disable", ai_enabled,
        function()
            local key = normalize_color(rawget(_G, "custom_ai_color_last_key") or ai_display_key or "red")
            call_global("set_ai_color", key)
        end,
        function() call_global("set_ai_color", "none") end)
    add_two_button(deps, view, grid, 5, 1, "Bot Color", "Red", "Green", ai_display_key == "red",
        function()
            rawset(_G, "custom_ai_color_last_key", "red")
            if normalize_color(rawget(_G, "custom_ai_color_key")) ~= "none" then call_global("set_ai_color", "red") end
        end,
        function()
            rawset(_G, "custom_ai_color_last_key", "green")
            if normalize_color(rawget(_G, "custom_ai_color_key")) ~= "none" then call_global("set_ai_color", "green") end
        end)
    add_two_button(deps, view, grid, 6, 0, "Player Color", "Red", "Green", player_key == "red",
        function() call_global("set_real_player_color", "red") end,
        function() call_global("set_real_player_color", "green") end)
    add_two_button(deps, view, grid, 6, 1, "Player X-Ray", "Enable", "Disable", rawget(_G, "custom_character_xray_enabled") == true,
        function() call_global("set_character_xray", true) end,
        function() call_global("set_character_xray", false) end)

    local part = rawget(_G, "custom_aim_target_part") or "head"
    if part == "miss" then part = "free" end
    rawset(_G, "custom_aim_target_part", part)
    local selected = ({ head = 1, chest = 2, leg = 3, free = 4 })[part] or 1
    add_four_button(deps, view, grid, 8, "Target Bone", selected, {
        function() set_aim_part("head") end,
        function() set_aim_part("chest") end,
        function() set_aim_part("leg") end,
        function() set_aim_part("free") end,
    })

    local speed = tonumber(rawget(_G, "custom_aim_speed")) or 50
    local fov = tonumber(rawget(_G, "custom_aim_range")) or 90
    local distance = tonumber(rawget(_G, "custom_aim_distance")) or 150
    local lock_time = tonumber(rawget(_G, "custom_aim_lock_time")) or 1
    rawset(_G, "custom_aim_speed", speed)
    rawset(_G, "custom_aim_range", fov)
    rawset(_G, "custom_aim_distance", distance)
    rawset(_G, "custom_aim_lock_time", lock_time)

    add_slider(deps, view, grid, 9, "Aim Speed", 1, 100, speed, 1, function(v) set_slider("custom_aim_speed", v) end)
    add_slider(deps, view, grid, 10, "Aim FOV", 1, 360, fov, 1, function(v) set_slider("custom_aim_range", v) end)
    add_slider(deps, view, grid, 11, "Aim Distance", 1, 500, distance, 1, function(v) set_slider("custom_aim_distance", v) end)
    add_slider(deps, view, grid, 12, "Aim Lock Delay", 1, 100, lock_time, 1, function(v) set_slider("custom_aim_lock_time", v) end)

    add_headers_async(deps, M._state, view, grid, build_token)
    pcall(function() view._wtResetPanel:Visible() end)
    pcall(function() view._wtResourceFixBtn:Collapsed() end)
    pcall(function() view:_ShowCloudBtn() end)
    return true
end

local function remove_existing_direct_tab(view, deps)
    local nav = safe_get(view, "_uiNavIDList")
    local tabs = safe_get(view, "_tabTable")
    if type(nav) ~= "table" or type(tabs) ~= "table" then return nil end
    local found
    for i = #nav, 1, -1 do
        local desc = tabs[i]
        if nav[i] == deps.row_id and type(desc) == "table" and desc.__dongdong_native_direct == true then
            if found == nil then found = desc end
            table.remove(nav, i); table.remove(tabs, i)
        end
    end
    return found
end

local function add_custom_tab(view, direct, deps)
    local nav = safe_get(view, "_uiNavIDList")
    local tabs = safe_get(view, "_tabTable")
    if type(nav) ~= "table" or type(tabs) ~= "table" then return false end
    local descriptor = remove_existing_direct_tab(view, deps) or {}
    descriptor.keyText = M.PAGE_TITLE
    descriptor.__dongdong_native_direct = true
    local index = direct == true and 1 or (#nav + 1)
    table.insert(nav, index, deps.row_id)
    table.insert(tabs, index, descriptor)
    M._state.tab_index = index
    pcall(function() deps.ui_manager:RegSwitchSubUI(view, nav) end)
    return true
end

local function is_custom_tab(view, requested, deps)
    local nav = safe_get(view, "_uiNavIDList")
    local tabs = safe_get(view, "_tabTable")
    local index = (tonumber(requested) or -1) + 1
    local desc = type(tabs) == "table" and tabs[index] or nil
    return type(nav) == "table"
        and nav[index] == deps.row_id
        and type(desc) == "table"
        and desc.__dongdong_native_direct == true
end

local function remove_native_root(deps, view)
    pcall(function() deps.ui_manager:RemoveSubUIByParent(view, view._wtRootMain) end)
end

local function make_generic_wrapper(class, method_name, before, after, state)
    local original = safe_get(class, method_name)
    if type(original) ~= "function" then return false end
    local prior = state.wrappers[method_name]
    if type(prior) == "table" and original == prior.wrapper then return true end

    local entry = { original = original }
    entry.wrapper = function(self, ...)
        local args = pack(...)
        if type(before) == "function" then pcall(before, self, args) end
        local results = pack(pcall(function() return original(self, unpack_values(args, 1, args.n)) end))
        local ok = results[1]
        if not ok then error(results[2], 0) end
        if type(after) == "function" then pcall(after, self, args) end
        return unpack_values(results, 2, results.n)
    end
    class[method_name] = entry.wrapper
    state.wrappers[method_name] = entry
    return safe_get(class, method_name) == entry.wrapper
end

local function restore_wrappers(class, wrappers)
    if type(class) ~= "table" or type(wrappers) ~= "table" then return end
    for method, entry in pairs(wrappers) do
        if type(entry) == "table" and type(entry.original) == "function" then
            if safe_get(class, method) == entry.wrapper then class[method] = entry.original end
        end
    end
end

local function install_hooks(deps, state)
    local class = deps.view_class
    local count = 0
    if make_generic_wrapper(class, "_InitDynamicBtns", nil, function(self) add_custom_tab(self, false, deps) end, state) then count = count + 1 end
    if make_generic_wrapper(class, "SetSelectedModePanel", function(self) add_custom_tab(self, false, deps) end,
        function(self) add_custom_tab(self, true, deps) end, state) then count = count + 1 end
    if make_generic_wrapper(class, "OnInitExtraData", nil, function(self) self._tabType = 1 end, state) then count = count + 1 end
    if make_generic_wrapper(class, "OnShowBegin", function(self) add_custom_tab(self, true, deps); self._tabType = 1 end,
        function(self) add_custom_tab(self, true, deps); self._tabType = 1 end, state) then count = count + 1 end
    if make_generic_wrapper(class, "OnActivate", nil, function(self) add_custom_tab(self, true, deps) end, state) then count = count + 1 end

    local original_fetch = safe_get(class, "_FetchSettingSystemByTab")
    if type(original_fetch) == "function" then
        local entry = { original = original_fetch }
        entry.wrapper = function(self, requested, ...)
            if is_custom_tab(self, requested, deps) then
                self._tabType = (tonumber(requested) or 0) + 1
                remove_native_root(deps, self)
                M.build_page(self)
                return
            end
            M.cleanup(self, deps)
            return original_fetch(self, requested, ...)
        end
        class._FetchSettingSystemByTab = entry.wrapper
        state.wrappers._FetchSettingSystemByTab = entry
        count = count + 1
    end

    local original_update = safe_get(class, "_UpdateSysetemSettingPanel")
    if type(original_update) == "function" then
        local entry = { original = original_update }
        entry.wrapper = function(self, ...)
            if is_custom_tab(self, (tonumber(self._tabType) or 1) - 1, deps) then
                remove_native_root(deps, self)
                M.build_page(self)
                return
            end
            M.cleanup(self, deps)
            return original_update(self, ...)
        end
        class._UpdateSysetemSettingPanel = entry.wrapper
        state.wrappers._UpdateSysetemSettingPanel = entry
        count = count + 1
    end

    if make_generic_wrapper(class, "OnHideBegin", function(self) M.cleanup(self, deps) end, nil, state) then count = count + 1 end
    if make_generic_wrapper(class, "OnClose", function(self) M.cleanup(self, deps) end, nil, state) then count = count + 1 end
    return count
end

M._state = {
    wrappers = {},
    installed = false,
    hook_count = 0,
    title_waiters = {},
    title_loading = false,
    title_class = nil,
}

function M.install()
    if M._state.installed == true and M._state.hook_count == M.REQUIRED_HOOK_COUNT then
        return M._state.hook_count
    end
    local deps = resolve_dependencies()
    if deps == nil then return 0 end
    M._deps = deps

    -- If the bytecode payload installed P0.29.105 first, replace it only after all
    -- dependencies are resolved. Restore only methods that still equal the recorded wrapper.
    local payload_state = rawget(_G, "custom_dongdong_api_settings")
    local old_wrappers = type(payload_state) == "table" and payload_state.wrappers or nil
    if type(old_wrappers) == "table" then restore_wrappers(deps.view_class, old_wrappers) end

    local new_state = {
        wrappers = {}, installed = false, hook_count = 0,
        title_waiters = M._state.title_waiters or {}, title_loading = M._state.title_loading == true,
        title_class = M._state.title_class,
    }
    local count = install_hooks(deps, new_state)
    new_state.hook_count = count
    new_state.row_id = deps.row_id
    new_state.installed = count == M.REQUIRED_HOOK_COUNT

    if not new_state.installed then
        restore_wrappers(deps.view_class, new_state.wrappers)
        -- Put previous bytecode wrappers back if they were removed.
        if type(old_wrappers) == "table" then
            for method, entry in pairs(old_wrappers) do
                if type(entry) == "table" and type(entry.wrapper) == "function" then
                    deps.view_class[method] = entry.wrapper
                end
            end
        end
        return 0
    end

    M._state = new_state
    rawset(_G, "custom_dongdong_api_settings", new_state)
    rawset(_G, "custom_character_color_setting_hook_count", count)
    rawset(_G, "InstallDongDongNativeSettingPage", M.install)
    return count
end

function M.takeover_after_payload_load()
    local count = M.install()
    if count ~= 0 then return true, count end
    -- Mirrors the finite retry windows present in P0.29 without creating a UI watchdog.
    for _, delay in ipairs({ 0.4, 1.2, 2.8 }) do
        delayed(delay, function()
            if M._state.installed ~= true then M.install() end
        end)
    end
    return false, 0
end

function M.get_catalog()
    return {
        prototype = M.PROTOTYPE,
        page_title = M.PAGE_TITLE,
        baseline_page_title = M.BASELINE_PAGE_TITLE,
        hook_methods = M.HOOK_METHODS,
        controls = M.UI_MODEL,
    }
end

end)(S)
-- END native_settings_ui.lua

-- BEGIN payload_feature_bridge.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local FeatureControl = assert(S.FeatureControl, "FeatureControl required")
local Mutation = assert(S.MutationRuntime, "MutationRuntime required")
local M = {}
S.PayloadFeatureBridge = M

M.PROTOTYPE_GROUP = { "0.29.17", "0.29.26", "0.29.29", "0.29.67", "0.29.68" }

local original_feature_config
local installed = false

local function call_original(...)
    if type(original_feature_config) ~= "function" then return false end
    local ok, value = pcall(original_feature_config, ...)
    if ok then return value end
    return false
end

function M.takeover_after_payload_load()
    if installed then return true end
    original_feature_config = rawget(_G, "set_dongdong_feature_config")
    if type(original_feature_config) ~= "function" then return false, "original feature function missing" end

    local deps = {
        restore_feature_snapshot = function(feature)
            return Mutation.restore_feature_snapshot(_G, feature)
        end,
        apply_feature = function(feature)
            return Mutation.apply_feature(_G, feature)
        end,
        -- These branches are not reached by the D3 source-owned features.
        restore_bone_array_snapshots = function()
            return Mutation.restore_bone_array_snapshots(_G)
        end,
        set_native_aim_assist = function() return false end,
        set_fire_assisted_aim_debug = function() return false end,
    }

    rawset(_G, "set_dongdong_feature_config", function(feature, enabled)
        if feature == "no_recoil" or feature == "converge" then
            return FeatureControl.set_dongdong_feature_config(_G, deps, feature, enabled)
        end
        return call_original(feature, enabled)
    end)
    installed = true
    return true
end

function M.restore_original()
    if installed and type(original_feature_config) == "function" then
        rawset(_G, "set_dongdong_feature_config", original_feature_config)
    end
    installed = false
    return true
end

function M.status()
    return { installed=installed, partial_takeover={no_recoil=true, converge=true, aim=false, anti_shake=false} }
end

return M

end)(S)
-- END payload_feature_bridge.lua

-- BEGIN payload_visual_bridge.lua
;(function(...)
local S = ...
assert(type(S)=="table","spectra module table required")
local CV=assert(S.CharacterVisuals,"CharacterVisuals required")
local VS=assert(S.VisualScan,"VisualScan required")
local VR=assert(S.VisualRuntime,"VisualRuntime required")
local Runtime=assert(S.Runtime,"Runtime required")
local M={}; S.PayloadVisualBridge=M
local original={}; local installed=false

local function deps()
    return {
        restore_mesh_category=function(category) return VS.restore_mesh_category(_G,category) end,
        restore_mesh_snapshot=VS.restore_mesh_snapshot,
        new_weak_mesh_table=VR.new_weak_mesh_table,
        rescan_character_colors=function() return VS.rescan_character_colors(_G,Runtime.delay) end,
    }
end
function M.takeover_after_payload_load()
    if installed then return true end
    original.set_ai_color=rawget(_G,"set_ai_color")
    original.set_real_player_color=rawget(_G,"set_real_player_color")
    original.set_character_xray=rawget(_G,"set_character_xray")
    if type(original.set_ai_color)~="function" or type(original.set_real_player_color)~="function" or type(original.set_character_xray)~="function" then
        return false,"original visual globals missing"
    end
    local d=deps()
    rawset(_G,"set_ai_color",function(v) return CV.set_ai_color(_G,d,v) end)
    rawset(_G,"set_real_player_color",function(v) return CV.set_real_player_color(_G,d,v) end)
    rawset(_G,"set_character_xray",function(v) return CV.set_character_xray(_G,d,v) end)
    local hook_ok=VS.install_fashion_refresh_hook(_G,Runtime.delay)
    local tick_ok=VS.install_tick(_G)
    if not tick_ok then VS.fallback_scan_loop(_G,Runtime.delay,0) end
    _G._spectra_visual_hook_source_owned = hook_ok == true
    _G._spectra_visual_tick_source_owned = tick_ok == true
    installed=true; return true
end
function M.restore_original()
    if installed then for k,v in pairs(original) do if type(v)=="function" then rawset(_G,k,v) end end end
    installed=false; return true
end
function M.status() return {installed=installed, public_visuals_source_owned=installed, fashion_hook_source_owned=_G._spectra_visual_hook_source_owned==true, tick_source_owned=_G._spectra_visual_tick_source_owned==true} end
return M

end)(S)
-- END payload_visual_bridge.lua

-- BEGIN payload_ui_bridge.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")
local UI = assert(S.NativeSettingsUI, "NativeSettingsUI module required")
local M = {}
S.PayloadUIBridge = M

function M.after_payload_load()
    local ui_ok = UI.takeover_after_payload_load()
    local feature_ok = true
    if type(S.PayloadFeatureBridge) == "table" and type(S.PayloadFeatureBridge.takeover_after_payload_load) == "function" then
        feature_ok = S.PayloadFeatureBridge.takeover_after_payload_load()
    end
    local visual_ok = true
    if type(S.PayloadVisualBridge) == "table" and type(S.PayloadVisualBridge.takeover_after_payload_load) == "function" then
        visual_ok = S.PayloadVisualBridge.takeover_after_payload_load()
    end
    return ui_ok and feature_ok and visual_ok
end

end)(S)
-- END payload_ui_bridge.lua

-- BEGIN payload_loader.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local Crypto = assert(S.Crypto, "Crypto module required")
local M = {}
S.PayloadLoader = M

local state = Runtime.get_state()

function M.load_once()
    if state._s2 == true then
        return true
    end
    if state._s1 ~= true then
        return false
    end

    local encoded = S.PayloadBase64
    if type(encoded) ~= "string" or encoded == "" then
        state._sb = "embedded_payload_missing"
        Runtime.show_tip("Module loading failed", 4)
        return false
    end

    local bytes, decode_err = Crypto.base64_decode(encoded)
    if type(bytes) ~= "string" then
        state._sb = tostring(decode_err or "embedded_payload_decode_failed")
        Runtime.show_tip("Module loading failed", 4)
        return false
    end

    local chunk, load_err = load(bytes, "@spectra-product", "b", _G)
    if type(chunk) ~= "function" then
        state._sb = tostring(load_err)
        Runtime.show_tip("Module loading failed", 4)
        return false
    end

    local ok, result = pcall(chunk)
    if not ok then
        state._sb = tostring(result)
        Runtime.show_tip("Module startup failed", 4)
        return false
    end

    state._s2 = true
    state.product = result
    state._sb = nil

    -- Phase-D can replace only the reconstructed native settings UI after the
    -- byte-identical payload has initialized its feature globals. Phase-C omits
    -- PayloadUIBridge, so this branch is behavior-neutral there.
    if type(S.PayloadUIBridge) == "table" and type(S.PayloadUIBridge.after_payload_load) == "function" then
        local bridge_ok, bridge_err = pcall(S.PayloadUIBridge.after_payload_load)
        if not bridge_ok then
            state._payload_ui_bridge_error = tostring(bridge_err)
        else
            state._payload_ui_bridge_error = nil
        end
    end

    -- Baseline releases the captured Base64 after successful startup.
    S.PayloadBase64 = nil
    S.PayloadBase64Chunks = nil
    return true
end

end)(S)
-- END payload_loader.lua

-- BEGIN auth.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local Crypto = assert(S.Crypto, "Crypto module required")
local Storage = assert(S.Storage, "Storage module required")
local Transport = assert(S.Transport, "Transport module required")
local PayloadLoader = assert(S.PayloadLoader, "PayloadLoader module required")

local M = {}
S.Auth = M

M.APP_ID = "71438"
M.REQUEST_SIGN_SECRET = "f052b3414cc670a954ab10a"
M.RC4_KEY = "gddbf544aa9a227c85f"
M.BASE_URL = "https://zxx.spwz.online/connect/kmlogon"
M.SUCCESS_CODE = 73913
M.FRESHNESS_SECONDS = 30

local state = Runtime.get_state()

local function make_challenge()
    local timestamp = tostring(Runtime.get_timestamp())
    local random_fn = type(math) == "table" and math.random or nil
    if type(random_fn) == "function" then
        local ok, value = pcall(random_fn, 1000, 99999)
        if ok and type(value) == "number" then
            return tostring(math.floor(value)) .. timestamp
        end
    end

    local seed = Crypto.md5(timestamp .. "|" .. tostring({}) .. "|" .. M.APP_ID)
    local n = tonumber(seed:sub(1, 8), 16) or 0
    n = (n % 99000) + 1000
    return tostring(n) .. timestamp
end

function M.build_request(card, device_id, secret_override)
    card = tostring(card)
    device_id = tostring(device_id)
    local timestamp = tostring(Runtime.get_timestamp())
    local value = make_challenge()
    local secret = tostring(secret_override or M.REQUEST_SIGN_SECRET)

    local sign_source = table.concat({
        "kami=", card,
        "&markcode=", device_id,
        "&t=", timestamp,
        "&", secret,
    })
    local sign = Crypto.md5(sign_source):lower()

    local plaintext = table.concat({
        "kami=", card,
        "&markcode=", device_id,
        "&t=", timestamp,
        "&sign=", sign,
        "&value=", value,
    })

    local encrypted = Crypto.rc4_encrypt_hex(plaintext, tostring(M.RC4_KEY))
    local sep = M.BASE_URL:find("?", 1, true) and "&" or "?"
    local url = M.BASE_URL
        .. sep .. "id=kmlogon"
        .. "&app=" .. Crypto.url_encode(M.APP_ID)
        .. "&data=" .. encrypted

    local diagnostic = {
        card = card,
        device_id = device_id,
        timestamp = tonumber(timestamp),
        value = value,
        sign = sign,
        _c1 = secret,
        signature_rule = "official_https_get_diagnostic",
        card_byte_length = #card,
        card_hex = Crypto.hex_lower(card),
        card_md5 = Crypto.md5(card),
        device_byte_length = #device_id,
        device_md5 = Crypto.md5(device_id),
        sign_source_length = #sign_source,
        sign_source_md5 = Crypto.md5(sign_source),
        inner_data_length = #plaintext,
        inner_data_md5 = Crypto.md5(plaintext),
        encrypted_length = #encrypted,
        encrypted_md5 = Crypto.md5(encrypted),
        url_length = #url,
        transport_scheme = "HTTPS",
    }
    return url, diagnostic
end

local function complete(on_result, ok, kind, message, data)
    if type(on_result) == "function" then
        pcall(on_result, ok, kind, message, data)
    end
end

local function fail(on_result, kind, message, severity)
    state._s7 = false
    state._sb = tostring(message or "")
    Runtime.show_tip(message, severity or 4)
    complete(on_result, false, kind, message, nil)
    return false
end

function M.authenticate(card, on_result)
    card = Runtime.normalize_card(card)

    if state._s7 == true then
        Runtime.show_tip("Verification request in progress", 2)
        complete(on_result, false, "busy", "Verification request in progress", nil)
        return false
    end
    if card == "" then
        Runtime.show_tip("Enter license key", 3)
        complete(on_result, false, "empty_key", "Enter license key", nil)
        return false
    end

    if state._c7 == nil then
        state._c7 = Crypto.self_test()
    end
    if state._c7 ~= true then
        Runtime.show_tip("Crypto self-test failed", 4)
        complete(on_result, false, "crypto_self_test", "Crypto self-test failed", nil)
        return false
    end

    local device_id, device_err = Runtime.get_device_id()
    if device_id == nil or device_id == "" then
        -- Baseline would fall into request building with nil here. The clean source
        -- fails explicitly instead of manufacturing a device identifier.
        return fail(on_result, "device_id", tostring(device_err or "Unable to read device ID"), 4)
    end

    state._s7 = true
    Runtime.show_tip("Establishing secure connection", 2)

    local url, diagnostic = M.build_request(card, device_id)
    state._sc = {
        time = diagnostic.timestamp,
        value = diagnostic.value,
        device = device_id,
        sign = diagnostic.sign,
    }

    local request_timestamp = diagnostic.timestamp
    local request_value = diagnostic.value
    local tag = "login-" .. tostring(request_timestamp)

    local started = Transport.get(tag, url, function(ok, body, err)
        state._s7 = false

        if not ok then
            local text = Runtime.trim(err)
            if text == "" then text = "Network request failed" end
            state._sb = tostring(err)
            Runtime.show_tip("Connection failed: " .. text, 5)
            complete(on_result, false, "network", text, nil)
            return
        end

        local encrypted_response = Crypto.hex_decode(body)
        if encrypted_response == nil then
            state._sb = "response_not_hex"
            Runtime.show_tip("Invalid server response format", 4)
            complete(on_result, false, "response_format", "Invalid server response format", nil)
            return
        end

        local plaintext = Crypto.rc4(encrypted_response, M.RC4_KEY)
        local response = Runtime.parse_json(plaintext)
        state._sd = response

        if type(response) ~= "table" or tonumber(response.code) ~= M.SUCCESS_CODE then
            local message = Runtime.server_message(response)
            Runtime.show_tip("Verification failed: " .. message, 4)
            complete(on_result, false, "server_reject", message, response)
            return
        end

        local response_time = math.floor(tonumber(response.time) or 0)
        if response_time <= 0
            or math.abs(response_time - request_timestamp) > M.FRESHNESS_SECONDS then
            Runtime.show_tip("Verification failed: response expired", 4)
            complete(on_result, false, "response_freshness", "response expired", response)
            return
        end

        local expected_check = Crypto.md5(
            tostring(response_time) .. M.REQUEST_SIGN_SECRET .. request_value
        )
        local actual_check = tostring(response.check):lower()
        if actual_check ~= expected_check then
            Runtime.show_tip("Verification failed: data check failed", 4)
            complete(on_result, false, "response_check", "data check failed", response)
            return
        end

        state._s1 = true
        state.card = card
        state._se = response
        state._sb = nil
        Storage.set_card(card)

        if S.LoginUI and type(S.LoginUI.close) == "function" then
            S.LoginUI.close()
        end

        local loaded = PayloadLoader.load_once()
        if loaded then
            Runtime.show_tip("SPECTRA verification successful", 4)
            complete(on_result, true, "success", "SPECTRA verification successful", response)
        else
            complete(on_result, false, "payload_load", tostring(state._sb or "Module startup failed"), response)
        end
    end)

    if not started then
        state._s7 = false
        return false
    end
    return true
end

end)(S)
-- END auth.lua

-- BEGIN login_ui.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local Storage = assert(S.Storage, "Storage module required")
local M = {}
S.LoginUI = M

local state = Runtime.get_state()

local function ui_manager()
    local facade = rawget(_G, "Facade")
    return Runtime.safe_get(facade, "UIManager") or rawget(_G, "UIManager")
end

local function ui_id(name)
    return Runtime.safe_get(rawget(_G, "UIName2ID"), name)
end

local function clear_login_refs()
    state.login_ui = nil
    state.login_handle = nil
    state._s5 = false
    state._s6 = false
end

function M.is_live()
    local widget = state.login_ui
    if widget == nil then
        return false
    end

    -- No IsValid-style engine API is present in the baseline. Probe only fields
    -- that the baseline itself accesses; a destroyed userdata normally fails here.
    local inner = Runtime.safe_get(widget, "_wtCommonPopWinV2")
    if inner == nil then
        return false
    end
    return type(Runtime.safe_get(inner, "SetTitle")) == "function"
end

function M.close()
    local manager = ui_manager()
    local close_fn = Runtime.safe_get(manager, "CloseUI")
    if type(close_fn) == "function" and state.login_ui ~= nil then
        pcall(close_fn, manager, state.login_ui)
    end
    clear_login_refs()
end

local function configure_widget(widget, CommonPopWindows, center_confirm)
    state.login_ui = widget
    state._s5 = widget ~= nil
    state._s6 = false

    if widget == nil then
        return
    end

    local pop = Runtime.safe_get(widget, "_wtCommonPopWinV2")
    if pop == nil then
        return
    end

    local set_title = Runtime.safe_get(pop, "SetTitle")
    if type(set_title) == "function" then
        pcall(set_title, pop, "License Verification")
    end

    local handle_type = Runtime.safe_get(
        Runtime.safe_get(CommonPopWindows, "EHandleBtnType"),
        "Confirm"
    ) or 2

    local buttons = {}
    buttons[handle_type] = {
        btnText = "Unlock",
        fClickCallback = function()
            local input = Runtime.safe_get(widget, "_wt_WBP_inputBox")
            local get_text = Runtime.safe_get(input, "GetText")
            local card = ""
            if type(get_text) == "function" then
                local ok, value = pcall(get_text, input)
                if ok then card = value end
            end
            if S.Auth and type(S.Auth.authenticate) == "function" then
                S.Auth.authenticate(card)
            end
        end,
        caller = widget,
        bNeedClose = false,
        bNeedDeClose = false,
    }

    local set_buttons = Runtime.safe_get(pop, "SetConfirmBtnType")
    if type(set_buttons) == "function" then
        pcall(set_buttons, pop, center_confirm, buttons, true)
    end

    local set_close = Runtime.safe_get(pop, "SetPopIsOnClose")
    if type(set_close) == "function" then
        pcall(set_close, pop, false)
    end

    local set_background = Runtime.safe_get(pop, "SetBackgroudClickable")
    if type(set_background) == "function" then
        pcall(set_background, pop, false)
    end

    local collapse_close = Runtime.safe_get(pop, "CollapseCloseBtn")
    if type(collapse_close) == "function" then
        pcall(collapse_close, pop)
    end
end

function M.open_license(force)
    if state._s1 == true then
        return true
    end

    if M.is_live() then
        state._s5 = true
        return true
    end

    -- Stale flags/handles must never block a manual reopen.
    state.login_ui = nil
    state.login_handle = nil
    state._s5 = false
    if force then
        state._s6 = false
    elseif state._s6 == true then
        return true
    end

    local ok_param_mod, CommonRenameUIParam =
        pcall(require, "DFM.Business.DataStruct.CommonWidgetStruct.CommonRenameUIParam")
    local ok_pop_mod, CommonPopWindows =
        pcall(require, "DFM.Business.Module.CommonWidgetModule.UI.CommonPopWindows")

    local manager = ui_manager()
    local id = ui_id("CommonRenamePopWindows")
    local async_show = Runtime.safe_get(manager, "AsyncShowUI")
    local default_ctor = ok_param_mod and Runtime.safe_get(CommonRenameUIParam, "Default") or nil

    if not ok_param_mod
        or not ok_pop_mod
        or type(default_ctor) ~= "function"
        or id == nil
        or type(async_show) ~= "function" then
        return false
    end

    local ok_param, param = pcall(default_ctor)
    if not ok_param or param == nil then
        return false
    end

    Runtime.try_method(param, "SetTitle", "License Verification")
    Runtime.try_method(param, "SetContent", "Enter your license key to unlock")
    Runtime.try_method(param, "SetInputBoxHintText", "Enter license key")
    Runtime.try_method(param, "SetInputBoxText", Storage.get_card())

    local center_confirm = Runtime.safe_get(
        Runtime.safe_get(CommonPopWindows, "EConfirmBtnType"),
        "CenterConfirm"
    ) or 1
    Runtime.try_method(param, "SetConfirmBtnType", center_confirm)

    local set_callback = Runtime.safe_get(param, "SetCallback")
    if type(set_callback) == "function" then
        pcall(set_callback, param, function(card)
            if S.Auth and type(S.Auth.authenticate) == "function" then
                S.Auth.authenticate(card)
            end
        end)
    end

    state._s6 = true
    local ok_show, handle = pcall(
        async_show,
        manager,
        id,
        function(widget)
            configure_widget(widget, CommonPopWindows, center_confirm)
        end,
        nil,
        param
    )

    if not ok_show then
        state._s6 = false
        state._sb = tostring(handle)
        return false
    end

    state.login_handle = handle
    return true
end

-- Legacy/manual welcome. Automatic bootstrap never calls this, so ConfirmWindows
-- is no longer coupled to account-login -> Lobby transition.
function M.open_control()
    if state._s1 == true then
        return true
    end
    if state._s3 == true or state._s4 == true or M.is_live() or state._s6 == true then
        return true
    end

    local manager = ui_manager()
    local id = ui_id("ConfirmWindows")
    local async_show = Runtime.safe_get(manager, "AsyncShowUI")
    if manager == nil or id == nil or type(async_show) ~= "function" then
        return false
    end

    local unlock = function()
        state._s3 = false
        state._s4 = false
        Runtime.delay(0.2, function()
            M.open_license(true)
        end)
    end
    local later = function()
        state._s3 = false
        state._s4 = false
    end

    state._s4 = true
    local ok, handle = pcall(
        async_show,
        manager,
        id,
        nil,
        nil,
        "@DrkZeref  ",
        "This device is locked\nConnect securely and verify your license key to continue",
        unlock,
        later,
        "Later",
        "Unlock",
        nil, nil, nil, nil, nil, nil,
        false,
        true,
        nil
    )
    state._s4 = false

    if ok then
        state._s3 = true
        state.entry_handle = handle
        return true
    end
    state._sb = tostring(handle)
    return false
end

end)(S)
-- END login_ui.lua

-- BEGIN bootstrap.lua
;(function(...)
local S = ...
assert(type(S) == "table", "spectra module table required")

local Runtime = assert(S.Runtime, "Runtime module required")
local Storage = assert(S.Storage, "Storage module required")
local Auth = assert(S.Auth, "Auth module required")
local LoginUI = assert(S.LoginUI, "LoginUI module required")

local M = {}
S.Bootstrap = M

local state = Runtime.get_state()

-- These values are not a UI watchdog. They are a finite listener-registration
-- fallback using the same 1 s / 60 attempt envelope present in the baseline.
local LOBBY_BIND_RETRY_SECONDS = 1.0
local LOBBY_BIND_RETRY_LIMIT = 60

local function initialize_state()
    if state._s0 == true then
        return false
    end
    state._s0 = true
    state._s1 = false
    state._s2 = false
    state._s3 = false
    state._s4 = false
    state._s5 = false
    state._s6 = false
    state._s7 = false
    state._s8 = 0
    state._s9 = type(state._s9) == "table" and state._s9 or {}
    state._sa = type(state._sa) == "table" and state._sa or {}
    state._sb = nil
    state._sc = nil
    state._sd = nil
    state._se = nil
    state.lobby_ready = false
    state.lobby_listener = nil
    state.lobby_listener_registered = false
    state.lobby_bind_retry_count = 0
    state.lobby_bind_retry_scheduled = false
    state.saved_key_invalid = false
    return true
end

local function is_lobby_ready_now()
    -- Verified in embedded payload prototypes 0.0 and 0.11.
    local facade = rawget(_G, "Facade")
    local manager = Runtime.safe_get(facade, "GameFlowManager")
    local get_current = Runtime.safe_get(manager, "GetCurrentGameFlow")
    local stage_type = rawget(_G, "EGameFlowStageType")
    local lobby = Runtime.safe_get(stage_type, "Lobby")
    if type(get_current) ~= "function" or lobby == nil then
        return false
    end
    local ok, current = pcall(get_current, manager)
    return ok and current == lobby
end

local function open_login_if_ready()
    if state._s1 == true or state._s7 == true then
        return
    end
    if state.lobby_ready == true then
        LoginUI.open_license(false)
    end
end

local function on_lobby_ready()
    state.lobby_ready = true
    Runtime.delay(0.6, open_login_if_ready)
end

local function register_lobby_listener()
    if state.lobby_listener_registered == true then
        return true
    end

    local ok, events = pcall(require, "DFM.BusinessEntrance.EntranceGlobalEvents")
    local event = ok and Runtime.safe_get(events, "evtLobbyBusinessInit") or nil
    local add_listener = Runtime.safe_get(event, "AddListener")
    if event == nil or type(add_listener) ~= "function" then
        state._sb = "evtLobbyBusinessInit unavailable"
        return false
    end

    local callback = function()
        on_lobby_ready()
    end
    local ok_add = pcall(add_listener, event, callback)
    if ok_add then
        state.lobby_listener = callback
        state.lobby_listener_registered = true
        state._sb = nil
    end
    return ok_add
end

local function can_schedule_delay()
    local timer = rawget(_G, "Timer")
    return type(Runtime.safe_get(timer, "DelayCall")) == "function"
end

local ensure_lobby_watcher

local function schedule_lobby_bind_retry()
    if state.lobby_bind_retry_scheduled == true
        or state.lobby_listener_registered == true
        or state.lobby_ready == true
        or state._s1 == true
        or state.lobby_bind_retry_count >= LOBBY_BIND_RETRY_LIMIT
        or not can_schedule_delay() then
        return false
    end

    state.lobby_bind_retry_scheduled = true
    local scheduled = Runtime.delay(LOBBY_BIND_RETRY_SECONDS, function()
        state.lobby_bind_retry_scheduled = false
        state.lobby_bind_retry_count = state.lobby_bind_retry_count + 1
        ensure_lobby_watcher()
    end)
    if not scheduled then
        state.lobby_bind_retry_scheduled = false
    end
    return scheduled
end

ensure_lobby_watcher = function()
    if state._s1 == true or state.lobby_ready == true then
        return true
    end

    if is_lobby_ready_now() then
        on_lobby_ready()
        return true
    end

    if register_lobby_listener() then
        -- Close the race where Lobby became current between the synchronous
        -- stage check and listener registration.
        if is_lobby_ready_now() then
            on_lobby_ready()
        end
        return true
    end

    schedule_lobby_bind_retry()
    return false
end

local function install_manual_entrypoints()
    -- Install these before any auth request. A transport implementation is
    -- allowed to invoke its callback synchronously.
    rawset(_G, "OpenSpectraLogin", function()
        state._s5 = false
        state._s6 = false
        return LoginUI.open_license(true)
    end)

    rawset(_G, "OpenSpectraControl", function()
        state._s3 = false
        state._s4 = false
        return LoginUI.open_control()
    end)
end

local function start_saved_key_auth()
    local saved = Storage.get_card()
    if saved == "" then
        state.auto_login_attempted = false
        return false
    end

    state.auto_login_attempted = true
    state.auto_login_key = saved

    return Auth.authenticate(saved, function(ok, kind)
        state.auto_login_key = nil
        if ok then
            return
        end

        -- A non-success server code is a key/account rejection. Freshness/check
        -- failures are transport integrity failures, not proof that the key expired.
        if kind == "server_reject" then
            Storage.clear_card()
            state.saved_key_invalid = true
        end

        if is_lobby_ready_now() then
            state.lobby_ready = true
        end
        open_login_if_ready()
    end)
end

function M.start()
    if not initialize_state() then
        return false
    end

    install_manual_entrypoints()

    local crypto_ok = S.Crypto.self_test()
    state._c7 = crypto_ok == true

    ensure_lobby_watcher()

    -- Saved key is authenticated before any automatic popup. No automatic
    -- ConfirmWindows path remains.
    if not start_saved_key_auth() then
        open_login_if_ready()
    end

    return true
end

end)(S)
-- END bootstrap.lua

return S.Bootstrap.start()
