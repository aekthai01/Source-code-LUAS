#!/usr/bin/env python3
"""Reproducible structural index from the verified embedded-payload extraction.

Capture relationships are not automatically interpreted as invocation edges.
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = {x['path']: x for x in json.loads((ROOT/'payload_prototypes.json').read_text())}
C = json.loads((ROOT/'payload_constants.json').read_text())
IDS = [*range(30, 46), *range(61, 67), *range(74, 78)]
parent = (ROOT/'proto_0_29.txt').read_text()
closures = {int(reg): f'0.29.{proto}' for reg, proto in re.findall(r'CLOSURE\s+R(\d+), P(\d+)', parent)}
by_proto = {}
for p in P.values():
    for u in p['upvalues']:
        if p['path'].startswith('0.29.') and u['instack'] == 1 and u['idx'] in closures:
            by_proto.setdefault(closures[u['idx']], set()).add(p['path'])

out = {}
for i in IDS:
    pid = f'0.29.{i}'
    p = P[pid]
    file = ROOT / f'proto_0_29_{i}.txt'
    if not file.exists(): file = ROOT / '_aim_sections' / f'0_29_{i}.txt'
    lines = file.read_text().splitlines()
    up = []
    for u in p['upvalues']:
        idx = u['idx']
        up.append({'scope': 'parent_register' if u['instack'] else 'parent_upvalue',
                   'index': idx, 'closure': closures.get(idx) if u['instack'] else None})
    consts = [c['value'] for c in C if c['proto'] == pid]
    env_slots = [j for j, u in enumerate(p['upvalues']) if u['instack'] == 0 and u['idx'] == 0]
    globals_used = sorted({key for slot, key in re.findall(r"GETTABUP\s+R\d+, U(\d+), K\d+='([^']+)'", '\n'.join(lines))
                           if int(slot) in env_slots})
    writes = sorted(set(re.findall(r"SETTABUP\s+U\d+, K\d+='([^']+)'", '\n'.join(lines))))
    named_fields = sorted(set(re.findall(r"(?:GETTABLE|SETTABLE)\s+[^\n]*K\d+='([^']+)'", '\n'.join(lines))))
    returns = sorted(set(map(int, re.findall(r'RETURN\s+A=\d+ B=(\d+)', '\n'.join(lines)))))
    out[pid] = {
        'evidence': str(file.relative_to(ROOT)),
        'instruction_count': p['instruction_count'],
        'captured_upvalues': up,
        'captured_by': sorted(by_proto.get(pid, set())),
        'globals_from_environment': globals_used,
        'constants': consts,
        'state_keys_in_constants': sorted({v for v in consts if isinstance(v, str) and v.startswith('custom_')}),
        'table_or_config_literals': sorted({v for v in consts if isinstance(v, str) and ('Table' in v or 'Config' in v)}),
        'literal_fields': named_fields,
        'global_writes': writes,
        'return_B_operands': returns,
        'call_edges': 'Consult upvalue captures and disassembly CALL sites; captures alone do not prove invocation.',
        'engine_side_effects': 'Undetermined by static extraction; inspect CALL sites before runtime takeover.',
        'reconstructed_name': f'P0_29_{i}_descriptive_pending' if i not in (65,77) else {65:'replace_aim_field',77:'set_dongdong_aim_part'}[i],
        'name_is_original_symbol': False,
        'confidence': 'structural metadata verified; dynamic behavior requires per-branch review',
    }
(ROOT/'AIM_PROTOTYPE_INDEX.json').write_text(json.dumps(out, indent=2, ensure_ascii=False)+'\n')
print(f'indexed {len(out)} prototypes; {len(closures)} parent closures')
