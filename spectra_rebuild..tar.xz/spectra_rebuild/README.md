# SPECTRA wrapper reconstruction bundle

Bundle นี้ยึด `baseline_original.luac` เป็น source of truth เดียว

- baseline size: `180034`
- baseline SHA-256: `35ee381760ea24dcfebfac44433f8fe3078b4b34df79b165968bfeb87c874536`
- embedded payload size: `108533`
- embedded payload SHA-256: `a0438b2eb2ecdec664dc25a6093766b9d79ab2dc6bc00536d59ff901798f6263`

## Primary checkpoint files

- `baseline_original.luac` — exact copy of the attached known-good baseline.
- `spectra_wrapper_source.lua` — generated single-file editable wrapper source.
- `spectra_wrapper.standard.luac` — standard compiled Lua 5.3 chunk before opcode remap.
- `spectra_wrapper.custom.luac` — compiled wrapper for baseline runtime format (`size_t=4` + recovered opcode permutation).
- `embedded_payload.bin` — exact decoded payload from baseline.
- `embedded_payload.b64` — exact Base64 concatenation extracted from baseline root constants.
- `PHASE_A_REPORT.md` — forensic findings, protocol, UI/login behavior and rebuild status.
- `WRAPPER_CALL_GRAPH.md` / `wrapper_call_graph.json` — resolved baseline wrapper call graph.
- `validation.json` — regenerated hashes, opcode evidence and completed checks.

## Editable modules

`src/spectra/` contains:

- `runtime.lua`
- `crypto.lua`
- `storage.lua`
- `transport.lua`
- `payload_embed.lua`
- `payload_loader.lua`
- `auth.lua`
- `login_ui.lua`
- `bootstrap.lua`

The automatic login path does not use `ConfirmWindows`. It authenticates a saved
`SPECTRA_WY_71438_CARD` first without opening UI. First-time login opens only after
the verified Lobby event/current-flow path. If the Lobby event module is not yet
available, bootstrap retries **listener registration only** at the baseline 1 s / 60
attempt envelope. It does not run a UI reopen watchdog.

## Rebuild + validation

Requires a Lua 5.3 compiler. `tools/build.py` auto-detects `luac5.3`, `texluac`, or
`luac` when it reports Lua 5.3.

```sh
python3 tools/build.py
```

The build script:

1. bundles editable source modules,
2. syntax-checks and compiles stripped standard Lua 5.3 bytecode,
3. remaps standard opcodes to the recovered runtime permutation,
4. writes the target chunk with `size_t=4`,
5. runs `tools/validate.py`, which regenerates `validation.json` and runs the meaningful regression checks.

Current custom rebuild:

- size: `180467`
- SHA-256: `44a7705e2593daea5903f89671c58266ffaa455e1533ddbbbfb8ed4bf4b072d1`

## Tests

Full validator:

```sh
python3 tools/validate.py
```

Behavior smoke tests:

```sh
texlua tests/smoke.lua .
```

Deterministic protocol fixture:

```sh
texlua tests/protocol_fixture.lua .
```

The tests cover saved-key auto-auth/no-popup, synchronous callback entrypoint
ordering, Lobby-gated first-time UI, stale-widget manual reopen, server rejection,
already-in-Lobby detection, late Lobby-event module binding, baseline JSON/tip/bytes
bridge signatures, HttpLoader completion lifecycle, and exact HttpLoader callback-body argument semantics.

## Opcode evidence

`opcode_map.json` contains the recovered mapping used by the converter. Direct
instruction evidence exists for 44/47 raw opcode values across outer+payload.
Raw `8` (`IDIV`), `36` (`LOADKX`) and `46` (`EXTRAARG`) do not occur in either
chunk and are explicitly recorded as inferred-only in `validation.json`.

Manual conversion:

```sh
python3 tools/remap_lua53.py --to-standard --target-size-t 8 input.luac output.luac
python3 tools/remap_lua53.py --to-custom   --target-size-t 4 input.luac output.luac
```

The converter refuses an unsafe `size_t` width change if a chunk contains Lua 5.3
long-string length fields.

## Forensic exports

- `outer_*` describe the attached baseline wrapper.
- `payload_*` describe the exact decoded embedded payload.
- constants and prototype metadata are JSON.
- complete disassembly and string tables are text.

## Runtime checkpoint

`game_runtime_test` is intentionally `false` in `validation.json`. The custom
chunk has not been executed inside the actual DFM/game engine in this sandbox.
Passing local build/round-trip/smoke checks is not presented as proof of engine
compatibility.

## Phase D1: reconstructed post-login native settings UI

The first payload group has now been moved back to editable Lua source without changing
the embedded payload bytes:

- `src/spectra/native_settings_ui.lua` reconstructs payload prototype `0.29.105`
- `src/spectra/payload_ui_bridge.lua` swaps the bytecode-installed native settings hooks
  for the source implementation only after payload load succeeds
- `PAYLOAD_UI_MAP.md` records the exact post-login menu, controls, ranges and callbacks
- `PAYLOAD_FUNCTION_CATALOG.md` records exact payload/public/root symbols and explicitly
  distinguishes reconstructed helper names
- `PHASE_D_REPORT.md` records scope and remaining groups

Build the separate D1 checkpoint without overwriting the stable Phase-C artifact:

```sh
python3 tools/build_phase_d.py
python3 tools/validate_phase_d.py
```

Current D1 custom chunk:

- size: `208172`
- SHA-256: `ad668a891a573fba40e2e112650d2060d0c3e85498c4ae60cedef6e1ca512d97`

The baseline payload contains the old page title `@starrmods        `, but the D1 source
UI intentionally displays `@DrkZeref` per the reconstruction requirement. The old
value remains only in forensic/baseline payload evidence so payload identity is not
falsified.

### Phase D2

D2 adds editable source reconstructions for `set_dongdong_feature_config`, `set_dongdong_aim_part`, `set_ai_color`, `set_real_player_color`, `set_character_xray`, and their small normalization helpers. These modules are bundled and syntax/unit tested but do not replace the known-good payload globals yet; lower-level captured helper prototypes are the next reconstruction boundary.

Run:

```sh
python tools/build_phase_d.py
python tools/validate_phase_d.py
```

### Phase D3

D3 adds reversible source-owned DataTable mutation for two features while keeping the
embedded payload byte-identical:

- `src/spectra/mutation_runtime.lua` reconstructs snapshot/TableManager/recoil/spread
  helpers and the `0.29.67`/`0.29.68` dispatch layer.
- `src/spectra/payload_feature_bridge.lua` captures the known-good payload global and
  routes only `no_recoil` + `converge` into source.
- `aim` + `anti_shake` still delegate to the payload until the large `0.29.65` aim
  replacement function and its dependencies are fully reconstructed.
- `DATA_MUTATION_MAP.md` records exact DataTable candidates, fields, recursion behavior,
  prototype IDs and the runtime ownership boundary.

D3-specific tests:

```sh
texlua tests/mutation_runtime.lua .
texlua tests/payload_feature_bridge.lua .
```

Current D3 custom chunk:

- size: `238497`
- SHA-256: `1cbe099f234415e9807dc90f0bdd381e1d600dc8af0c0c5790fdbb39633af349`

## Current verified Phase-D ownership

The current materialized checkpoint is intentionally conservative:

- reconstructed native settings UI: source-owned
- `no_recoil`, `converge`: source-owned
- `aim`, `anti_shake`: still payload-owned in this delivered checkpoint
- `set_ai_color`, `set_real_player_color`, `set_character_xray`: source-owned
- visual actor/mesh immediate rescan (`P0.29.78..98`): source-owned
- fashion refresh hook `P0.29.104` and tick/fallback `P0.29.106/107`: source-owned after payload init

A prior report-only aim D4 state was not present in the actual workspace and is not treated as
completed. `validation_phase_d.json` is the authoritative machine-readable ownership record.
