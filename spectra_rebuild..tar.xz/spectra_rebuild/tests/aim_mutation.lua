local root = assert(arg[1])
local S = {}
assert(loadfile(root .. "/src/spectra/aim_mutation.lua"))(S)
local M = S.AimMutation
local function eq(a, b, why)
    if a ~= b then error((why or "value") .. ": expected " .. tostring(b) .. ", got " .. tostring(a), 2) end
end
local state = {custom_dongdong_toggle_state = {anti_shake = true},
    custom_aim_speed = 100, custom_aim_range = 180, custom_aim_distance = 300, custom_aim_lock_time = 50}
local deps = {
    normalize_identifier = function(v) return string.lower(tostring(v)):gsub("[^%w]", "") end,
    read_field = function(row, key) return row[key] end,
    scale_clamp = function(value, multiplier, lo, hi)
        return math.min(hi, math.max(lo, (tonumber(value) or 0) * multiplier))
    end,
}
local function replace(mode, name, field, original, row, path)
    state.custom_dongdong_toggle_state.anti_shake = mode == "ads"
    state.custom_dongdong_toggle_state.aim = mode == "fire"
    return M.replacement(state, deps, row or {}, name, field, original, path)
end
local name = "WeaponBase/WeaponAimAssistorTable"
local gamepad = "WeaponBase/WeaponAimAssistorTableForGamepad"
local v, patch = replace("ads", name, "bTakeEffect", false)
eq(v, true, "ADS normal enable"); eq(patch, true)
v, patch = replace("ads", gamepad, "bTakeEffect", false)
eq(v, nil, "Gamepad excluded from ordinary ADS path"); eq(patch, false)
v, patch = replace("ads", name, "InRangeB", 9000)
eq(v, 66666, "ADS distance scaling"); eq(patch, true)
v, patch = replace("ads", name, "InRangeB", "9000")
eq(v, nil, "numeric guard"); eq(patch, false)
v, patch = replace("ads", name, "PitchRateHip", 2)
eq(v, nil, "hip rate in ADS"); eq(patch, false)
v, patch = replace("fire", "WeaponBase/WeaponBulletTable", "Radius", 3)
eq(v, 5, "fire bullet threshold"); eq(patch, true)
v, patch = replace("fire", "WeaponBase/WeaponBulletTable", "Radius", 4)
eq(v, nil, "fire bullet threshold above cutoff"); eq(patch, false)
v, patch = replace("fire", "WeaponBase/WeaponAssistedAimingGroupTable", "SingleIdPVE", nil, {SingleId = 1002})
eq(v, 1002, "group linked ID"); eq(patch, true)
v, patch = replace("fire", "WeaponBase/WeaponAssistedAimingGroupTable", "SingleIdPVE", nil, {SingleId = 0})
eq(v, nil, "group invalid ID"); eq(patch, false)
v, patch = replace("fire", "WeaponBase/WeaponAssistedAimingTable", "EnableDistanceMax", 0)
eq(v, 90000, "assisted range"); eq(patch, true)
eq(M.PROFILE_VALUES[1001].coneheightbase, 45900, "bytecode profile 1001")
eq(M.PROFILE_VALUES[1004].shootingconfigrangescaleoutrangeb, 3, "bytecode profile 1004")
v, patch = replace("fire", "ShootingConfig", "PitchFactorAds", 0, {}, 1)
eq(v, 2.6, "profile factor by ID"); eq(patch, true)
v, patch = replace("fire", "ShootingConfig", "PitchFactorAds", 0, {}, 99999)
eq(v, nil, "unknown profile ID"); eq(patch, false)
v, patch = replace("fire", "ActiveTrackingConfig", "bTakeEffect", true)
eq(v, false, "tracking disabled"); eq(patch, true)
v, patch = replace("fire", "ShootingConfig", "bTakeEffect", false)
eq(v, true, "shooting enabled"); eq(patch, true)
v, patch = replace("none", name, "bTakeEffect", false)
eq(v, nil, "inactive mode"); eq(patch, false)
print("aim-mutation: ok")
